import { useState, useEffect } from "react";
import { Navigation } from "./components/Navigation";
import { HeroSection } from "./components/HeroSection";
import { HowItWorks } from "./components/HowItWorks";
import { DonationListings } from "./components/DonationListings";
import { Organizations } from "./components/Organizations";
import { Footer } from "./components/Footer";
import { UserProfile } from "./components/UserProfile";
import { Dashboard } from "./components/Dashboard";
import { RestaurantDashboard } from "./components/RestaurantDashboard";
import { OrphanageDashboard } from "./components/OrphanageDashboard";
import { MessagingSystem } from "./components/MessagingSystem";
import { OrganizationProfile } from "./components/OrganizationProfile";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { DonationProvider } from "./contexts/DonationContext";
import { NotificationProvider } from "./contexts/NotificationContext";
import { Card, CardContent } from "./components/ui/card";
import { Alert, AlertDescription } from "./components/ui/alert";
import { ChefHat, Baby, Loader2, Truck } from "lucide-react";
import { VolunteerDashboard } from "./components/VolunteerDashboard";

function AppContent() {
  const [currentPage, setCurrentPage] = useState('home');
  const [isRedirecting, setIsRedirecting] = useState(false);
  const [showOrgProfile, setShowOrgProfile] = useState(false);
  const [selectedOrgId, setSelectedOrgId] = useState<string>('');

  const { user, profile, loading } = useAuth();

  // Handle immediate role-based redirects
  useEffect(() => {
    if (user && profile && !loading) {
      // Determine the correct dashboard based on organization type
      let correctDashboard: string;
      if (profile.organization_type === 'donor') {
        correctDashboard = 'restaurant-dashboard';
      } else if (profile.organization_type === 'volunteer') {
        correctDashboard = 'volunteer-dashboard';
      } else {
        correctDashboard = 'orphanage-dashboard';
      }

      // Auto-redirect from home or if on wrong dashboard
      if (currentPage === 'home' || 
          (profile.organization_type === 'donor' && currentPage !== 'restaurant-dashboard' && currentPage.includes('dashboard')) ||
          (profile.organization_type === 'volunteer' && currentPage !== 'volunteer-dashboard' && currentPage.includes('dashboard')) ||
          (profile.organization_type === 'recipient' && currentPage !== 'orphanage-dashboard' && currentPage.includes('dashboard')) ||
          currentPage === 'dashboard') {
        
        setIsRedirecting(true);
        
        // Small delay to show redirect message
        setTimeout(() => {
          setCurrentPage(correctDashboard);
          setIsRedirecting(false);
        }, 1500);
      }
    }
  }, [user, profile, loading, currentPage]);

  // Handle logout redirect
  useEffect(() => {
    if (!user && !loading && currentPage.includes('dashboard')) {
      setCurrentPage('home');
    }
  }, [user, loading, currentPage]);

  const handleNavigate = (page: string) => {
    // Prevent navigation to wrong dashboard type
    if (user && profile) {
      if (page === 'dashboard') {
        // Always redirect to appropriate dashboard
        if (profile.organization_type === 'donor') {
          page = 'restaurant-dashboard';
        } else if (profile.organization_type === 'volunteer') {
          page = 'volunteer-dashboard';
        } else {
          page = 'orphanage-dashboard';
        }
      }
      // Redirect to correct dashboard if trying to access wrong one
      else if (profile.organization_type === 'donor' && (page === 'orphanage-dashboard' || page === 'volunteer-dashboard')) {
        page = 'restaurant-dashboard';
      } else if (profile.organization_type === 'volunteer' && (page === 'restaurant-dashboard' || page === 'orphanage-dashboard')) {
        page = 'volunteer-dashboard';
      } else if (profile.organization_type === 'recipient' && (page === 'restaurant-dashboard' || page === 'volunteer-dashboard')) {
        page = 'orphanage-dashboard';
      }
    }
    
    setCurrentPage(page);
  };

  const handleViewOrganizationProfile = (orgId: string) => {
    setSelectedOrgId(orgId);
    setShowOrgProfile(true);
  };

  const handleMessage = (orgId: string) => {
    setCurrentPage('messages');
  };

  const renderRedirectScreen = () => {
    const isDonor = profile?.organization_type === 'donor';
    const isVolunteer = profile?.organization_type === 'volunteer';
    const isRecipient = profile?.organization_type === 'recipient';
    
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="mb-6">
              {isDonor ? (
                <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center">
                  <ChefHat className="h-8 w-8 text-orange-600" />
                </div>
              ) : isVolunteer ? (
                <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                  <Truck className="h-8 w-8 text-green-600" />
                </div>
              ) : (
                <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <Baby className="h-8 w-8 text-blue-600" />
                </div>
              )}
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Welcome to FoodBridge!
            </h2>
            
            <p className="text-gray-600 mb-4">
              Redirecting you to your {isDonor ? 'Restaurant' : isVolunteer ? 'Volunteer' : 'Orphanage'} dashboard...
            </p>
            
            <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Setting up your personalized experience</span>
            </div>
            
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                <strong>{profile?.organization_name}</strong>
                <br />
                {isDonor ? '🍽️ Food Donor' : isVolunteer ? '🚚 Volunteer Driver' : '👶 Food Recipient'} • Khammam
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderPage = () => {
    // Show redirect screen when redirecting
    if (isRedirecting && user && profile) {
      return renderRedirectScreen();
    }

    switch (currentPage) {
      case 'home':
        return (
          <main>
            <HeroSection />
            <HowItWorks />
            <DonationListings />
            <Organizations />
          </main>
        );
      case 'profile':
        return <UserProfile />;
      case 'org-profile':
        return (
          <OrganizationProfile
            organizationId={selectedOrgId}
            onClose={() => setCurrentPage('home')}
            onMessage={handleMessage}
          />
        );
      case 'dashboard':
        // Legacy dashboard - always redirect to role-specific dashboard
        if (profile?.organization_type === 'donor') {
          return <RestaurantDashboard onNavigate={handleNavigate} />;
        } else if (profile?.organization_type === 'volunteer') {
          return <VolunteerDashboard onNavigate={handleNavigate} />;
        } else if (profile?.organization_type === 'recipient') {
          return <OrphanageDashboard onNavigate={handleNavigate} />;
        }
        return <Dashboard onNavigate={handleNavigate} />;
      case 'restaurant-dashboard':
        // Only allow donors to access restaurant dashboard
        if (profile?.organization_type === 'donor') {
          return <RestaurantDashboard onNavigate={handleNavigate} />;
        } else {
          // Redirect to correct dashboard
          setTimeout(() => handleNavigate('dashboard'), 100);
          return renderRedirectScreen();
        }
      case 'volunteer-dashboard':
        // Only allow volunteers to access volunteer dashboard
        if (profile?.organization_type === 'volunteer') {
          return <VolunteerDashboard onNavigate={handleNavigate} />;
        } else {
          // Redirect to correct dashboard
          setTimeout(() => handleNavigate('dashboard'), 100);
          return renderRedirectScreen();
        }
      case 'orphanage-dashboard':
        // Only allow recipients to access orphanage dashboard
        if (profile?.organization_type === 'recipient') {
          return <OrphanageDashboard onNavigate={handleNavigate} />;
        } else {
          // Redirect to correct dashboard
          setTimeout(() => handleNavigate('dashboard'), 100);
          return renderRedirectScreen();
        }
      case 'messages':
        return <MessagingSystem />;
      default:
        return (
          <main>
            <HeroSection />
            <HowItWorks />
            <DonationListings />
            <Organizations />
          </main>
        );
    }
  };

  const shouldShowFooter = () => {
    return (currentPage === 'home' && !isRedirecting) || 
           (!user && ['home'].includes(currentPage));
  };

  const shouldShowNavigation = () => {
    // Always show navigation unless we're in a redirect state
    return !isRedirecting;
  };

  // Show loading screen while auth is loading
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="p-8">
          <div className="flex items-center gap-3">
            <Loader2 className="h-5 w-5 animate-spin text-green-600" />
            <span>Loading FoodBridge...</span>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">


      {shouldShowNavigation() && (
        <Navigation onNavigate={handleNavigate} currentPage={currentPage} />
      )}
      {renderPage()}
      {shouldShowFooter() && <Footer />}

      {/* Organization Profile Modal */}
      {showOrgProfile && (
        <OrganizationProfile
          organizationId={selectedOrgId}
          onClose={() => setShowOrgProfile(false)}
          onMessage={handleMessage}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DonationProvider>
        <NotificationProvider>
          <AppContent />
        </NotificationProvider>
      </DonationProvider>
    </AuthProvider>
  );
}