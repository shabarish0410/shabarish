import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';

const app = new Hono();

app.use('*', logger(console.log));
app.use('*', cors());

// Initialize Supabase clients
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// KV Store utility functions
const KV_TABLE = 'kv_store_e4b54fa0';

async function kvGet(key: string) {
  try {
    const { data, error } = await supabaseClient
      .from(KV_TABLE)
      .select('value')
      .eq('key', key)
      .single();
    
    if (error || !data) return null;
    return JSON.parse(data.value);
  } catch (error) {
    console.log(`Error in kvGet for key ${key}:`, error);
    return null;
  }
}

async function kvSet(key: string, value: any) {
  try {
    const { error } = await supabaseClient
      .from(KV_TABLE)
      .upsert({ key, value: JSON.stringify(value) });
    
    if (error) throw error;
  } catch (error) {
    console.log(`Error in kvSet for key ${key}:`, error);
    throw error;
  }
}

async function kvGetByPrefix(prefix: string) {
  try {
    const { data, error } = await supabaseClient
      .from(KV_TABLE)
      .select('key, value')
      .like('key', `${prefix}%`);
    
    if (error) throw error;
    return (data || []).map(item => JSON.parse(item.value));
  } catch (error) {
    console.log(`Error in kvGetByPrefix for prefix ${prefix}:`, error);
    return [];
  }
}

// Helper function to verify authenticated user
async function verifyUser(request: Request) {
  try {
    const accessToken = request.headers.get('Authorization')?.split(' ')[1];
    if (!accessToken) return null;
    
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user?.id) {
      return null;
    }
    
    return user;
  } catch (error) {
    console.log('Error verifying user:', error);
    return null;
  }
}

// Sign up route
app.post('/make-server-e4b54fa0/signup', async (c) => {
  try {
    const { email, password, name, organizationName, organizationType, address, phone, description } = await c.req.json();

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (authError) {
      console.log('Authentication error during user creation:', authError);
      return c.json({ error: authError.message }, 400);
    }

    if (!authData.user) {
      console.log('No user returned from auth creation');
      return c.json({ error: 'Failed to create user' }, 400);
    }

    // Store user profile in KV store
    const profileData = {
      id: authData.user.id,
      email,
      name,
      organization_name: organizationName,
      organization_type: organizationType,
      address,
      phone,
      description,
      created_at: new Date().toISOString()
    };

    await kvSet(`profile:${authData.user.id}`, profileData);

    return c.json({ 
      message: 'User created successfully',
      user: authData.user
    });
  } catch (error) {
    console.log('Server error during signup:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Get user profile
app.get('/make-server-e4b54fa0/profile/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    
    const user = await verifyUser(c.req);
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = await kvGet(`profile:${userId}`);
    
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json(profile);
  } catch (error) {
    console.log('Error fetching profile:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Update user profile
app.put('/make-server-e4b54fa0/profile/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    
    const user = await verifyUser(c.req);
    if (!user?.id || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const updates = await c.req.json();
    const currentProfile = await kvGet(`profile:${userId}`);
    
    if (!currentProfile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    const updatedProfile = {
      ...currentProfile,
      ...updates,
      updated_at: new Date().toISOString()
    };

    await kvSet(`profile:${userId}`, updatedProfile);

    return c.json(updatedProfile);
  } catch (error) {
    console.log('Error updating profile:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Get all organizations (for directory)
app.get('/make-server-e4b54fa0/organizations', async (c) => {
  try {
    const organizationType = c.req.query('type'); // 'donor' or 'recipient'
    
    const profiles = await kvGetByPrefix('profile:');
    
    let filteredProfiles = profiles;
    if (organizationType) {
      filteredProfiles = profiles.filter(profile => 
        profile.organization_type === organizationType
      );
    }

    // Remove sensitive information
    const publicProfiles = filteredProfiles.map(profile => ({
      id: profile.id,
      name: profile.name,
      organization_name: profile.organization_name,
      organization_type: profile.organization_type,
      address: profile.address,
      description: profile.description
    }));

    return c.json(publicProfiles);
  } catch (error) {
    console.log('Error fetching organizations:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// ===== DONATION ROUTES =====

// Create donation (donors only)
app.post('/make-server-e4b54fa0/donations', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = await kvGet(`profile:${user.id}`);
    if (!profile || profile.organization_type !== 'donor') {
      return c.json({ error: 'Only donor organizations can create donations' }, 403);
    }

    const donationData = await c.req.json();
    const donationId = crypto.randomUUID();
    
    const donation = {
      id: donationId,
      donor_id: user.id,
      donor_name: profile.organization_name,
      donor_address: profile.address,
      donor_phone: profile.phone,
      title: donationData.title,
      description: donationData.description,
      food_type: donationData.food_type,
      quantity: donationData.quantity,
      unit: donationData.unit,
      expiration_date: donationData.expiration_date,
      pickup_instructions: donationData.pickup_instructions,
      available_from: donationData.available_from,
      available_until: donationData.available_until,
      status: 'available', // available, claimed, completed, expired
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    await kvSet(`donation:${donationId}`, donation);

    return c.json(donation);
  } catch (error) {
    console.log('Error creating donation:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Get donations (with filtering)
app.get('/make-server-e4b54fa0/donations', async (c) => {
  try {
    const status = c.req.query('status');
    const donorId = c.req.query('donor_id');
    const foodType = c.req.query('food_type');
    
    const donations = await kvGetByPrefix('donation:');
    
    let filteredDonations = donations;
    
    if (status) {
      filteredDonations = filteredDonations.filter((d: any) => d.status === status);
    }
    
    if (donorId) {
      filteredDonations = filteredDonations.filter((d: any) => d.donor_id === donorId);
    }
    
    if (foodType) {
      filteredDonations = filteredDonations.filter((d: any) => 
        d.food_type.toLowerCase().includes(foodType.toLowerCase())
      );
    }

    // Sort by created date (newest first)
    filteredDonations.sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return c.json(filteredDonations);
  } catch (error) {
    console.log('Error fetching donations:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Update donation status
app.put('/make-server-e4b54fa0/donations/:donationId', async (c) => {
  try {
    const donationId = c.req.param('donationId');
    const user = await verifyUser(c.req);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const donation = await kvGet(`donation:${donationId}`);
    if (!donation) {
      return c.json({ error: 'Donation not found' }, 404);
    }

    const updates = await c.req.json();
    
    // Only donor can update their own donations, or recipients can claim
    if (donation.donor_id !== user.id && updates.status !== 'claimed') {
      return c.json({ error: 'Unauthorized to update this donation' }, 403);
    }

    // If claiming, add recipient info
    if (updates.status === 'claimed' && donation.status === 'available') {
      const recipientProfile = await kvGet(`profile:${user.id}`);
      if (!recipientProfile || recipientProfile.organization_type !== 'recipient') {
        return c.json({ error: 'Only recipient organizations can claim donations' }, 403);
      }
      
      updates.recipient_id = user.id;
      updates.recipient_name = recipientProfile.organization_name;
      updates.recipient_phone = recipientProfile.phone;
      updates.claimed_at = new Date().toISOString();
    }

    const updatedDonation = {
      ...donation,
      ...updates,
      updated_at: new Date().toISOString()
    };

    await kvSet(`donation:${donationId}`, updatedDonation);

    return c.json(updatedDonation);
  } catch (error) {
    console.log('Error updating donation:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// ===== REQUEST ROUTES =====

// Create request (recipients only)
app.post('/make-server-e4b54fa0/requests', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = await kvGet(`profile:${user.id}`);
    if (!profile || profile.organization_type !== 'recipient') {
      return c.json({ error: 'Only recipient organizations can create requests' }, 403);
    }

    const requestData = await c.req.json();
    const requestId = crypto.randomUUID();
    
    const request = {
      id: requestId,
      recipient_id: user.id,
      recipient_name: profile.organization_name,
      recipient_address: profile.address,
      recipient_phone: profile.phone,
      title: requestData.title,
      description: requestData.description,
      food_type: requestData.food_type,
      quantity_needed: requestData.quantity_needed,
      unit: requestData.unit,
      needed_by: requestData.needed_by,
      urgency: requestData.urgency, // low, medium, high
      status: 'open', // open, fulfilled, expired
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    await kvSet(`request:${requestId}`, request);

    return c.json(request);
  } catch (error) {
    console.log('Error creating request:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Get requests (with filtering)
app.get('/make-server-e4b54fa0/requests', async (c) => {
  try {
    const status = c.req.query('status');
    const recipientId = c.req.query('recipient_id');
    const urgency = c.req.query('urgency');
    const foodType = c.req.query('food_type');
    
    const requests = await kvGetByPrefix('request:');
    
    let filteredRequests = requests;
    
    if (status) {
      filteredRequests = filteredRequests.filter((r: any) => r.status === status);
    }
    
    if (recipientId) {
      filteredRequests = filteredRequests.filter((r: any) => r.recipient_id === recipientId);
    }
    
    if (urgency) {
      filteredRequests = filteredRequests.filter((r: any) => r.urgency === urgency);
    }
    
    if (foodType) {
      filteredRequests = filteredRequests.filter((r: any) => 
        r.food_type.toLowerCase().includes(foodType.toLowerCase())
      );
    }

    // Sort by urgency and created date
    filteredRequests.sort((a: any, b: any) => {
      const urgencyOrder: any = { high: 3, medium: 2, low: 1 };
      const urgencyDiff = urgencyOrder[b.urgency] - urgencyOrder[a.urgency];
      if (urgencyDiff !== 0) return urgencyDiff;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });

    return c.json(filteredRequests);
  } catch (error) {
    console.log('Error fetching requests:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Update request status
app.put('/make-server-e4b54fa0/requests/:requestId', async (c) => {
  try {
    const requestId = c.req.param('requestId');
    const user = await verifyUser(c.req);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const request = await kvGet(`request:${requestId}`);
    if (!request) {
      return c.json({ error: 'Request not found' }, 404);
    }

    const updates = await c.req.json();
    
    // Only request creator can update their own requests
    if (request.recipient_id !== user.id) {
      return c.json({ error: 'Unauthorized to update this request' }, 403);
    }

    const updatedRequest = {
      ...request,
      ...updates,
      updated_at: new Date().toISOString()
    };

    await kvSet(`request:${requestId}`, updatedRequest);

    return c.json(updatedRequest);
  } catch (error) {
    console.log('Error updating request:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// ===== MESSAGING ROUTES =====

// Get conversations for user
app.get('/make-server-e4b54fa0/conversations', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const conversations = await kvGetByPrefix(`conversation:${user.id}:`);
    
    // Sort by last message time
    conversations.sort((a: any, b: any) => 
      new Date(b.last_message_at || b.created_at).getTime() - 
      new Date(a.last_message_at || a.created_at).getTime()
    );

    return c.json(conversations);
  } catch (error) {
    console.log('Error fetching conversations:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Create or get conversation
app.post('/make-server-e4b54fa0/conversations', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { other_user_id, donation_id, request_id } = await c.req.json();
    
    // Check if conversation already exists
    const conversationId1 = `conversation:${user.id}:${other_user_id}`;
    const conversationId2 = `conversation:${other_user_id}:${user.id}`;
    
    let conversation = await kvGet(conversationId1) || await kvGet(conversationId2);
    
    if (!conversation) {
      // Create new conversation
      const otherProfile = await kvGet(`profile:${other_user_id}`);
      const userProfile = await kvGet(`profile:${user.id}`);
      
      if (!otherProfile || !userProfile) {
        return c.json({ error: 'Profile not found' }, 404);
      }

      conversation = {
        id: `${user.id}:${other_user_id}`,
        participants: [
          {
            id: user.id,
            name: userProfile.organization_name,
            type: userProfile.organization_type
          },
          {
            id: other_user_id,
            name: otherProfile.organization_name,
            type: otherProfile.organization_type
          }
        ],
        donation_id: donation_id || null,
        request_id: request_id || null,
        created_at: new Date().toISOString(),
        last_message_at: null
      };

      // Store conversation for both users
      await kvSet(conversationId1, conversation);
      await kvSet(conversationId2, conversation);
    }

    return c.json(conversation);
  } catch (error) {
    console.log('Error creating conversation:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Get messages in conversation
app.get('/make-server-e4b54fa0/conversations/:conversationId/messages', async (c) => {
  try {
    const conversationId = c.req.param('conversationId');
    const user = await verifyUser(c.req);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Verify user is part of conversation
    if (!conversationId.includes(user.id)) {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const messages = await kvGetByPrefix(`message:${conversationId}:`);
    
    // Sort by timestamp
    messages.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    return c.json(messages);
  } catch (error) {
    console.log('Error fetching messages:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Send message
app.post('/make-server-e4b54fa0/conversations/:conversationId/messages', async (c) => {
  try {
    const conversationId = c.req.param('conversationId');
    const user = await verifyUser(c.req);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Verify user is part of conversation
    if (!conversationId.includes(user.id)) {
      return c.json({ error: 'Unauthorized' }, 403);
    }

    const { message, type = 'text' } = await c.req.json();
    const messageId = crypto.randomUUID();
    const timestamp = new Date().toISOString();
    
    const userProfile = await kvGet(`profile:${user.id}`);
    
    const messageData = {
      id: messageId,
      conversation_id: conversationId,
      sender_id: user.id,
      sender_name: userProfile.organization_name,
      message,
      type, // text, status_update, system
      timestamp,
      read: false
    };

    await kvSet(`message:${conversationId}:${timestamp}:${messageId}`, messageData);

    // Update conversation last message time
    const conversationKey1 = `conversation:${user.id}:${conversationId.replace(`${user.id}:`, '')}`;
    const conversationKey2 = `conversation:${conversationId.replace(`:${user.id}`, '')}:${user.id}`;
    
    const conversation1 = await kvGet(conversationKey1);
    const conversation2 = await kvGet(conversationKey2);
    
    if (conversation1) {
      await kvSet(conversationKey1, { ...conversation1, last_message_at: timestamp });
    }
    if (conversation2) {
      await kvSet(conversationKey2, { ...conversation2, last_message_at: timestamp });
    }

    return c.json(messageData);
  } catch (error) {
    console.log('Error sending message:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

Deno.serve(app.fetch);