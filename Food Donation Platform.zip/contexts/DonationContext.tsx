import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useAuth } from './AuthContext';

interface Donation {
  id: string;
  title: string;
  description: string;
  food_type: string;
  quantity: number;
  unit: string;
  expiration_date: string;
  status: 'available' | 'claimed' | 'completed' | 'expired';
  donor_id: string;
  donor_name: string;
  donor_phone?: string;
  donor_address?: string;
  recipient_name?: string;
  recipient_phone?: string;
  claimed_at?: string;
  created_at: string;
  pickup_instructions?: string;
  available_from?: string;
  available_until?: string;
  image_url?: string;
  volunteer_id?: string;
  volunteer_name?: string;
  volunteer_phone?: string;
  pickup_status?: 'pending' | 'assigned' | 'in_progress' | 'completed';
}

interface DonationContextType {
  donations: Donation[];
  userDonations: Donation[];
  availableDonations: Donation[];
  claimedDonations: Donation[];
  volunteerDeliveries: Donation[];
  loading: boolean;
  refreshDonations: () => void;
  createDonation: (donationData: any) => Promise<boolean>;
  updateDonationStatus: (donationId: string, status: string) => Promise<boolean>;
  claimDonation: (donationId: string) => Promise<boolean>;
  assignVolunteer: (donationId: string, volunteerId: string, volunteerName: string, volunteerPhone: string) => Promise<boolean>;
  updatePickupStatus: (donationId: string, status: string) => Promise<boolean>;
  // Real-time sync methods
  syncDonations: () => void;
  broadcastDonationUpdate: (donation: Donation, updateType: string) => void;
}

const DonationContext = createContext<DonationContextType | undefined>(undefined);

// Food category image mapping
const FOOD_CATEGORY_IMAGES = {
  'Bakery Items': 'https://images.unsplash.com/photo-1736520537688-1f1f06b71605?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGJyZWFkJTIwYmFrZXJ5JTIwaXRlbXN8ZW58MXx8fHwxNzU0MzAxMTk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'Prepared Meals': 'https://images.unsplash.com/photo-1665758483281-b4b59c5fd4c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVwYXJlZCUyMG1lYWxzJTIwcmVhZHklMjBmb29kJTIwY29udGFpbmVyc3xlbnwxfHx8fDE3NTQzMDEyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'Fresh Produce': 'https://images.unsplash.com/photo-1623125489492-6d3641414e37?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHZlZ2V0YWJsZXMlMjBmcnVpdHMlMjBvcmdhbmljJTIwcHJvZHVjZXxlbnwxfHx8fDE3NTQzMDExNTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'Dairy Products': 'https://images.unsplash.com/photo-1596151163116-98a5033814c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYWlyeSUyMG1pbGslMjBwYW5lZXIlMjBpbmRpYW4lMjBzd2VldHN8ZW58MXx8fHwxNzU0MzAxMTU5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'Canned Goods': 'https://images.unsplash.com/photo-1573628684838-e91b68dd77d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYWNrYWdlZCUyMGdyb2NlcmllcyUyMGZvb2QlMjBzdXBwbGllcyUyMGNhbm5lZCUyMGdvb2RzfGVufDF8fHx8MTc1NDMwMTE3Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
};

// Specific food item images
const SPECIFIC_FOOD_IMAGES = {
  'roti': 'https://images.unsplash.com/photo-1498654364264-5e856b6bb047?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHJvdGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGJyZWFkfGVufDF8fHx8MTc1NDMwMTE0MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'biryani': 'https://images.unsplash.com/photo-1615865417491-9941019fbc00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXJ5YW5pJTIwY3VycnklMjByaWNlJTIwaW5kaWFuJTIwbWVhbHxlbnwxfHx8fDE3NTQzMDExNDd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'idli': 'https://images.unsplash.com/photo-1586511926871-deb1aca37f38?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpZGxpJTIwZG9zYSUyMHNvdXRoJTIwaW5kaWFuJTIwYnJlYWtmYXN0fGVufDF8fHx8MTc1NDMwMTE2NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'thali': 'https://images.unsplash.com/photo-1573890607045-678f0f9d2cf0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0aGFsaSUyMHRyYWRpdGlvbmFsJTIwbWVhbCUyMHBsYXRlfGVufDF8fHx8MTc1NDMwMTE3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'samosa': 'https://images.unsplash.com/photo-1596467891524-0de83d341fd2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW1vc2ElMjBwYWtvcmElMjBpbmRpYW4lMjB0ZWElMjBzbmFja3N8ZW58MXx8fHwxNzU0MzAxMTg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
};

// Function to get appropriate image for donation
const getDonationImage = (title: string, food_type: string): string => {
  const titleLower = title.toLowerCase();
  
  // Check for specific food items first
  for (const [keyword, imageUrl] of Object.entries(SPECIFIC_FOOD_IMAGES)) {
    if (titleLower.includes(keyword)) {
      return imageUrl;
    }
  }
  
  // Fall back to category image
  return FOOD_CATEGORY_IMAGES[food_type as keyof typeof FOOD_CATEGORY_IMAGES] || 
         FOOD_CATEGORY_IMAGES['Prepared Meals'];
};

// Mock data with Khammam local restaurant names and realistic images
const MOCK_DONATIONS: Donation[] = [
  {
    id: '1',
    title: 'Fresh Rotis & Traditional Sweets',
    description: 'Daily surplus from our kitchen - fresh rotis, laddu, jalebi, and traditional sweets made with pure ghee',
    food_type: 'Bakery Items',
    quantity: 30,
    unit: 'pieces',
    expiration_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'available',
    donor_id: 'khammam-1',
    donor_name: 'Haveli Restaurant',
    donor_phone: '08742-234567',
    donor_address: 'Station Road, Khammam',
    created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    pickup_instructions: 'Available at kitchen entrance after 7 PM',
    image_url: getDonationImage('Fresh Rotis & Traditional Sweets', 'Bakery Items')
  },
  {
    id: '2',
    title: 'Biryani & Curry Meals',
    description: 'Freshly prepared vegetarian and non-vegetarian biryani with curry, raita, and pickles - perfect for dinner',
    food_type: 'Prepared Meals',
    quantity: 50,
    unit: 'servings',
    expiration_date: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'available',
    donor_id: 'khammam-2',
    donor_name: 'Annapurna Family Restaurant',
    donor_phone: '08742-345678',
    donor_address: 'Wyra Road, Khammam',
    created_at: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    pickup_instructions: 'Contact manager Ramesh at reception',
    image_url: getDonationImage('Biryani & Curry Meals', 'Prepared Meals')
  },
  {
    id: '3',
    title: 'Fresh Vegetables & Fruits',
    description: 'Daily fresh vegetables, seasonal fruits, and organic produce from local farmers - includes tomatoes, onions, potatoes, apples, bananas',
    food_type: 'Fresh Produce',
    quantity: 20,
    unit: 'kg',
    expiration_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'available',
    donor_id: 'khammam-3',
    donor_name: 'Reliance Fresh Grocery',
    donor_phone: '08742-456789',
    donor_address: 'Collectorate Road, Khammam',
    created_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    pickup_instructions: 'Available during store hours 8 AM - 9 PM',
    image_url: getDonationImage('Fresh Vegetables & Fruits', 'Fresh Produce')
  },
  {
    id: '4',
    title: 'Dairy Products & Sweets',
    description: 'Fresh milk, paneer, ghee, butter, and traditional sweets from local dairy - includes rasgulla, gulab jamun',
    food_type: 'Dairy Products',
    quantity: 25,
    unit: 'pieces',
    expiration_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'claimed',
    donor_id: 'khammam-4',
    donor_name: 'Sri Venkateswara Dairy & Sweets',
    donor_phone: '08742-567890',
    donor_address: 'Gandhi Chowk, Khammam',
    recipient_name: 'Balala Vikasa Kendra',
    recipient_phone: '08742-987654',
    claimed_at: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    created_at: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
    pickup_instructions: 'Side entrance, refrigerated section',
    image_url: getDonationImage('Dairy Products & Sweets', 'Dairy Products')
  },
  {
    id: '5',
    title: 'South Indian Breakfast Items',
    description: 'Idli, dosa, vada, upma, and sambar - traditional breakfast items with coconut chutney and sambar',
    food_type: 'Prepared Meals',
    quantity: 40,
    unit: 'servings',
    expiration_date: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'available',
    donor_id: 'khammam-5',
    donor_name: 'Udupi Krishna Hotel',
    donor_phone: '08742-678901',
    donor_address: 'Bus Stand Road, Khammam',
    created_at: new Date(Date.now() - 20 * 60 * 1000).toISOString(),
    pickup_instructions: 'Available after 11 AM, contact kitchen staff',
    image_url: getDonationImage('South Indian Breakfast Items', 'Prepared Meals')
  },
  {
    id: '6',
    title: 'Packaged Food & Groceries',
    description: 'Rice, dal, oil, spices, and packaged food items approaching expiry - includes wheat flour, cooking oil, lentils',
    food_type: 'Canned Goods',
    quantity: 60,
    unit: 'pieces',
    expiration_date: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'available',
    donor_id: 'khammam-6',
    donor_name: 'Big Bazaar Khammam',
    donor_phone: '08742-789012',
    donor_address: 'NSP Complex, Khammam',
    created_at: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    pickup_instructions: 'Customer service desk, weekdays 10 AM - 8 PM',
    image_url: getDonationImage('Packaged Food & Groceries', 'Canned Goods')
  },
  {
    id: '7',
    title: 'Traditional Thali Meals',
    description: 'Complete thali meals with rice, dal, vegetables, pickle, papad, and sweet - balanced nutrition for families',
    food_type: 'Prepared Meals',
    quantity: 35,
    unit: 'servings',
    expiration_date: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'available',
    donor_id: 'khammam-7',
    donor_name: 'Kakatiya Family Restaurant',
    donor_phone: '08742-890123',
    donor_address: 'Mamatha Nagar, Khammam',
    created_at: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    pickup_instructions: 'Main entrance, ask for Suresh',
    image_url: getDonationImage('Traditional Thali Meals', 'Prepared Meals')
  },
  {
    id: '8',
    title: 'Tea Snacks & Samosas',
    description: 'Evening tea snacks - crispy samosas, pakoras, biscuits, and traditional sweets perfect for evening meals',
    food_type: 'Bakery Items',
    quantity: 50,
    unit: 'pieces',
    expiration_date: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'available',
    donor_id: 'khammam-8',
    donor_name: 'Raghavendra Tea Stall & Snacks',
    donor_phone: '08742-901234',
    donor_address: 'Railway Station Area, Khammam',
    created_at: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    pickup_instructions: 'Evening after 6 PM',
    image_url: getDonationImage('Tea Snacks & Samosas', 'Bakery Items')
  }
];

export function DonationProvider({ children }: { children: React.ReactNode }) {
  const [donations, setDonations] = useState<Donation[]>(MOCK_DONATIONS);
  const [loading, setLoading] = useState(false);
  const { user, profile } = useAuth();

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly update donation statuses or add new donations
      setDonations(prev => {
        const updated = [...prev];
        
        // Sometimes add a new donation from Khammam restaurants
        if (Math.random() < 0.1) {
          const khammamRestaurants = [
            'Haveli Restaurant', 'Annapurna Family Restaurant', 'Reliance Fresh Grocery',
            'Sri Venkateswara Dairy & Sweets', 'Udupi Krishna Hotel', 'Big Bazaar Khammam',
            'Kakatiya Family Restaurant', 'Raghavendra Tea Stall & Snacks'
          ];
          const randomRestaurant = khammamRestaurants[Math.floor(Math.random() * khammamRestaurants.length)];
          
          const newDonationTitles = [
            'Fresh Chapati & Curry',
            'Vegetable Pulao & Raita', 
            'Mixed Vegetable Curry',
            'Dal & Rice Combo',
            'Fresh Fruit Salad'
          ];
          const randomTitle = newDonationTitles[Math.floor(Math.random() * newDonationTitles.length)];
          const randomFoodType = ['Prepared Meals', 'Fresh Produce', 'Bakery Items'][Math.floor(Math.random() * 3)];
          
          const newDonation: Donation = {
            id: `new-${Date.now()}`,
            title: randomTitle,
            description: 'Newly posted donation from local Khammam business',
            food_type: randomFoodType,
            quantity: Math.floor(Math.random() * 20) + 5,
            unit: 'kg',
            expiration_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
            status: 'available',
            donor_id: `khammam-${Math.floor(Math.random() * 10)}`,
            donor_name: randomRestaurant,
            donor_phone: '08742-111222',
            donor_address: 'Khammam, Telangana',
            created_at: new Date().toISOString(),
            pickup_instructions: 'Contact for pickup details',
            image_url: getDonationImage(randomTitle, randomFoodType)
          };
          updated.unshift(newDonation);
        }

        // Sometimes update existing donations
        updated.forEach(donation => {
          if (donation.status === 'available' && Math.random() < 0.05) {
            donation.status = 'claimed';
            donation.claimed_at = new Date().toISOString();
            donation.recipient_name = 'Local Orphanage';
          }
        });

        return updated.slice(0, 20); // Keep only latest 20
      });
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const refreshDonations = useCallback(() => {
    setLoading(true);
    // Simulate API call delay
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  const createDonation = useCallback(async (donationData: any): Promise<boolean> => {
    if (!user || !profile) return false;

    const newDonation: Donation = {
      id: `donation-${Date.now()}`,
      ...donationData,
      donor_id: user.id,
      donor_name: profile.organization_name,
      donor_phone: profile.phone,
      donor_address: profile.address,
      status: 'available',
      created_at: new Date().toISOString(),
      image_url: getDonationImage(donationData.title, donationData.food_type)
    };

    setDonations(prev => [newDonation, ...prev]);
    return true;
  }, [user, profile]);

  const updateDonationStatus = useCallback(async (donationId: string, status: string): Promise<boolean> => {
    setDonations(prev => prev.map(donation => 
      donation.id === donationId 
        ? { ...donation, status: status as any }
        : donation
    ));
    return true;
  }, []);

  const claimDonation = useCallback(async (donationId: string): Promise<boolean> => {
    if (!user || !profile) return false;

    setDonations(prev => prev.map(donation => 
      donation.id === donationId 
        ? { 
            ...donation, 
            status: 'claimed', 
            claimed_at: new Date().toISOString(),
            recipient_name: profile.organization_name,
            recipient_phone: profile.phone
          }
        : donation
    ));
    return true;
  }, [user, profile]);

  const assignVolunteer = useCallback(async (donationId: string, volunteerId: string, volunteerName: string, volunteerPhone: string): Promise<boolean> => {
    if (!user || !profile) return false;

    setDonations(prev => prev.map(donation => 
      donation.id === donationId 
        ? { 
            ...donation, 
            volunteer_id: volunteerId,
            volunteer_name: volunteerName,
            volunteer_phone: volunteerPhone,
            pickup_status: 'assigned'
          }
        : donation
    ));
    return true;
  }, [user, profile]);

  const updatePickupStatus = useCallback(async (donationId: string, status: string): Promise<boolean> => {
    setDonations(prev => prev.map(donation => 
      donation.id === donationId 
        ? { 
            ...donation, 
            pickup_status: status as any
          }
        : donation
    ));
    return true;
  }, []);

  // Real-time sync methods
  const syncDonations = useCallback(() => {
    // Simulate syncing with backend
    console.log('Syncing donations...');
  }, []);

  const broadcastDonationUpdate = useCallback((donation: Donation, updateType: string) => {
    // Simulate broadcasting update to connected clients
    console.log(`Broadcasting donation update: ${updateType}`, donation);
  }, []);

  const userDonations = donations.filter(d => d.donor_id === user?.id);
  const availableDonations = donations.filter(d => d.status === 'available' && d.donor_id !== user?.id);
  const claimedDonations = donations.filter(d => d.status === 'claimed');
  const volunteerDeliveries = donations.filter(d => d.pickup_status === 'assigned');

  return (
    <DonationContext.Provider value={{
      donations,
      userDonations,
      availableDonations,
      claimedDonations,
      volunteerDeliveries,
      loading,
      refreshDonations,
      createDonation,
      updateDonationStatus,
      claimDonation,
      assignVolunteer,
      updatePickupStatus,
      // Real-time sync methods
      syncDonations,
      broadcastDonationUpdate
    }}>
      {children}
    </DonationContext.Provider>
  );
}

export function useDonations() {
  const context = useContext(DonationContext);
  if (context === undefined) {
    throw new Error('useDonations must be used within a DonationProvider');
  }
  return context;
}