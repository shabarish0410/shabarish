import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { useDonations } from './DonationContext';

interface Notification {
  id: string;
  type: 'donation_posted' | 'donation_claimed' | 'pickup_requested' | 'delivery_update' | 'route_request';
  title: string;
  message: string;
  data: any;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  timestamp: string;
  read: boolean;
  targetUserType?: 'donor' | 'recipient' | 'volunteer' | 'all';
  sourceUserId?: string;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  removeNotification: (notificationId: string) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { user, profile } = useAuth();
  const { donations } = useDonations();

  const addNotification = useCallback((notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      read: false,
    };

    setNotifications(prev => [newNotification, ...prev.slice(0, 49)]); // Keep only latest 50 notifications
  }, []);

  const markAsRead = useCallback((notificationId: string) => {
    setNotifications(prev => prev.map(notif => 
      notif.id === notificationId ? { ...notif, read: true } : notif
    ));
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(notif => ({ ...notif, read: true })));
  }, []);

  const removeNotification = useCallback((notificationId: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== notificationId));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // Listen for donation changes and create notifications
  useEffect(() => {
    if (!user || !profile) return;

    const checkDonationChanges = () => {
      donations.forEach(donation => {
        // New donation posted - notify recipients and volunteers
        if (donation.status === 'available' && profile.organization_type !== 'donor') {
          const existingNotif = notifications.find(n => 
            n.data?.donationId === donation.id && n.type === 'donation_posted'
          );
          
          if (!existingNotif && donation.donor_id !== user.id) {
            addNotification({
              type: 'donation_posted',
              title: '🍽️ New Food Donation Available',
              message: `${donation.donor_name} has posted "${donation.title}" - ${donation.quantity} ${donation.unit}`,
              data: { 
                donationId: donation.id,
                donorName: donation.donor_name,
                title: donation.title,
                quantity: donation.quantity,
                unit: donation.unit,
                expirationDate: donation.expiration_date
              },
              priority: new Date(donation.expiration_date).getTime() - Date.now() < 6 * 60 * 60 * 1000 ? 'urgent' : 'medium',
              targetUserType: profile.organization_type === 'recipient' ? 'recipient' : 'volunteer',
              sourceUserId: donation.donor_id
            });
          }
        }

        // Donation claimed - notify volunteers and donors
        if (donation.status === 'claimed' && donation.claimed_at) {
          const existingNotif = notifications.find(n => 
            n.data?.donationId === donation.id && n.type === 'donation_claimed'
          );

          if (!existingNotif) {
            if (profile.organization_type === 'volunteer') {
              addNotification({
                type: 'donation_claimed',
                title: '🚚 Pickup Request Available',
                message: `${donation.recipient_name || 'An orphanage'} claimed "${donation.title}" from ${donation.donor_name}. Volunteer needed for pickup!`,
                data: {
                  donationId: donation.id,
                  donorName: donation.donor_name,
                  recipientName: donation.recipient_name,
                  donorAddress: donation.donor_address,
                  donorPhone: donation.donor_phone,
                  recipientPhone: donation.recipient_phone,
                  title: donation.title,
                  quantity: donation.quantity,
                  unit: donation.unit
                },
                priority: 'high',
                targetUserType: 'volunteer'
              });
            } else if (profile.organization_type === 'donor' && donation.donor_id === user.id) {
              addNotification({
                type: 'donation_claimed',
                title: '✅ Your Donation Was Claimed',
                message: `${donation.recipient_name || 'An orphanage'} claimed your "${donation.title}". They will contact you soon for pickup coordination.`,
                data: {
                  donationId: donation.id,
                  recipientName: donation.recipient_name,
                  recipientPhone: donation.recipient_phone,
                  title: donation.title
                },
                priority: 'medium',
                targetUserType: 'donor'
              });
            }
          }
        }
      });
    };

    checkDonationChanges();
  }, [donations, user, profile, addNotification, notifications]);

  // Simulate real-time notifications from other user types
  useEffect(() => {
    if (!user || !profile) return;

    const interval = setInterval(() => {
      const shouldNotify = Math.random() < 0.15; // 15% chance every 30 seconds
      if (shouldNotify) {
        if (profile.organization_type === 'volunteer') {
          // Simulate pickup requests for volunteers
          const pickupRequests = [
            {
              donor: 'Haveli Restaurant',
              recipient: 'Balala Vikasa Kendra',
              address: 'Station Road, Khammam',
              items: 'Fresh Biryani & Sweets'
            },
            {
              donor: 'Reliance Fresh Grocery',
              recipient: 'Sri Venkateswara Orphanage',
              address: 'Collectorate Road, Khammam',
              items: 'Fresh Vegetables & Fruits'
            }
          ];
          const randomRequest = pickupRequests[Math.floor(Math.random() * pickupRequests.length)];
          
          addNotification({
            type: 'pickup_requested',
            title: '🚚 New Pickup Request',
            message: `${randomRequest.recipient} needs pickup from ${randomRequest.donor} - ${randomRequest.items}`,
            data: randomRequest,
            priority: Math.random() < 0.3 ? 'urgent' : 'high',
            targetUserType: 'volunteer'
          });
        } else if (profile.organization_type === 'recipient') {
          // Simulate delivery updates for recipients
          const deliveryUpdates = [
            'Your volunteer driver is 5 minutes away with fresh food delivery',
            'Pickup completed - food is on the way to your location',
            'New urgent donation available - expires in 2 hours'
          ];
          const randomUpdate = deliveryUpdates[Math.floor(Math.random() * deliveryUpdates.length)];
          
          addNotification({
            type: 'delivery_update',
            title: '📍 Delivery Update',
            message: randomUpdate,
            data: { updateType: 'live_tracking' },
            priority: randomUpdate.includes('urgent') ? 'urgent' : 'medium',
            targetUserType: 'recipient'
          });
        } else if (profile.organization_type === 'donor') {
          // Simulate claim notifications for donors
          const claimUpdates = [
            'Your biryani donation was just claimed by Balala Vikasa Kendra',
            'Volunteer driver accepted pickup for your fresh vegetables',
            'Thank you! Your donation fed 35 children today'
          ];
          const randomClaim = claimUpdates[Math.floor(Math.random() * claimUpdates.length)];
          
          addNotification({
            type: 'donation_claimed',
            title: '❤️ Donation Impact',
            message: randomClaim,
            data: { impactType: 'claim_update' },
            priority: 'medium',
            targetUserType: 'donor'
          });
        }
      }
    }, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, [user, profile, addNotification]);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      addNotification,
      markAsRead,
      markAllAsRead,
      removeNotification,
      clearAll
    }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}