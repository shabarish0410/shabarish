import React, { createContext, useContext, useEffect, useState } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
}

interface Profile {
  id: string;
  user_id: string;
  organization_name: string;
  organization_type: 'donor' | 'recipient' | 'volunteer';
  contact_person: string;
  phone: string;
  address: string;
  description?: string;
  children_count?: number;
  established_year?: string;
  vehicle_type?: string;
  availability_hours?: string;
}

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean; redirectTo?: string }>;
  signUp: (userData: any) => Promise<boolean>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock data with Khammam organizations
const MOCK_USERS = [
  {
    id: 'demo-restaurant-1',
    email: 'demo@restaurant.com',
    password: 'demo123',
    name: 'Restaurant Manager',
    profile: {
      id: 'profile-1',
      user_id: 'demo-restaurant-1',
      organization_name: 'Haveli Restaurant',
      organization_type: 'donor' as const,
      contact_person: 'Rajesh Kumar',
      phone: '08742-234567',
      address: 'Station Road, Near Bus Stand, Khammam, Telangana 507001',
      description: 'Traditional Indian cuisine restaurant serving authentic Telangana dishes since 1995.',
      established_year: '1995'
    }
  },
  {
    id: 'demo-orphanage-1', 
    email: 'demo@orphanage.com',
    password: 'demo123',
    name: 'Orphanage Manager',
    profile: {
      id: 'profile-2',
      user_id: 'demo-orphanage-1',
      organization_name: 'Balala Vikasa Kendra',
      organization_type: 'recipient' as const,
      contact_person: 'Lakshmi Devi',
      phone: '08742-987654',
      address: 'Mamatha Nagar, Behind Govt School, Khammam, Telangana 507001',
      description: 'A caring home for 45 children aged 3-16, providing education, healthcare, and nutritious meals.',
      children_count: 45,
      established_year: '2010'
    }
  },
  {
    id: 'demo-grocery-1',
    email: 'demo@grocery.com', 
    password: 'demo123',
    name: 'Store Manager',
    profile: {
      id: 'profile-3',
      user_id: 'demo-grocery-1',
      organization_name: 'Reliance Fresh Grocery',
      organization_type: 'donor' as const,
      contact_person: 'Venkat Rao',
      phone: '08742-456789',
      address: 'Collectorate Road, Near Govt Hospital, Khammam, Telangana 507001',
      description: 'Modern grocery store providing fresh produce and daily essentials to Khammam residents.',
      established_year: '2018'
    }
  },
  {
    id: 'demo-volunteer-1',
    email: 'demo@volunteer.com',
    password: 'demo123',
    name: 'Volunteer Driver',
    profile: {
      id: 'profile-4',
      user_id: 'demo-volunteer-1',
      organization_name: 'FoodBridge Delivery Services',
      organization_type: 'volunteer' as const,
      contact_person: 'Anil Reddy',
      phone: '08742-345678',
      address: 'Gandhi Nagar, Near Water Tank, Khammam, Telangana 507001',
      description: 'Dedicated volunteer driver helping deliver food donations across Khammam with 3+ years experience.',
      vehicle_type: 'Two Wheeler (Motorcycle)',
      availability_hours: '9:00 AM - 6:00 PM'
    }
  }
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem('foodbridge_user');
    const savedProfile = localStorage.getItem('foodbridge_profile');
    
    if (savedUser && savedProfile) {
      setUser(JSON.parse(savedUser));
      setProfile(JSON.parse(savedProfile));
    }
    
    setLoading(false);
  }, []);

  const signIn = async (email: string, password: string): Promise<{ success: boolean; redirectTo?: string }> => {
    setLoading(true);
    
    try {
      // Find matching user
      const mockUser = MOCK_USERS.find(u => u.email === email && u.password === password);
      
      if (mockUser) {
        const userData = {
          id: mockUser.id,
          email: mockUser.email,
          name: mockUser.name
        };
        
        setUser(userData);
        setProfile(mockUser.profile);
        
        // Save to localStorage
        localStorage.setItem('foodbridge_user', JSON.stringify(userData));
        localStorage.setItem('foodbridge_profile', JSON.stringify(mockUser.profile));
        
        // Determine redirect based on organization type
        let redirectTo: string;
        if (mockUser.profile.organization_type === 'donor') {
          redirectTo = 'restaurant-dashboard';
        } else if (mockUser.profile.organization_type === 'volunteer') {
          redirectTo = 'volunteer-dashboard';
        } else {
          redirectTo = 'orphanage-dashboard';
        }
        
        setLoading(false);
        return { success: true, redirectTo };
      } else {
        setLoading(false);
        return { success: false };
      }
    } catch (error) {
      console.error('Sign in error:', error);
      setLoading(false);
      return { success: false };
    }
  };

  const signUp = async (userData: any): Promise<boolean> => {
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const newUser = {
        id: `user-${Date.now()}`,
        email: userData.email,
        name: userData.contact_person
      };
      
      const newProfile = {
        id: `profile-${Date.now()}`,
        user_id: newUser.id,
        organization_name: userData.organization_name,
        organization_type: userData.organization_type,
        contact_person: userData.contact_person,
        phone: userData.phone,
        address: userData.address,
        description: userData.description,
        children_count: userData.children_count,
        established_year: userData.established_year,
        vehicle_type: userData.vehicle_type,
        availability_hours: userData.availability_hours
      };
      
      setUser(newUser);
      setProfile(newProfile);
      
      // Save to localStorage
      localStorage.setItem('foodbridge_user', JSON.stringify(newUser));
      localStorage.setItem('foodbridge_profile', JSON.stringify(newProfile));
      
      setLoading(false);
      return true;
    } catch (error) {
      console.error('Sign up error:', error);
      setLoading(false);
      return false;
    }
  };

  const signOut = async (): Promise<void> => {
    setUser(null);
    setProfile(null);
    localStorage.removeItem('foodbridge_user');
    localStorage.removeItem('foodbridge_profile');
  };

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      loading,
      signIn,
      signUp,
      signOut
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}