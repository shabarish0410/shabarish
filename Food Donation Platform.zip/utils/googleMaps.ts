/**
 * Google Maps integration utilities for live tracking and navigation
 */

interface LocationCoords {
  lat: number;
  lng: number;
}

interface DeliveryRoute {
  origin: string;
  destination: string;
  waypoints?: string[];
}

/**
 * Opens Google Maps with live navigation to destination
 */
export function openGoogleMapsNavigation(destination: string, origin?: string) {
  const baseUrl = 'https://www.google.com/maps/dir/';
  const params = new URLSearchParams();
  
  // Set destination
  params.set('api', '1');
  params.set('destination', destination);
  params.set('travelmode', 'driving');
  params.set('dir_action', 'navigate');
  
  // Set origin if provided
  if (origin) {
    params.set('origin', origin);
  }
  
  const mapsUrl = `${baseUrl}?${params.toString()}`;
  window.open(mapsUrl, '_blank');
}

/**
 * Opens Google Maps with a specific route for delivery tracking
 */
export function openDeliveryRoute(route: DeliveryRoute) {
  const baseUrl = 'https://www.google.com/maps/dir/';
  let url = baseUrl;
  
  // Add origin
  url += encodeURIComponent(route.origin) + '/';
  
  // Add waypoints if any
  if (route.waypoints && route.waypoints.length > 0) {
    route.waypoints.forEach(waypoint => {
      url += encodeURIComponent(waypoint) + '/';
    });
  }
  
  // Add destination
  url += encodeURIComponent(route.destination);
  
  // Add parameters
  const params = new URLSearchParams();
  params.set('travelmode', 'driving');
  params.set('dir_action', 'navigate');
  
  const finalUrl = `${url}?${params.toString()}`;
  window.open(finalUrl, '_blank');
}

/**
 * Creates a shareable Google Maps link for live tracking
 */
export function createShareableTrackingLink(destination: string): string {
  const params = new URLSearchParams();
  params.set('api', '1');
  params.set('destination', encodeURIComponent(destination));
  params.set('travelmode', 'driving');
  
  return `https://www.google.com/maps/dir/?${params.toString()}`;
}

/**
 * Opens Google Maps showing a location with live tracking capabilities
 */
export function openLocationWithTracking(coords: LocationCoords, title: string) {
  const params = new URLSearchParams();
  params.set('api', '1');
  params.set('query', `${coords.lat},${coords.lng}`);
  params.set('query_place_id', title);
  
  const mapsUrl = `https://www.google.com/maps/search/?${params.toString()}`;
  window.open(mapsUrl, '_blank');
}

/**
 * Estimates travel time between two locations (simplified)
 */
export function estimateTravelTime(origin: LocationCoords, destination: LocationCoords): number {
  // Simple haversine distance calculation
  const R = 6371; // Earth's radius in kilometers
  const dLat = (destination.lat - origin.lat) * Math.PI / 180;
  const dLon = (destination.lng - origin.lng) * Math.PI / 180;
  
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(origin.lat * Math.PI / 180) * Math.cos(destination.lat * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c; // Distance in km
  
  // Assume average city driving speed of 25 km/h with traffic
  const averageSpeed = 25;
  const estimatedMinutes = (distance / averageSpeed) * 60;
  
  return Math.round(estimatedMinutes);
}

/**
 * Gets the current user's location for navigation
 */
export function getCurrentLocation(): Promise<LocationCoords> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported'));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
      },
      (error) => {
        reject(error);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  });
}

/**
 * Khammam-specific locations for testing and demonstration
 */
export const KHAMMAM_LOCATIONS = {
  restaurants: {
    haveli: {
      name: "Haveli Restaurant",
      address: "Station Road, Khammam, Telangana 507001",
      coords: { lat: 17.2473, lng: 80.1514 }
    },
    minerva: {
      name: "Minerva Grand Hotel",
      address: "Collectorate Road, Khammam, Telangana",
      coords: { lat: 17.2456, lng: 80.1523 }
    },
    udupi: {
      name: "Udupi Bhavan",
      address: "Bus Stand Road, Khammam, Telangana",
      coords: { lat: 17.2481, lng: 80.1508 }
    }
  },
  orphanages: {
    balala: {
      name: "Balala Vikasa Kendra Orphanage",
      address: "Wyra Road, Khammam, Telangana 507002",
      coords: { lat: 17.2373, lng: 80.1614 }
    },
    littleAngels: {
      name: "Little Angels Children Home",
      address: "Kothagudem Road, Khammam, Telangana",
      coords: { lat: 17.2391, lng: 80.1597 }
    },
    sriSai: {
      name: "Sri Sai Orphanage",
      address: "Madhira Road, Khammam, Telangana",
      coords: { lat: 17.2421, lng: 80.1582 }
    }
  },
  landmarks: {
    ktrCircle: {
      name: "KTR Circle",
      address: "KTR Circle, Khammam, Telangana",
      coords: { lat: 17.2465, lng: 80.1535 }
    },
    busStand: {
      name: "Khammam Bus Stand",
      address: "Bus Stand Road, Khammam, Telangana",
      coords: { lat: 17.2478, lng: 80.1501 }
    },
    railwayStation: {
      name: "Khammam Railway Station",
      address: "Station Road, Khammam, Telangana",
      coords: { lat: 17.2469, lng: 80.1511 }
    }
  }
};