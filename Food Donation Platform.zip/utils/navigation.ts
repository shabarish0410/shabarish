/**
 * Navigation utilities for handling external links properly
 */

import { 
  openGoogleMapsNavigation, 
  openDeliveryRoute, 
  createShareableTrackingLink,
  KHAMMAM_LOCATIONS
} from './googleMaps';

export const openGoogleMaps = (address: string) => {
  const encodedAddress = encodeURIComponent(address);
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`;
  window.open(mapsUrl, '_blank');
};

export const openDirections = (destination: string | [number, number], travelMode: 'driving' | 'walking' | 'transit' = 'driving') => {
  let mapsUrl: string;
  
  if (typeof destination === 'string') {
    const encodedAddress = encodeURIComponent(destination);
    mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}&travelmode=${travelMode}&dir_action=navigate`;
  } else {
    const [lat, lng] = destination;
    mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=${travelMode}&dir_action=navigate`;
  }
  
  window.open(mapsUrl, '_blank');
};

export const openDirectionsWithWaypoints = (
  destination: string, 
  waypoints: string[] = [], 
  travelMode: 'driving' | 'walking' | 'transit' = 'driving'
) => {
  const encodedDestination = encodeURIComponent(destination);
  let mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodedDestination}&travelmode=${travelMode}&dir_action=navigate`;
  
  if (waypoints.length > 0) {
    const encodedWaypoints = waypoints.map(wp => encodeURIComponent(wp)).join('|');
    mapsUrl += `&waypoints=${encodedWaypoints}`;
  }
  
  window.open(mapsUrl, '_blank');
};

/**
 * Opens Google Maps with live navigation for delivery tracking
 */
export const openLiveNavigation = (destination: string, origin?: string) => {
  openGoogleMapsNavigation(destination, origin);
};

/**
 * Opens Google Maps with a complete delivery route from restaurant to orphanage
 */
export const openDeliveryTracking = (restaurantAddress: string, orphanageAddress: string) => {
  openDeliveryRoute({
    origin: restaurantAddress,
    destination: orphanageAddress,
    waypoints: ['KTR Circle, Khammam'] // Optional intermediate point
  });
};

/**
 * Creates a shareable live tracking link for deliveries
 */
export const shareDeliveryTracking = (destination: string): string => {
  return createShareableTrackingLink(destination);
};

/**
 * Opens Google Maps with optimized route for multiple pickup locations
 */
export const openMultiStopRoute = (pickupLocations: string[], finalDestination: string) => {
  if (pickupLocations.length === 0) {
    openDirections(finalDestination);
    return;
  }
  
  if (pickupLocations.length === 1) {
    openDeliveryRoute({
      origin: pickupLocations[0],
      destination: finalDestination
    });
    return;
  }
  
  // For multiple stops, use the first as origin and others as waypoints
  const [origin, ...waypoints] = pickupLocations;
  openDeliveryRoute({
    origin,
    destination: finalDestination,
    waypoints
  });
};

export const makePhoneCall = (phoneNumber: string) => {
  // Clean phone number - remove all non-digit characters except +
  const cleanNumber = phoneNumber.replace(/[^\d+]/g, '');
  window.open(`tel:${cleanNumber}`, '_self');
};

export const sendSMS = (phoneNumber: string, message?: string) => {
  const cleanNumber = phoneNumber.replace(/[^\d+]/g, '');
  const encodedMessage = message ? encodeURIComponent(message) : '';
  const smsUrl = `sms:${cleanNumber}${message ? `?body=${encodedMessage}` : ''}`;
  window.open(smsUrl, '_self');
};

/**
 * Opens WhatsApp chat with a phone number
 */
export const openWhatsApp = (phoneNumber: string, message?: string) => {
  const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
  const encodedMessage = message ? encodeURIComponent(message) : '';
  const whatsappUrl = `https://wa.me/${cleanNumber}${message ? `?text=${encodedMessage}` : ''}`;
  window.open(whatsappUrl, '_blank');
};

/**
 * Get common Khammam locations for quick access
 */
export const getKhammamLocations = () => {
  return KHAMMAM_LOCATIONS;
};

// Export Google Maps utilities for direct use
export { 
  openGoogleMapsNavigation, 
  openDeliveryRoute, 
  createShareableTrackingLink 
} from './googleMaps';