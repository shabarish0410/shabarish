import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useDonations } from '../contexts/DonationContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Plus, 
  Package, 
  Heart, 
  MessageSquare, 
  Clock, 
  MapPin, 
  Phone, 
  RefreshCw,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Eye
} from 'lucide-react';
import { DonationForm } from './DonationForm';
import { RequestForm } from './RequestForm';
import { OrganizationProfile } from './OrganizationProfile';

interface DashboardProps {
  onNavigate?: (page: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { user, profile } = useAuth();
  const { 
    donations, 
    userDonations, 
    availableDonations, 
    loading,
    refreshDonations,
    createDonation,
    updateDonationStatus,
    claimDonation
  } = useDonations();
  
  const [showDonationForm, setShowDonationForm] = useState(false);
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [selectedOrgId, setSelectedOrgId] = useState<string | null>(null);
  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());
  const [recentActivity, setRecentActivity] = useState<string[]>([]);

  // Real-time activity tracking
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdateTime(new Date());
      
      // Simulate real-time notifications
      if (Math.random() < 0.1) {
        const activities = [
          'New donation posted by Local Bakery',
          'Your donation was claimed by Hope Haven',
          'Fresh produce available nearby',
          'Urgent request posted for children\'s meals'
        ];
        const newActivity = activities[Math.floor(Math.random() * activities.length)];
        setRecentActivity(prev => [newActivity, ...prev.slice(0, 4)]);
      }
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const handleCreateDonation = async (donationData: any) => {
    const success = await createDonation(donationData);
    if (success) {
      setShowDonationForm(false);
      setRecentActivity(prev => ['Successfully posted new donation!', ...prev.slice(0, 4)]);
    }
    return success;
  };

  const handleClaimDonation = async (donationId: string) => {
    const success = await claimDonation(donationId);
    if (success) {
      setRecentActivity(prev => ['Successfully claimed donation!', ...prev.slice(0, 4)]);
    }
  };

  const handleUpdateStatus = async (donationId: string, status: string) => {
    const success = await updateDonationStatus(donationId, status);
    if (success) {
      setRecentActivity(prev => [`Donation status updated to ${status}`, ...prev.slice(0, 4)]);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-800';
      case 'claimed': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      case 'expired': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const isDonor = profile?.organization_type === 'donor';
  const stats = isDonor ? {
    total: userDonations.length,
    available: userDonations.filter(d => d.status === 'available').length,
    completed: userDonations.filter(d => d.status === 'completed').length,
    thisMonth: userDonations.filter(d => {
      const donationDate = new Date(d.created_at);
      const thisMonth = new Date();
      return donationDate.getMonth() === thisMonth.getMonth();
    }).length
  } : {
    total: availableDonations.length,
    claimed: availableDonations.filter(d => d.status === 'claimed').length,
    available: availableDonations.filter(d => d.status === 'available').length,
    thisMonth: 12 // Mock data
  };

  if (!user || !profile) {
    return null;
  }

  if (selectedOrgId) {
    return (
      <OrganizationProfile 
        organizationId={selectedOrgId}
        onClose={() => setSelectedOrgId(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {isDonor ? 'Donor Dashboard' : 'Recipient Dashboard'}
              </h1>
              <p className="text-gray-600 mt-2">
                Manage your {isDonor ? 'donations' : 'requests'} and connect with organizations
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-sm text-gray-500">
                Last updated: {lastUpdateTime.toLocaleTimeString()}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={refreshDonations}
                disabled={loading}
                className="gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>

          {/* Real-time Activity Feed */}
          {recentActivity.length > 0 && (
            <Alert className="mt-4 border-green-200 bg-green-50">
              <AlertCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                <div className="font-medium mb-1">Recent Activity:</div>
                <div className="text-sm space-y-1">
                  {recentActivity.slice(0, 2).map((activity, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3" />
                      {activity}
                    </div>
                  ))}
                </div>
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Enhanced Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600">
                    {isDonor ? 'Total Donations' : 'Available Donations'}
                  </p>
                  <p className="text-3xl font-bold text-blue-700">{stats.total}</p>
                  <p className="text-xs text-blue-600 mt-1">
                    {isDonor ? '+3 this week' : 'Updated 5 min ago'}
                  </p>
                </div>
                <Package className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-600">
                    {isDonor ? 'Available Now' : 'This Month'}
                  </p>
                  <p className="text-3xl font-bold text-green-700">
                    {isDonor ? stats.available : stats.thisMonth}
                  </p>
                  <p className="text-xs text-green-600 mt-1">
                    {isDonor ? 'Ready for pickup' : 'Meals received'}
                  </p>
                </div>
                <Heart className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-600">
                    {isDonor ? 'Completed' : 'Claimed'}
                  </p>
                  <p className="text-3xl font-bold text-purple-700">
                    {isDonor ? stats.completed : stats.claimed}
                  </p>
                  <p className="text-xs text-purple-600 mt-1">
                    {isDonor ? 'Successful handoffs' : 'Pending pickup'}
                  </p>
                </div>
                <MessageSquare className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-orange-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-600">Impact Score</p>
                  <p className="text-3xl font-bold text-orange-700">
                    {isDonor ? '94%' : '87%'}
                  </p>
                  <p className="text-xs text-orange-600 mt-1">Community rating</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Monthly Progress */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Monthly Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>{isDonor ? 'Donations Goal' : 'Requests Goal'}</span>
                  <span>{isDonor ? '15/20' : '8/10'}</span>
                </div>
                <Progress value={isDonor ? 75 : 80} className="h-3" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>{isDonor ? 'Meals Provided' : 'Children Fed Daily'}</span>
                  <span>{isDonor ? '450/500' : '45/45'}</span>
                </div>
                <Progress value={isDonor ? 90 : 100} className="h-3" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs defaultValue="manage" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-3">
            <TabsTrigger value="manage">
              Manage {isDonor ? 'Donations' : 'Requests'}
            </TabsTrigger>
            <TabsTrigger value="browse">
              Browse {isDonor ? 'Requests' : 'Donations'}
            </TabsTrigger>
            <TabsTrigger value="insights" className="hidden lg:flex">
              Insights
            </TabsTrigger>
          </TabsList>

          {/* Manage Tab */}
          <TabsContent value="manage" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">
                Your {isDonor ? 'Donations' : 'Requests'}
              </h2>
              <Button 
                onClick={() => {
                  if (isDonor) {
                    setShowDonationForm(true);
                  } else {
                    setShowRequestForm(true);
                  }
                }}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
              >
                <Plus className="h-4 w-4" />
                Add {isDonor ? 'Donation' : 'Request'}
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {(isDonor ? userDonations : availableDonations).map((item) => (
                <Card key={item.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                      <Badge className={getStatusColor(item.status)}>
                        {item.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4 line-clamp-2">{item.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Food Type:</span>
                        <span>{item.food_type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Quantity:</span>
                        <span>{item.quantity} {item.unit}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Expires:</span>
                        <span>{new Date(item.expiration_date).toLocaleDateString()}</span>
                      </div>
                      {!isDonor && (
                        <div className="flex justify-between">
                          <span className="text-gray-500">From:</span>
                          <button
                            onClick={() => setSelectedOrgId(item.donor_id)}
                            className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                          >
                            {item.donor_name}
                            <Eye className="h-3 w-3" />
                          </button>
                        </div>
                      )}
                      {item.status === 'claimed' && item.recipient_name && (
                        <div className="pt-2 border-t">
                          <p className="text-sm font-medium text-green-600">
                            Claimed by: {item.recipient_name}
                          </p>
                          {item.recipient_phone && (
                            <p className="text-sm text-gray-500">
                              <Phone className="inline h-3 w-3 mr-1" />
                              {item.recipient_phone}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="mt-4 flex gap-2">
                      {isDonor ? (
                        <>
                          {item.status === 'claimed' && (
                            <Button 
                              size="sm" 
                              onClick={() => handleUpdateStatus(item.id, 'completed')}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              Mark Complete
                            </Button>
                          )}
                          {item.status === 'available' && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleUpdateStatus(item.id, 'expired')}
                            >
                              Mark Expired
                            </Button>
                          )}
                        </>
                      ) : (
                        <Button 
                          size="sm" 
                          onClick={() => handleClaimDonation(item.id)}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                          disabled={item.status !== 'available'}
                        >
                          {item.status === 'available' ? 'Claim Donation' : 'Already Claimed'}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Browse Tab */}
          <TabsContent value="browse" className="space-y-6">
            <h2 className="text-xl font-semibold">
              Available {isDonor ? 'Requests' : 'Donations'}
            </h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {(isDonor ? [] : availableDonations).map((donation) => (
                <Card key={donation.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{donation.title}</CardTitle>
                      <Badge className={getStatusColor(donation.status)}>
                        {donation.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{donation.description}</p>
                    <div className="space-y-2 text-sm mb-4">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Organization:</span>
                        <button
                          onClick={() => setSelectedOrgId(donation.donor_id)}
                          className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                        >
                          {donation.donor_name}
                          <Eye className="h-3 w-3" />
                        </button>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Food Type:</span>
                        <span>{donation.food_type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Quantity:</span>
                        <span>{donation.quantity} {donation.unit}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Expires:</span>
                        <span>{new Date(donation.expiration_date).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => handleClaimDonation(donation.id)}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                        disabled={donation.status !== 'available'}
                      >
                        Claim Donation
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => alert('Opening conversation...')}
                      >
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Impact Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
                      <div className="text-3xl font-bold text-green-600 mb-2">
                        {isDonor ? '2,400 lbs' : '450 meals'}
                      </div>
                      <div className="text-gray-600">
                        {isDonor ? 'Food waste prevented' : 'Received this month'}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-xl font-bold text-blue-600">95</div>
                        <div className="text-xs text-gray-600">Families helped</div>
                      </div>
                      <div>
                        <div className="text-xl font-bold text-purple-600">1,200 lbs</div>
                        <div className="text-xs text-gray-600">CO2 saved</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Community Recognition</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-yellow-100 rounded-full flex items-center justify-center">
                        <MessageSquare className="h-5 w-5 text-yellow-600" />
                      </div>
                      <div>
                        <div className="font-medium">Community Hero</div>
                        <div className="text-sm text-gray-600">Top contributor this month</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center">
                        <Heart className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium">Reliable Partner</div>
                        <div className="text-sm text-gray-600">98% fulfillment rate</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Forms */}
      {showDonationForm && (
        <DonationForm 
          onClose={() => setShowDonationForm(false)} 
          onSuccess={handleCreateDonation}
        />
      )}
      
      {showRequestForm && (
        <RequestForm 
          onClose={() => setShowRequestForm(false)} 
          onSuccess={() => {
            setShowRequestForm(false);
            refreshDonations();
          }}
        />
      )}
    </div>
  );
}