import { Card, CardContent } from "./ui/card";
import { Upload, Search, Handshake, Heart } from "lucide-react";

export function HowItWorks() {
  const steps = [
    {
      icon: Upload,
      title: "Post Donations",
      description: "Restaurants and grocery stores post available food items with details about quantity, expiry, and pickup times.",
      userType: "Donors"
    },
    {
      icon: Search,
      title: "Browse & Request",
      description: "Orphanages browse available donations and submit requests for items they need most.",
      userType: "Recipients"
    },
    {
      icon: Handshake,
      title: "Connect & Coordinate",
      description: "Our platform facilitates direct communication between donors and recipients to arrange pickup or delivery.",
      userType: "Platform"
    },
    {
      icon: Heart,
      title: "Make Impact",
      description: "Food reaches those in need, reducing waste while fighting hunger in local communities.",
      userType: "Community"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            How FoodBridge Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our simple four-step process connects food donors with orphanages, 
            ensuring surplus food reaches those who need it most.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <Card key={index} className="relative border-2 hover:border-green-200 transition-colors">
              <CardContent className="p-6 text-center">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-green-600 text-white rounded-full p-3">
                    <step.icon className="h-6 w-6" />
                  </div>
                </div>
                
                <div className="pt-8">
                  <span className="inline-block px-3 py-1 text-xs font-semibold text-green-600 bg-green-100 rounded-full mb-3">
                    {step.userType}
                  </span>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {step.title}
                  </h3>
                  <p className="text-gray-600">
                    {step.description}
                  </p>
                </div>
                
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <div className="w-8 h-0.5 bg-green-200"></div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}