import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  Truck, 
  MapPin, 
  Clock, 
  Package, 
  Navigation, 
  Phone, 
  CheckCircle, 
  XCircle,
  Star,
  TrendingUp,
  Calendar,
  User,
  Baby,
  ChefHat,
  Route
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useDonations } from '../contexts/DonationContext';
import { useNotifications } from '../contexts/NotificationContext';
import { RouteOptimization } from './RouteOptimization';

interface VolunteerDashboardProps {
  onNavigate: (page: string) => void;
}

export function VolunteerDashboard({ onNavigate }: VolunteerDashboardProps) {
  const { profile } = useAuth();
  const { claimedDonations, assignVolunteer, updatePickupStatus } = useDonations();
  const { notifications, markAsRead } = useNotifications();
  const [showRouteOptimizer, setShowRouteOptimizer] = useState(false);
  const [routeOptimizerMode, setRouteOptimizerMode] = useState<'inline' | 'fullscreen'>('inline');

  // Filter real claimed donations and pickup notifications
  const realPickupRequests = claimedDonations.filter(d => 
    d.status === 'claimed' && (!d.volunteer_id || d.pickup_status === 'pending')
  );

  const myAssignedPickups = claimedDonations.filter(d => 
    d.volunteer_id === profile?.organization_name && d.pickup_status !== 'completed'
  );

  // Get pickup notifications for volunteers
  const pickupNotifications = notifications.filter(n => 
    n.type === 'pickup_requested' || 
    (n.type === 'donation_claimed' && n.targetUserType === 'volunteer')
  );

  const [activeDeliveries, setActiveDeliveries] = useState([
    // Mix real claimed donations with mock data for demo
    ...realPickupRequests.slice(0, 2).map(donation => ({
      id: donation.id,
      type: 'pickup' as const,
      donor: donation.donor_name,
      recipient: donation.recipient_name || 'Unknown Recipient',
      donorAddress: donation.donor_address || 'Khammam, Telangana',
      recipientAddress: 'Recipient Location, Khammam',
      donorPhone: donation.donor_phone || '08742-234567',
      recipientPhone: donation.recipient_phone || '08742-987654',
      items: `${donation.title} (${donation.quantity} ${donation.unit})`,
      distance: `${(Math.random() * 5 + 1).toFixed(1)} km`,
      estimatedTime: `${Math.floor(Math.random() * 20 + 10)} mins`,
      status: 'pending' as const,
      priority: 'high' as const,
      scheduledTime: new Date(Date.now() + Math.random() * 2 * 60 * 60 * 1000).toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
      }),
      expiry: new Date(donation.expiration_date).toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
      }),
      donationData: donation // Store original donation data
    })),
    // Add mock deliveries if we need more data
    ...(realPickupRequests.length < 2 ? [{
      id: 'del-001',
      type: 'pickup' as const,
      donor: 'Haveli Restaurant',
      recipient: 'Balala Vikasa Kendra',
      donorAddress: 'Station Road, Near Bus Stand, Khammam',
      recipientAddress: 'Mamatha Nagar, Behind Govt School, Khammam',
      donorPhone: '08742-234567',
      recipientPhone: '08742-987654',
      items: 'Rice, Dal, Vegetables (Serves 30)',
      distance: '3.2 km',
      estimatedTime: '15 mins',
      status: 'pending' as const,
      priority: 'high' as const,
      scheduledTime: '12:30 PM',
      expiry: '2:00 PM'
    }] : []),
    ...(realPickupRequests.length < 1 ? [{
      id: 'del-002', 
      type: 'delivery' as const,
      donor: 'Reliance Fresh Grocery',
      recipient: 'Sri Venkateswara Orphanage',
      donorAddress: 'Collectorate Road, Near Govt Hospital, Khammam',
      recipientAddress: 'Nehru Nagar, Behind Temple, Khammam',
      donorPhone: '08742-456789',
      recipientPhone: '08742-123456',
      items: 'Fruits, Bread, Milk (Serves 25)',
      distance: '4.1 km',
      estimatedTime: '18 mins',
      status: 'in_progress' as const,
      priority: 'medium' as const,
      scheduledTime: '1:15 PM',
      expiry: '3:30 PM'
    }] : [])
  ]);

  const [completedDeliveries] = useState([
    {
      id: 'del-comp-001',
      donor: 'Hotel Grand',
      recipient: 'Children Home',
      completedAt: '11:45 AM',
      items: 'Breakfast items (Served 40)',
      rating: 5
    },
    {
      id: 'del-comp-002',
      donor: 'Fresh Market',
      recipient: 'Care Foundation',
      completedAt: '10:30 AM', 
      items: 'Fresh vegetables (Served 35)',
      rating: 4
    }
  ]);

  const handleAcceptDelivery = async (deliveryId: string) => {
    const delivery = activeDeliveries.find(d => d.id === deliveryId);
    if (delivery && delivery.donationData) {
      // Update the real donation with volunteer assignment
      await assignVolunteer(
        delivery.donationData.id,
        profile?.organization_name || 'volunteer',
        profile?.organization_name || 'Volunteer Driver',
        profile?.phone || '9876543210'
      );
    }
    
    setActiveDeliveries(prev => 
      prev.map(delivery => 
        delivery.id === deliveryId 
          ? { ...delivery, status: 'accepted' }
          : delivery
      )
    );

    // Mark related notifications as read
    pickupNotifications.forEach(notification => {
      if (notification.data?.donationId === deliveryId) {
        markAsRead(notification.id);
      }
    });
  };

  const handleStartDelivery = async (deliveryId: string) => {
    const delivery = activeDeliveries.find(d => d.id === deliveryId);
    if (delivery && delivery.donationData) {
      await updatePickupStatus(delivery.donationData.id, 'in_progress');
    }

    setActiveDeliveries(prev => 
      prev.map(delivery => 
        delivery.id === deliveryId 
          ? { ...delivery, status: 'in_progress' }
          : delivery
      )
    );
  };

  const handleCompleteDelivery = async (deliveryId: string) => {
    const delivery = activeDeliveries.find(d => d.id === deliveryId);
    if (delivery && delivery.donationData) {
      await updatePickupStatus(delivery.donationData.id, 'completed');
    }

    setActiveDeliveries(prev => 
      prev.filter(delivery => delivery.id !== deliveryId)
    );
  };

  const handleViewRoute = (deliveryId: string) => {
    const delivery = activeDeliveries.find(d => d.id === deliveryId);
    if (delivery) {
      // Create pickup locations for route optimization
      const pickupLocations = [{
        donationId: delivery.id,
        donorName: delivery.donor,
        donorAddress: delivery.donorAddress,
        donorPhone: delivery.donorPhone
      }];

      setShowRouteOptimizer(true);
      setRouteOptimizerMode('fullscreen');
    }
  };

  const getStatusBadge = (status: string, priority: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className={`${priority === 'high' ? 'border-red-500 text-red-700' : 'border-yellow-500 text-yellow-700'}`}>Pending</Badge>;
      case 'accepted':
        return <Badge variant="default" className="bg-blue-500">Accepted</Badge>;
      case 'in_progress':
        return <Badge variant="default" className="bg-green-500">In Progress</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <div className="w-3 h-3 bg-red-500 rounded-full"></div>;
      case 'medium':
        return <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>;
      case 'low':
        return <div className="w-3 h-3 bg-green-500 rounded-full"></div>;
      default:
        return <div className="w-3 h-3 bg-gray-400 rounded-full"></div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Route Optimization Section - Show when viewing route */}
      {showRouteOptimizer && (
        <RouteOptimization
          pickupLocations={[
            {
              donationId: activeDeliveries.find(d => showRouteOptimizer)?.id || 'route-1',
              donorName: activeDeliveries.find(d => showRouteOptimizer)?.donor || 'Donor',
              donorAddress: activeDeliveries.find(d => showRouteOptimizer)?.donorAddress || 'Khammam, Telangana',
              donorPhone: activeDeliveries.find(d => showRouteOptimizer)?.donorPhone || '08742-000000'
            }
          ]}
          recipientLocation={{
            name: profile?.organization_name || 'Your Base Location',
            address: profile?.address || 'Khammam, Telangana'
          }}
          mode={routeOptimizerMode}
          onClose={() => setShowRouteOptimizer(false)}
          onModeChange={(mode) => setRouteOptimizerMode(mode)}
        />
      )}

      {/* Show main dashboard only when not in fullscreen route mode */}
      {!showRouteOptimizer || routeOptimizerMode === 'inline' ? (
        <>
          {/* Header */}
          <div className="bg-white shadow-sm">
            <div className="max-w-7xl mx-auto px-4 py-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <Truck className="h-8 w-8 text-green-600" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-semibold text-gray-900">Volunteer Dashboard</h1>
                    <p className="text-gray-600">Welcome back, {profile?.contact_person}</p>
                    {realPickupRequests.length > 0 && (
                      <p className="text-sm text-green-600 mt-1">🔔 {realPickupRequests.length} new pickup request{realPickupRequests.length > 1 ? 's' : ''} available!</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Available
                  </Badge>
                  <Button variant="outline" onClick={() => onNavigate('profile')}>
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="max-w-7xl mx-auto px-4 py-8">
            {/* Real-time notifications */}
            {pickupNotifications.length > 0 && (
              <Alert className="mb-6 border-green-200 bg-green-50">
                <Package className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  <div className="font-medium mb-1">🚛 New Pickup Requests Available:</div>
                  <div className="text-sm space-y-1">
                    {pickupNotifications.slice(0, 3).map((notification, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-3 w-3" />
                        {notification.message}
                      </div>
                    ))}
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Today's Deliveries</p>
                      <p className="text-2xl font-semibold">3</p>
                    </div>
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <Package className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Distance Covered</p>
                      <p className="text-2xl font-semibold">12.4 km</p>
                    </div>
                    <div className="bg-green-100 p-3 rounded-lg">
                      <Route className="h-6 w-6 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">People Served</p>
                      <p className="text-2xl font-semibold">95</p>
                    </div>
                    <div className="bg-orange-100 p-3 rounded-lg">
                      <Baby className="h-6 w-6 text-orange-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Rating</p>
                      <p className="text-2xl font-semibold">4.8</p>
                    </div>
                    <div className="bg-yellow-100 p-3 rounded-lg">
                      <Star className="h-6 w-6 text-yellow-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <Tabs defaultValue="active" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="active">Active Deliveries</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
                <TabsTrigger value="schedule">Schedule</TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="space-y-6">
                {activeDeliveries.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Truck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Deliveries</h3>
                      <p className="text-gray-600">New delivery requests will appear here</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-6">
                    {activeDeliveries.map((delivery) => (
                      <Card key={delivery.id} className="overflow-hidden">
                        <CardHeader className="pb-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="flex items-center gap-2">
                                {getPriorityIcon(delivery.priority)}
                                <CardTitle className="text-lg">Delivery #{delivery.id.slice(-3)}</CardTitle>
                              </div>
                              {getStatusBadge(delivery.status, delivery.priority)}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Clock className="h-4 w-4" />
                              {delivery.scheduledTime} • Expires {delivery.expiry}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {/* Route Information */}
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-3">
                              <div className="flex items-start gap-3">
                                <div className="bg-orange-100 p-2 rounded-lg">
                                  <ChefHat className="h-4 w-4 text-orange-600" />
                                </div>
                                <div className="flex-1">
                                  <p className="font-medium text-gray-900">Pickup from</p>
                                  <p className="text-sm text-gray-600">{delivery.donor}</p>
                                  <p className="text-sm text-gray-500">{delivery.donorAddress}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Phone className="h-3 w-3 text-gray-400" />
                                    <span className="text-xs text-gray-500">{delivery.donorPhone}</span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-3">
                              <div className="flex items-start gap-3">
                                <div className="bg-blue-100 p-2 rounded-lg">
                                  <Baby className="h-4 w-4 text-blue-600" />
                                </div>
                                <div className="flex-1">
                                  <p className="font-medium text-gray-900">Deliver to</p>
                                  <p className="text-sm text-gray-600">{delivery.recipient}</p>
                                  <p className="text-sm text-gray-500">{delivery.recipientAddress}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Phone className="h-3 w-3 text-gray-400" />
                                    <span className="text-xs text-gray-500">{delivery.recipientPhone}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <Separator />

                          {/* Delivery Details */}
                          <div className="grid md:grid-cols-3 gap-4">
                            <div>
                              <p className="text-sm text-gray-600">Items</p>
                              <p className="font-medium">{delivery.items}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-600">Distance</p>
                              <p className="font-medium">{delivery.distance}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-600">Est. Time</p>
                              <p className="font-medium">{delivery.estimatedTime}</p>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex flex-wrap gap-2">
                            {delivery.status === 'pending' && (
                              <Button 
                                onClick={() => handleAcceptDelivery(delivery.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Accept Delivery
                              </Button>
                            )}
                            
                            {delivery.status === 'accepted' && (
                              <Button 
                                onClick={() => handleStartDelivery(delivery.id)}
                                className="bg-blue-600 hover:bg-blue-700"
                              >
                                <Navigation className="h-4 w-4 mr-2" />
                                Start Delivery
                              </Button>
                            )}

                            {delivery.status === 'in_progress' && (
                              <Button 
                                onClick={() => handleCompleteDelivery(delivery.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Mark Completed
                              </Button>
                            )}

                            <Button variant="outline" onClick={() => handleViewRoute(delivery.id)}>
                              <MapPin className="h-4 w-4 mr-2" />
                              View Route
                            </Button>
                            
                            <Button variant="outline">
                              <Phone className="h-4 w-4 mr-2" />
                              Contact
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="completed" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Completed Deliveries Today</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {completedDeliveries.length === 0 ? (
                      <div className="text-center py-8">
                        <CheckCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">No completed deliveries yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {completedDeliveries.map((delivery) => (
                          <div key={delivery.id} className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                            <div>
                              <p className="font-medium">{delivery.donor} → {delivery.recipient}</p>
                              <p className="text-sm text-gray-600">{delivery.items}</p>
                              <p className="text-xs text-gray-500">Completed at {delivery.completedAt}</p>
                            </div>
                            <div className="flex items-center gap-1">
                              {[...Array(delivery.rating)].map((_, i) => (
                                <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="schedule" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Upcoming Schedule</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No scheduled deliveries</p>
                      <p className="text-sm text-gray-500 mt-2">Future delivery requests will appear here</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Quick Actions */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <Button variant="outline" className="h-20 flex-col">
                    <MapPin className="h-6 w-6 mb-2" />
                    Update Location
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <Clock className="h-6 w-6 mb-2" />
                    Set Availability
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <TrendingUp className="h-6 w-6 mb-2" />
                    View Analytics
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      ) : null}
    </div>
  );
}