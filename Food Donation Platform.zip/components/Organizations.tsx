import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { MapPin, Star, Users, Heart, Award, TrendingUp, Calendar, Eye } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { useState } from "react";
import { AuthModal } from "./AuthModal";
import { OrganizationProfile } from "./OrganizationProfile";

export function Organizations() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'signin' | 'signup'>('signup');
  const [selectedOrgId, setSelectedOrgId] = useState<string | null>(null);

  const handleJoinAsDonor = () => {
    setAuthModalTab('signup');
    setAuthModalOpen(true);
  };

  const handleJoinAsRecipient = () => {
    setAuthModalTab('signup');
    setAuthModalOpen(true);
  };

  const handleViewProfile = (orgId: string) => {
    setSelectedOrgId(orgId);
  };

  // Updated with Khammam local restaurant names
  const donors = [
    {
      id: 'khammam-1',
      name: "Haveli Restaurant",
      type: "Restaurant",
      location: "Station Road, Khammam",
      rating: 4.8,
      totalDonations: 127,
      image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=300&q=80",
      description: "Traditional Indian cuisine restaurant serving authentic Telangana dishes and committed to reducing food waste."
    },
    {
      id: 'khammam-2',
      name: "Annapurna Family Restaurant",
      type: "Restaurant",
      location: "Wyra Road, Khammam",
      rating: 4.9,
      totalDonations: 89,
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=300&q=80",
      description: "Popular family restaurant known for South Indian and North Indian cuisine, actively supporting local orphanages."
    },
    {
      id: 'khammam-3',
      name: "Reliance Fresh Grocery",
      type: "Grocery Store",
      location: "Collectorate Road, Khammam",
      rating: 4.7,
      totalDonations: 156,
      image: "https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=300&q=80",
      description: "Modern grocery store providing fresh produce and groceries, committed to community welfare and food donation."
    },
    {
      id: 'khammam-4',
      name: "Sri Venkateswara Dairy & Sweets",
      type: "Dairy & Sweets",
      location: "Gandhi Chowk, Khammam",
      rating: 4.6,
      totalDonations: 73,
      image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=300&q=80",
      description: "Traditional dairy shop and sweet center offering fresh milk products and regional sweets."
    },
    {
      id: 'khammam-5',
      name: "Udupi Krishna Hotel",
      type: "Restaurant",
      location: "Bus Stand Road, Khammam",
      rating: 4.8,
      totalDonations: 98,
      image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=300&q=80",
      description: "Authentic South Indian restaurant specializing in Udupi cuisine and breakfast items."
    },
    {
      id: 'khammam-6',
      name: "Big Bazaar Khammam",
      type: "Supermarket",
      location: "NSP Complex, Khammam",
      rating: 4.5,
      totalDonations: 145,
      image: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=300&q=80",
      description: "Large retail store offering groceries, fresh produce, and household items with community support programs."
    }
  ];

  const recipients = [
    {
      id: 'recipient-1',
      name: "Balala Vikasa Kendra",
      type: "Orphanage",
      location: "Mamatha Nagar, Khammam",
      children: 45,
      established: "2010",
      image: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=300&q=80",
      description: "Caring for 45 children aged 3-16, providing education, healthcare, and a loving home environment."
    },
    {
      id: 'recipient-2',
      name: "Khammam Children's Home",
      type: "Orphanage",
      location: "Nehru Nagar, Khammam",
      children: 32,
      established: "2015",
      image: "https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=300&q=80",
      description: "Supporting 32 children with special focus on education and skill development programs."
    },
    {
      id: 'recipient-3',
      name: "Little Angels Care Center",
      type: "Orphanage",
      location: "Railway Station Road, Khammam",
      children: 28,
      established: "2008",
      image: "https://images.unsplash.com/photo-1544717297-fa95b6ee9643?auto=format&fit=crop&w=300&q=80",
      description: "Dedicated to providing nutritious meals and comprehensive care for 28 children."
    },
    {
      id: 'recipient-4',
      name: "Telangana Seva Samithi",
      type: "Orphanage",
      location: "Collectorate Road, Khammam",
      children: 38,
      established: "2012",
      image: "https://images.unsplash.com/photo-1471860501518-0282dbe6ee96?auto=format&fit=crop&w=300&q=80",
      description: "Youth-focused organization providing housing, education, and life skills training for 38 teenagers."
    }
  ];

  // Enhanced featured restaurants with Khammam names
  const featuredRestaurants = [
    {
      id: 'khammam-1',
      name: "Haveli Restaurant",
      image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=400&q=80",
      totalDonations: 127,
      mealsProvided: 3800,
      joinedDate: "2022",
      specialty: "Traditional Telangana Cuisine"
    },
    {
      id: 'khammam-3',
      name: "Reliance Fresh Grocery",
      image: "https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=400&q=80",
      totalDonations: 156,
      mealsProvided: 4680,
      joinedDate: "2022",
      specialty: "Fresh Groceries & Produce"
    },
    {
      id: 'khammam-2',
      name: "Annapurna Family Restaurant",
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=400&q=80",
      totalDonations: 89,
      mealsProvided: 2670,
      joinedDate: "2023",
      specialty: "South & North Indian Cuisine"
    },
    {
      id: 'khammam-5',
      name: "Udupi Krishna Hotel",
      image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=400&q=80",
      totalDonations: 98,
      mealsProvided: 2940,
      joinedDate: "2023",
      specialty: "Authentic South Indian Food"
    }
  ];

  if (selectedOrgId) {
    return (
      <OrganizationProfile 
        organizationId={selectedOrgId}
        onClose={() => setSelectedOrgId(null)}
      />
    );
  }

  return (
    <>
      <section id="organizations" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Khammam Community Partners
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Meet the amazing local organizations in Khammam that make FoodBridge possible - from generous food donors 
              to the orphanages serving children in need.
            </p>
          </div>
          
          <Tabs defaultValue="donors" className="w-full">
            <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-12">
              <TabsTrigger value="donors" className="flex items-center">
                <Heart className="mr-2 h-4 w-4" />
                Food Donors
              </TabsTrigger>
              <TabsTrigger value="recipients" className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                Orphanages
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="donors">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {donors.map((donor) => (
                  <Card key={donor.id} className="hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <ImageWithFallback
                        src={donor.image}
                        alt={donor.name}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <Badge className="absolute top-3 right-3 bg-green-600 hover:bg-green-600">
                        {donor.type}
                      </Badge>
                    </div>
                    
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{donor.name}</h3>
                      <p className="text-gray-600 text-sm mb-4">{donor.description}</p>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-4 w-4 mr-2" />
                          {donor.location}
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Star className="h-4 w-4 mr-2 text-yellow-500" />
                          {donor.rating} rating
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Heart className="h-4 w-4 mr-2 text-red-500" />
                          {donor.totalDonations} donations made
                        </div>
                      </div>
                      
                      <Button 
                        className="w-full" 
                        variant="outline"
                        onClick={() => handleViewProfile(donor.id)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View Profile
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="recipients">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recipients.map((recipient) => (
                  <Card key={recipient.id} className="hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <ImageWithFallback
                        src={recipient.image}
                        alt={recipient.name}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <Badge className="absolute top-3 right-3 bg-blue-600 hover:bg-blue-600">
                        {recipient.type}
                      </Badge>
                    </div>
                    
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{recipient.name}</h3>
                      <p className="text-gray-600 text-sm mb-4">{recipient.description}</p>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-4 w-4 mr-2" />
                          {recipient.location}
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Users className="h-4 w-4 mr-2" />
                          {recipient.children} children
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Heart className="h-4 w-4 mr-2" />
                          Est. {recipient.established}
                        </div>
                      </div>
                      
                      <Button 
                        className="w-full" 
                        variant="outline"
                        onClick={() => handleViewProfile(recipient.id)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View Profile
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="text-center mt-12">
            <div className="bg-green-50 rounded-2xl p-8 mb-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                Join Our Khammam Community
              </h3>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                Whether you're a restaurant, grocery store, or orphanage in Khammam, join FoodBridge to make a difference in our local community.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={handleJoinAsDonor}
                >
                  Register as Donor
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-green-600 text-green-600 hover:bg-green-50"
                  onClick={handleJoinAsRecipient}
                >
                  Register as Recipient
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Restaurant Showcase Section */}
      <section className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-4">
              <Award className="h-8 w-8 text-yellow-500 mr-3" />
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
                Top Contributing Khammam Partners
              </h2>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Celebrating our local Khammam restaurant and business partners who have made the biggest impact 
              in fighting hunger in our community.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredRestaurants.map((restaurant, index) => (
              <Card key={restaurant.id} className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden">
                <div className="relative">
                  <ImageWithFallback
                    src={restaurant.image}
                    alt={restaurant.name}
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-yellow-500 hover:bg-yellow-500 text-yellow-900">
                      #{index + 1} Partner
                    </Badge>
                  </div>
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-white/90 hover:bg-white/90 text-gray-900">
                      Since {restaurant.joinedDate}
                    </Badge>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">{restaurant.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{restaurant.specialty}</p>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-gray-600">
                        <TrendingUp className="h-4 w-4 mr-2 text-green-600" />
                        Total Donations
                      </div>
                      <span className="font-semibold text-green-600">{restaurant.totalDonations}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-gray-600">
                        <Heart className="h-4 w-4 mr-2 text-red-500" />
                        Meals Provided
                      </div>
                      <span className="font-semibold text-red-600">{restaurant.mealsProvided.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="h-4 w-4 mr-2 text-blue-500" />
                        Partner Since
                      </div>
                      <span className="font-semibold text-blue-600">{restaurant.joinedDate}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <Button 
                      className="w-full text-sm" 
                      variant="outline"
                      onClick={() => handleViewProfile(restaurant.id)}
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View Full Profile
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">573+</div>
                  <div className="text-gray-600">Total Donations</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">17,190</div>
                  <div className="text-gray-600">Meals Provided</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-2">147</div>
                  <div className="text-gray-600">Children Fed Daily</div>
                </div>
              </div>
              <div className="mt-6">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                  onClick={handleJoinAsDonor}
                >
                  Join Our Khammam Community Partners
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <AuthModal 
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialTab={authModalTab}
      />
    </>
  );
}