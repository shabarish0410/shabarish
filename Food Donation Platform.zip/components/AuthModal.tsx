import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Heart, AlertCircle, CheckCircle, ChefHat, Baby, Loader2, ArrowRight, Truck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface AuthModalProps {
  mode?: 'signin' | 'signup';
  onClose: () => void;
  onSuccess?: () => void;
  onToggleMode?: (mode: 'signin' | 'signup') => void;
  isOpen?: boolean;
}

export function AuthModal({ mode = 'signin', onClose, onSuccess, onToggleMode, isOpen = true }: AuthModalProps) {
  const [activeTab, setActiveTab] = useState(mode);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [redirectProgress, setRedirectProgress] = useState(0);
  const [showRolePreview, setShowRolePreview] = useState(false);
  const { signIn, signUp } = useAuth();

  // Update activeTab when mode prop changes
  useState(() => {
    setActiveTab(mode);
  });

  const [signInData, setSignInData] = useState({
    email: '',
    password: ''
  });

  const [signUpData, setSignUpData] = useState({
    organization_name: '',
    organization_type: 'donor' as 'donor' | 'recipient' | 'volunteer',
    contact_person: '',
    email: '',
    password: '',
    phone: '',
    address: '',
    description: '',
    children_count: '',
    established_year: '',
    vehicle_type: '',
    availability_hours: ''
  });

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const result = await signIn(signInData.email, signInData.password);
      
      if (result.success) {
        setSuccess('Successfully signed in!');
        
        // Show redirect progress
        let progress = 0;
        const interval = setInterval(() => {
          progress += 25;
          setRedirectProgress(progress);
          
          if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              onSuccess?.();
            }, 500);
          }
        }, 250);
      } else {
        setError('Invalid email or password. Please try again.');
      }
    } catch (error) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const success = await signUp(signUpData);
      
      if (success) {
        setSuccess('Account created successfully!');
        
        // Show redirect progress with role-specific message
        let progress = 0;
        const interval = setInterval(() => {
          progress += 20;
          setRedirectProgress(progress);
          
          if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              let redirectTo: string;
              if (signUpData.organization_type === 'donor') {
                redirectTo = 'restaurant-dashboard';
              } else if (signUpData.organization_type === 'volunteer') {
                redirectTo = 'volunteer-dashboard';
              } else {
                redirectTo = 'orphanage-dashboard';
              }
              onSuccess?.();
            }, 500);
          }
        }, 200);
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (error) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignInInputChange = (field: string, value: string) => {
    setSignInData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleSignUpInputChange = (field: string, value: string) => {
    setSignUpData(prev => ({ ...prev, [field]: value }));
    setError('');
    
    // Show role preview when organization type changes
    if (field === 'organization_type') {
      setShowRolePreview(true);
      setTimeout(() => setShowRolePreview(false), 3000);
    }
  };

  const demoAccounts = [
    {
      type: 'Restaurant',
      email: 'demo@restaurant.com',
      password: 'demo123',
      description: 'Haveli Restaurant - Traditional Indian cuisine',
      icon: <ChefHat className="h-4 w-4" />,
      dashboardType: 'Restaurant Dashboard'
    },
    {
      type: 'Orphanage',
      email: 'demo@orphanage.com', 
      password: 'demo123',
      description: 'Balala Vikasa Kendra - Children care center',
      icon: <Baby className="h-4 w-4" />,
      dashboardType: 'Orphanage Dashboard'
    },
    {
      type: 'Volunteer Driver',
      email: 'demo@volunteer.com',
      password: 'demo123',
      description: 'FoodBridge Delivery Services - Volunteer delivery',
      icon: <Truck className="h-4 w-4" />,
      dashboardType: 'Volunteer Dashboard'
    },
    {
      type: 'Grocery Store',
      email: 'demo@grocery.com',
      password: 'demo123', 
      description: 'Reliance Fresh Grocery - Modern grocery store',
      icon: <ChefHat className="h-4 w-4" />,
      dashboardType: 'Restaurant Dashboard'
    }
  ];

  const fillDemoAccount = (email: string, password: string) => {
    setSignInData({ email, password });
  };

  const getRoleInfo = (type: 'donor' | 'recipient' | 'volunteer') => {
    if (type === 'donor') {
      return {
        title: 'Restaurant/Grocery Dashboard',
        description: 'Post food donations, track impact, manage pickups',
        icon: <ChefHat className="h-5 w-5" />,
        color: 'orange',
        features: ['Post daily surplus food', 'Track waste reduction', 'Connect with orphanages', 'Route optimization']
      };
    } else if (type === 'volunteer') {
      return {
        title: 'Volunteer Dashboard',
        description: 'Manage deliveries, optimize routes, track impacts',
        icon: <Truck className="h-5 w-5" />,
        color: 'green',
        features: ['Accept delivery requests', 'GPS route optimization', 'Real-time tracking', 'Impact reporting']
      };
    } else {
      return {
        title: 'Orphanage Dashboard', 
        description: 'Find food donations, claim meals, coordinate pickups',
        icon: <Baby className="h-5 w-5" />,
        color: 'blue',
        features: ['Browse available donations', 'Claim needed food', 'Nutrition planning', 'Pickup scheduling']
      };
    }
  };

  const roleInfo = getRoleInfo(signUpData.organization_type);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="bg-green-600 p-1.5 rounded">
              <Heart className="h-4 w-4 text-white" />
            </div>
            Welcome to FoodBridge Khammam
          </DialogTitle>
          <DialogDescription>
            {activeTab === 'signin' 
              ? 'Sign in to your account to manage food donations and connect with local organizations in Khammam.'
              : 'Create your account to join the FoodBridge community and start reducing food waste in Khammam.'
            }
          </DialogDescription>
        </DialogHeader>

        {/* Redirect Progress */}
        {(success && redirectProgress > 0) && (
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="font-medium text-green-900">
                {activeTab === 'signin' ? 'Signing you in...' : 'Creating your account...'}
              </span>
            </div>
            <Progress value={redirectProgress} className="h-2 mb-2" />
            <p className="text-sm text-green-700">
              Redirecting to your {roleInfo.title}...
            </p>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={(value) => {
          setActiveTab(value as 'signin' | 'signup');
          onToggleMode?.(value as 'signin' | 'signup');
        }}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Join Us</TabsTrigger>
          </TabsList>

          <TabsContent value="signin">
            <form onSubmit={handleSignIn} className="space-y-4">
              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-700">{error}</AlertDescription>
                </Alert>
              )}

              {success && !redirectProgress && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-700">{success}</AlertDescription>
                </Alert>
              )}

              {/* Demo Accounts with Dashboard Preview */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-3">Try Demo Accounts:</h4>
                <div className="space-y-3">
                  {demoAccounts.map((account, index) => (
                    <div key={index} className="bg-white p-3 rounded border">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded ${
                            account.type === 'Orphanage' 
                              ? 'bg-blue-100' 
                              : account.type === 'Volunteer Driver'
                              ? 'bg-green-100'
                              : 'bg-orange-100'
                          }`}>
                            {account.icon}
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">{account.type}</div>
                            <div className="text-xs text-gray-600">{account.description}</div>
                            <div className="text-xs text-green-600 flex items-center gap-1 mt-1">
                              <ArrowRight className="h-3 w-3" />
                              {account.dashboardType}
                            </div>
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => fillDemoAccount(account.email, account.password)}
                          className="text-xs"
                        >
                          Use Account
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="signin-email">Email</Label>
                  <Input
                    id="signin-email"
                    type="email"
                    value={signInData.email}
                    onChange={(e) => handleSignInInputChange('email', e.target.value)}
                    placeholder="your@email.com"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="signin-password">Password</Label>
                  <Input
                    id="signin-password"
                    type="password"
                    value={signInData.password}
                    onChange={(e) => handleSignInInputChange('password', e.target.value)}
                    placeholder="Your password"
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading || redirectProgress > 0}>
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Signing In...
                  </>
                ) : (
                  'Sign In'
                )}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <form onSubmit={handleSignUp} className="space-y-4">
              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-700">{error}</AlertDescription>
                </Alert>
              )}

              {success && !redirectProgress && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-700">{success}</AlertDescription>
                </Alert>
              )}

              <div>
                <Label htmlFor="organization_type">Organization Type</Label>
                <Select 
                  value={signUpData.organization_type} 
                  onValueChange={(value) => handleSignUpInputChange('organization_type', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select organization type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="donor">
                      <div className="flex items-center gap-2">
                        <ChefHat className="h-4 w-4" />
                        Restaurant/Grocery Store (Food Donor)
                      </div>
                    </SelectItem>
                    <SelectItem value="recipient">
                      <div className="flex items-center gap-2">
                        <Baby className="h-4 w-4" />
                        Orphanage (Food Recipient)
                      </div>
                    </SelectItem>
                    <SelectItem value="volunteer">
                      <div className="flex items-center gap-2">
                        <Truck className="h-4 w-4" />
                        Volunteer Delivery Driver
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Role Preview */}
              {(showRolePreview || signUpData.organization_type) && (
                <div className={`p-4 rounded-lg border-2 transition-all ${
                  roleInfo.color === 'orange' 
                    ? 'bg-orange-50 border-orange-200' 
                    : roleInfo.color === 'green'
                    ? 'bg-green-50 border-green-200'
                    : 'bg-blue-50 border-blue-200'
                }`}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`p-2 rounded ${
                      roleInfo.color === 'orange' 
                        ? 'bg-orange-100' 
                        : roleInfo.color === 'green'
                        ? 'bg-green-100'
                        : 'bg-blue-100'
                    }`}>
                      {roleInfo.icon}
                    </div>
                    <div>
                      <h4 className={`font-medium ${
                        roleInfo.color === 'orange' 
                          ? 'text-orange-900' 
                          : roleInfo.color === 'green'
                          ? 'text-green-900'
                          : 'text-blue-900'
                      }`}>
                        {roleInfo.title}
                      </h4>
                      <p className={`text-sm ${
                        roleInfo.color === 'orange' 
                          ? 'text-orange-700' 
                          : roleInfo.color === 'green'
                          ? 'text-green-700'
                          : 'text-blue-700'
                      }`}>
                        {roleInfo.description}
                      </p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    {roleInfo.features.map((feature, index) => (
                      <div key={index} className={`text-xs flex items-center gap-2 ${
                        roleInfo.color === 'orange' 
                          ? 'text-orange-600' 
                          : roleInfo.color === 'green'
                          ? 'text-green-600'
                          : 'text-blue-600'
                      }`}>
                        <CheckCircle className="h-3 w-3" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 gap-3">
                <div>
                  <Label htmlFor="organization_name">Organization Name</Label>
                  <Input
                    id="organization_name"
                    value={signUpData.organization_name}
                    onChange={(e) => handleSignUpInputChange('organization_name', e.target.value)}
                    placeholder="Your organization name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="contact_person">Contact Person</Label>
                  <Input
                    id="contact_person"
                    value={signUpData.contact_person}
                    onChange={(e) => handleSignUpInputChange('contact_person', e.target.value)}
                    placeholder="Your full name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    value={signUpData.email}
                    onChange={(e) => handleSignUpInputChange('email', e.target.value)}
                    placeholder="your@email.com"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="signup-password">Password</Label>
                  <Input
                    id="signup-password"
                    type="password"
                    value={signUpData.password}
                    onChange={(e) => handleSignUpInputChange('password', e.target.value)}
                    placeholder="Create a password"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={signUpData.phone}
                    onChange={(e) => handleSignUpInputChange('phone', e.target.value)}
                    placeholder="08742-XXXXXX"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="address">Address in Khammam</Label>
                  <Textarea
                    id="address"
                    value={signUpData.address}
                    onChange={(e) => handleSignUpInputChange('address', e.target.value)}
                    placeholder="Complete address in Khammam, Telangana"
                    rows={2}
                    required
                  />
                </div>

                {signUpData.organization_type === 'recipient' && (
                  <div>
                    <Label htmlFor="children_count">Number of Children</Label>
                    <Input
                      id="children_count"
                      type="number"
                      value={signUpData.children_count}
                      onChange={(e) => handleSignUpInputChange('children_count', e.target.value)}
                      placeholder="Total children in your care"
                    />
                  </div>
                )}

                {signUpData.organization_type === 'volunteer' && (
                  <>
                    <div>
                      <Label htmlFor="vehicle_type">Vehicle Type</Label>
                      <Select 
                        value={signUpData.vehicle_type} 
                        onValueChange={(value) => handleSignUpInputChange('vehicle_type', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select your vehicle" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="two_wheeler">Two Wheeler (Motorcycle/Scooter)</SelectItem>
                          <SelectItem value="three_wheeler">Three Wheeler (Auto/Rickshaw)</SelectItem>
                          <SelectItem value="four_wheeler">Four Wheeler (Car/Van)</SelectItem>
                          <SelectItem value="bicycle">Bicycle</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="availability_hours">Availability Hours</Label>
                      <Input
                        id="availability_hours"
                        value={signUpData.availability_hours}
                        onChange={(e) => handleSignUpInputChange('availability_hours', e.target.value)}
                        placeholder="e.g., 9:00 AM - 6:00 PM"
                      />
                    </div>
                  </>
                )}

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={signUpData.description}
                    onChange={(e) => handleSignUpInputChange('description', e.target.value)}
                    placeholder="Brief description of your organization"
                    rows={2}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading || redirectProgress > 0}>
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  <>
                    Create Account
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </>
                )}
              </Button>

              <p className="text-xs text-gray-500 text-center">
                By creating an account, you agree to help reduce food waste and support the Khammam community.
              </p>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}