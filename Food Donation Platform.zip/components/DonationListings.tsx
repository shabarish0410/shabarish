import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Clock, MapPin, Package, Calendar, Filter, RefreshCw, Eye, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { AuthModal } from "./AuthModal";
import { OrganizationProfile } from "./OrganizationProfile";
import { ClaimForm } from "./ClaimForm";
import { useAuth } from "../contexts/AuthContext";
import { useDonations } from "../contexts/DonationContext";
import { Alert, AlertDescription } from "./ui/alert";

export function DonationListings() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [selectedOrgId, setSelectedOrgId] = useState<string | null>(null);
  const [selectedDonation, setSelectedDonation] = useState<any>(null);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const { user } = useAuth();
  const { availableDonations, loading, refreshDonations, claimDonation } = useDonations();

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date());
      refreshDonations();
    }, 30000);

    return () => clearInterval(interval);
  }, [refreshDonations]);

  const categories = ["All Categories", "Bakery Items", "Prepared Meals", "Fresh Produce", "Dairy Products", "Canned Goods"];

  const filteredDonations = selectedCategory === "All Categories" 
    ? availableDonations 
    : availableDonations.filter(donation => donation.food_type === selectedCategory);

  const handlePostDonation = () => {
    if (!user) {
      setAuthModalOpen(true);
    } else {
      alert("Redirecting to donation posting form in your dashboard!");
    }
  };

  const handleRequestDonation = async (donation: any) => {
    if (!user) {
      setAuthModalOpen(true);
    } else {
      setSelectedDonation(donation);
    }
  };

  const handleClaimSubmit = async (claimData: any) => {
    const success = await claimDonation(claimData.donation_id);
    if (success) {
      setSelectedDonation(null);
      alert(`Successfully claimed "${selectedDonation.title}"! The donor will contact you soon to arrange pickup.`);
    }
    return success;
  };

  const handleViewMore = () => {
    alert("Loading more donations... Full pagination coming soon!");
  };

  const handleViewProfile = (orgId: string) => {
    setSelectedOrgId(orgId);
  };

  const getTimeAgo = (dateString: string) => {
    const now = new Date();
    const created = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - created.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes} minutes ago`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(diffInMinutes / 1440);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
  };

  const getExpiryUrgency = (expiryDate: string) => {
    const now = new Date();
    const expiry = new Date(expiryDate);
    const hoursUntilExpiry = (expiry.getTime() - now.getTime()) / (1000 * 60 * 60);
    
    if (hoursUntilExpiry < 6) return 'urgent';
    if (hoursUntilExpiry < 24) return 'soon';
    return 'normal';
  };

  if (selectedOrgId) {
    return (
      <OrganizationProfile 
        organizationId={selectedOrgId}
        onClose={() => setSelectedOrgId(null)}
      />
    );
  }

  return (
    <>
      <section id="donations" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Available Donations in Khammam
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Browse current food donations from local Khammam restaurants and grocery stores. 
              Connect directly with donors to arrange pickup.
            </p>
            <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Last updated: {lastUpdate.toLocaleTimeString()}</span>
              <span className="text-green-600">• Live updates every 30 seconds</span>
            </div>
          </div>

          {/* Real-time alert */}
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <strong>Live Feed:</strong> Donations are updated in real-time from Khammam businesses. New items appear automatically as they're posted.
            </AlertDescription>
          </Alert>
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div className="flex gap-2 flex-wrap">
              {categories.map((category) => (
                <Badge 
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className={`cursor-pointer transition-colors ${
                    selectedCategory === category 
                      ? "bg-green-600 hover:bg-green-700" 
                      : "hover:bg-green-50 hover:border-green-300"
                  }`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline"
                size="sm"
                onClick={refreshDonations}
                disabled={loading}
                className="gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button 
                className="bg-green-600 hover:bg-green-700"
                onClick={handlePostDonation}
              >
                <Package className="mr-2 h-4 w-4" />
                Post Donation
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDonations.map((donation) => {
              const urgency = getExpiryUrgency(donation.expiration_date);
              return (
                <Card key={donation.id} className={`hover:shadow-lg transition-shadow overflow-hidden ${
                  urgency === 'urgent' ? 'ring-2 ring-red-200' : 
                  urgency === 'soon' ? 'ring-1 ring-yellow-200' : ''
                }`}>
                  <div className="relative">
                    <ImageWithFallback
                      src={donation.image_url || "https://images.unsplash.com/photo-1665758483281-b4b59c5fd4c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVwYXJlZCUyMG1lYWxzJTIwcmVhZHklMjBmb29kJTIwY29udGFpbmVyc3xlbnwxfHx8fDE3NTQzMDEyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"}
                      alt={donation.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge 
                        className={`${
                          donation.status === 'available' 
                            ? urgency === 'urgent' ? 'bg-red-500 hover:bg-red-600 text-white' :
                              urgency === 'soon' ? 'bg-yellow-500 hover:bg-yellow-600 text-white' :
                              'bg-green-600 hover:bg-green-600'
                            : 'bg-orange-500 hover:bg-orange-500'
                        }`}
                      >
                        {urgency === 'urgent' ? 'Urgent' : 
                         urgency === 'soon' ? 'Expiring Soon' : 
                         donation.status}
                      </Badge>
                    </div>
                    <div className="absolute top-3 right-3">
                      <Badge variant="outline" className="bg-white/90 text-gray-800">
                        {donation.food_type}
                      </Badge>
                    </div>
                    {/* Quantity badge */}
                    <div className="absolute bottom-3 left-3">
                      <Badge className="bg-black/70 text-white hover:bg-black/70">
                        {donation.quantity} {donation.unit}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{donation.title}</CardTitle>
                        <button
                          onClick={() => handleViewProfile(donation.donor_id)}
                          className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1 mt-1"
                        >
                          {donation.donor_name}
                          <Eye className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{donation.description}</p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-2" />
                        {donation.donor_address || 'Contact for address'}
                      </div>
                      <div className="flex items-center text-sm">
                        <Clock className="h-4 w-4 mr-2" />
                        <span className={urgency === 'urgent' ? 'text-red-600 font-medium' : 
                                       urgency === 'soon' ? 'text-yellow-600 font-medium' : 'text-gray-600'}>
                          Expires {new Date(donation.expiration_date).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="h-4 w-4 mr-2" />
                        Posted {getTimeAgo(donation.created_at)}
                      </div>
                      {donation.pickup_instructions && (
                        <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
                          <strong>Pickup:</strong> {donation.pickup_instructions}
                        </div>
                      )}
                    </div>
                    
                    <Button 
                      className="w-full" 
                      variant={donation.status === 'available' ? 'default' : 'outline'}
                      disabled={donation.status !== 'available'}
                      onClick={() => handleRequestDonation(donation)}
                    >
                      {donation.status === 'available' ? 
                        (urgency === 'urgent' ? 'Claim Now - Urgent!' : 'Claim Donation') : 
                        'Already Claimed'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          {filteredDonations.length === 0 && (
            <div className="text-center py-12">
              <Filter className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No donations found</h3>
              <p className="text-gray-600 mb-4">
                {selectedCategory === "All Categories" 
                  ? "No donations are currently available from Khammam businesses. Check back soon as new donations are posted regularly!" 
                  : `No donations found in the "${selectedCategory}" category. Try selecting a different category.`}
              </p>
              <Button onClick={refreshDonations} variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Listings
              </Button>
            </div>
          )}
          
          <div className="text-center mt-12">
            <Button 
              variant="outline" 
              size="lg"
              onClick={handleViewMore}
            >
              View More Donations
            </Button>
          </div>
        </div>
      </section>

      <AuthModal 
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialTab="signin"
      />

      {selectedDonation && (
        <ClaimForm
          donation={selectedDonation}
          onClose={() => setSelectedDonation(null)}
          onSubmit={handleClaimSubmit}
        />
      )}
    </>
  );
}