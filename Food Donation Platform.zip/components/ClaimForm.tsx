import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Badge } from './ui/badge';
import { Calendar, Phone, Users, MapPin, Clock, Package } from 'lucide-react';

interface ClaimFormProps {
  donation: {
    id: string;
    title: string;
    description: string;
    food_type: string;
    quantity: number;
    unit: string;
    expiration_date: string;
    donor_name: string;
    donor_phone?: string;
    donor_address?: string;
    pickup_instructions?: string;
  };
  onClose: () => void;
  onSubmit: (claimData: any) => Promise<boolean>;
}

export function ClaimForm({ donation, onClose, onSubmit }: ClaimFormProps) {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    recipient_organization: profile?.organization_name || '',
    contact_person: '',
    phone_number: profile?.phone || '',
    pickup_date: '',
    pickup_time: '',
    transport_method: '',
    quantity_needed: donation.quantity,
    special_requirements: '',
    urgency_level: 'normal',
    additional_notes: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const success = await onSubmit({
        donation_id: donation.id,
        ...formData
      });

      if (success) {
        onClose();
      } else {
        setError('Failed to claim donation. Please try again.');
      }
    } catch (error) {
      setError('An error occurred. Please try again.');
      console.error('Error claiming donation:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Set default pickup date (tomorrow)
  const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const expiryDate = new Date(donation.expiration_date).toISOString().split('T')[0];

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5 text-green-600" />
            Claim Donation
          </DialogTitle>
          <DialogDescription>
            Fill out this form to claim the donation. The donor will receive your details to coordinate pickup.
          </DialogDescription>
        </DialogHeader>

        {/* Donation Summary */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-gray-900 mb-3">Donation Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Item:</span>
                  <span className="font-medium">{donation.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Type:</span>
                  <Badge variant="outline">{donation.food_type}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Quantity:</span>
                  <span>{donation.quantity} {donation.unit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Expires:</span>
                  <span className="text-red-600 font-medium">
                    {new Date(donation.expiration_date).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
            <div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Donor:</span>
                  <span className="font-medium">{donation.donor_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Location:</span>
                  <span>{donation.donor_address}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Contact:</span>
                  <span>{donation.donor_phone}</span>
                </div>
                {donation.pickup_instructions && (
                  <div className="col-span-2 mt-2">
                    <span className="text-sm text-gray-600">Pickup Instructions:</span>
                    <p className="text-sm bg-blue-50 p-2 rounded mt-1">
                      {donation.pickup_instructions}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm">
              {error}
            </div>
          )}

          {/* Organization Details */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Users className="h-4 w-4" />
              Organization Details
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="recipient_organization">Organization Name *</Label>
                <Input
                  id="recipient_organization"
                  value={formData.recipient_organization}
                  onChange={(e) => handleChange('recipient_organization', e.target.value)}
                  placeholder="Your organization name"
                  required
                />
              </div>
              <div>
                <Label htmlFor="contact_person">Contact Person *</Label>
                <Input
                  id="contact_person"
                  value={formData.contact_person}
                  onChange={(e) => handleChange('contact_person', e.target.value)}
                  placeholder="Name of person handling pickup"
                  required
                />
              </div>
              <div>
                <Label htmlFor="phone_number">Phone Number *</Label>
                <Input
                  id="phone_number"
                  type="tel"
                  value={formData.phone_number}
                  onChange={(e) => handleChange('phone_number', e.target.value)}
                  placeholder="Contact number"
                  required
                />
              </div>
              <div>
                <Label htmlFor="urgency_level">Urgency Level *</Label>
                <Select value={formData.urgency_level} onValueChange={(value) => handleChange('urgency_level', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select urgency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low - Can wait few days</SelectItem>
                    <SelectItem value="normal">Normal - Within 1-2 days</SelectItem>
                    <SelectItem value="high">High - Need today</SelectItem>
                    <SelectItem value="urgent">Urgent - Immediate need</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Pickup Details */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Pickup Coordination
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="pickup_date">Preferred Pickup Date *</Label>
                <Input
                  id="pickup_date"
                  type="date"
                  value={formData.pickup_date}
                  onChange={(e) => handleChange('pickup_date', e.target.value)}
                  min={tomorrow}
                  max={expiryDate}
                  required
                />
              </div>
              <div>
                <Label htmlFor="pickup_time">Preferred Time</Label>
                <Input
                  id="pickup_time"
                  type="time"
                  value={formData.pickup_time}
                  onChange={(e) => handleChange('pickup_time', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="transport_method">Transport Method</Label>
                <Select value={formData.transport_method} onValueChange={(value) => handleChange('transport_method', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="How will you transport?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="car">Car</SelectItem>
                    <SelectItem value="van">Van</SelectItem>
                    <SelectItem value="truck">Truck</SelectItem>
                    <SelectItem value="auto">Auto Rickshaw</SelectItem>
                    <SelectItem value="bike">Motorcycle</SelectItem>
                    <SelectItem value="walking">Walking/Manual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Quantity and Requirements */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Package className="h-4 w-4" />
              Quantity & Requirements
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="quantity_needed">Quantity Needed</Label>
                <div className="flex gap-2">
                  <Input
                    id="quantity_needed"
                    type="number"
                    min="1"
                    max={donation.quantity}
                    value={formData.quantity_needed}
                    onChange={(e) => handleChange('quantity_needed', Number(e.target.value))}
                  />
                  <span className="flex items-center px-3 bg-gray-100 rounded-md text-sm">
                    {donation.unit}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Max available: {donation.quantity} {donation.unit}
                </p>
              </div>
              <div>
                <Label htmlFor="special_requirements">Special Requirements</Label>
                <Input
                  id="special_requirements"
                  value={formData.special_requirements}
                  onChange={(e) => handleChange('special_requirements', e.target.value)}
                  placeholder="Cold storage, specific containers, etc."
                />
              </div>
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <Label htmlFor="additional_notes">Additional Notes</Label>
            <Textarea
              id="additional_notes"
              value={formData.additional_notes}
              onChange={(e) => handleChange('additional_notes', e.target.value)}
              placeholder="Any additional information for the donor..."
              rows={3}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button 
              type="submit" 
              disabled={loading}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {loading ? 'Submitting Claim...' : 'Submit Claim Request'}
            </Button>
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
              className="px-8"
            >
              Cancel
            </Button>
          </div>

          <div className="text-xs text-gray-500 bg-blue-50 p-3 rounded">
            <strong>Next Steps:</strong> After submitting, the donor will receive your contact details and pickup preferences. 
            They will contact you directly to confirm pickup arrangements. Please ensure your phone number is correct.
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}