import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { 
  MapPin, 
  Navigation, 
  Clock, 
  Phone, 
  MessageSquare, 
  X, 
  Truck, 
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Eye,
  Route,
  ExternalLink,
  Zap,
  RadioIcon as Live
} from 'lucide-react';
import { makePhoneCall, openLiveNavigation } from '../utils/navigation';

interface DeliveryPerson {
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  rating: number;
  photo?: string;
}

interface LiveLocationData {
  lat: number;
  lng: number;
  timestamp: number;
  speed: number; // km/h
  heading: number; // degrees
  accuracy: number; // meters
}

interface LiveLocationTrackerProps {
  donationId: string;
  donorLocation: {
    name: string;
    address: string;
    lat: number;
    lng: number;
  };
  recipientLocation: {
    name: string;
    address: string;
    lat: number;
    lng: number;
  };
  deliveryPerson: DeliveryPerson;
  onClose: () => void;
  isRecipientView?: boolean; // true for orphanage, false for restaurant
}

export function LiveLocationTracker({
  donationId,
  donorLocation,
  recipientLocation,
  deliveryPerson,
  onClose,
  isRecipientView = false
}: LiveLocationTrackerProps) {
  const [currentLocation, setCurrentLocation] = useState<LiveLocationData | null>(null);
  const [deliveryStatus, setDeliveryStatus] = useState<'pickup' | 'in_transit' | 'delivered'>('pickup');
  const [estimatedArrival, setEstimatedArrival] = useState<Date | null>(null);
  const [distanceRemaining, setDistanceRemaining] = useState<number>(0);
  const [routeProgress, setRouteProgress] = useState<number>(0);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [deliveryHistory, setDeliveryHistory] = useState<LiveLocationData[]>([]);
  const [googleMapsUrl, setGoogleMapsUrl] = useState<string>('');
  const mapRef = useRef<HTMLDivElement>(null);

  // Generate Google Maps tracking URL
  useEffect(() => {
    const destination = isRecipientView 
      ? recipientLocation.address 
      : donorLocation.address;
    
    // Create Google Maps URL with live tracking parameters
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}&travelmode=driving&dir_action=navigate`;
    setGoogleMapsUrl(mapsUrl);
  }, [donorLocation, recipientLocation, isRecipientView]);

  // Simulate real-time location updates with more realistic data
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate GPS coordinates moving from donor to recipient
      const startLat = donorLocation.lat;
      const startLng = donorLocation.lng;
      const endLat = recipientLocation.lat;
      const endLng = recipientLocation.lng;
      
      // Calculate progress based on time (simulate 12-18 minute journey)
      const journeyTime = 900000; // 15 minutes in milliseconds
      const startTime = Date.now() - (journeyTime * Math.random() * 0.7); // Started 0-70% ago
      const elapsedTime = (Date.now() - startTime) / journeyTime;
      const progress = Math.min(Math.max(elapsedTime + Math.random() * 0.05, 0), 1);
      
      // Interpolate position with some realistic variance
      const variance = 0.0003; // Small GPS variance
      const currentLat = startLat + (endLat - startLat) * progress + (Math.random() - 0.5) * variance;
      const currentLng = startLng + (endLng - startLng) * progress + (Math.random() - 0.5) * variance;
      
      const newLocation: LiveLocationData = {
        lat: currentLat,
        lng: currentLng,
        timestamp: Date.now(),
        speed: Math.max(15, 30 + Math.random() * 15 - 7.5), // 15-37 km/h realistic city speed
        heading: Math.atan2(endLng - currentLng, endLat - currentLat) * 180 / Math.PI + 90,
        accuracy: 2 + Math.random() * 3 // 2-5 meters accuracy
      };

      setCurrentLocation(newLocation);
      setDeliveryHistory(prev => [...prev.slice(-25), newLocation]); // Keep last 25 points
      setRouteProgress(progress * 100);
      setIsConnected(true);
      setLastUpdate(new Date());
      
      // Calculate distance remaining (realistic Khammam distances)
      const totalDistance = 3.2 + Math.random() * 2.8; // 3.2-6.0 km
      const remaining = totalDistance * (1 - progress);
      setDistanceRemaining(remaining);
      
      // Calculate realistic ETA based on current speed and traffic
      const speed = newLocation.speed;
      const trafficFactor = 0.7 + Math.random() * 0.4; // Traffic affects speed by 70-110%
      const effectiveSpeed = speed * trafficFactor;
      const timeRemaining = (remaining / effectiveSpeed) * 60; // minutes
      setEstimatedArrival(new Date(Date.now() + timeRemaining * 60000));
      
      // Update delivery status based on progress
      if (progress < 0.15) {
        setDeliveryStatus('pickup');
      } else if (progress < 0.92) {
        setDeliveryStatus('in_transit');
      } else {
        setDeliveryStatus('delivered');
      }
    }, 2000); // Update every 2 seconds for more live feel

    return () => clearInterval(interval);
  }, [donorLocation, recipientLocation]);

  const openGoogleMapsLive = () => {
    // Open Google Maps with live navigation to destination
    const destination = isRecipientView 
      ? recipientLocation.address 
      : donorLocation.address;
    
    openLiveNavigation(destination);
  };

  const getStatusColor = () => {
    switch (deliveryStatus) {
      case 'pickup': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'in_transit': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'delivered': return 'bg-green-100 text-green-800 border-green-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getStatusText = () => {
    switch (deliveryStatus) {
      case 'pickup': return '📦 Collecting food from restaurant';
      case 'in_transit': return '🚚 On the way to destination';
      case 'delivered': return '✅ Food delivered successfully!';
      default: return '⏳ Preparing for pickup';
    }
  };

  const formatETA = (eta: Date | null) => {
    if (!eta) return 'Calculating...';
    const now = new Date();
    const diffMinutes = Math.round((eta.getTime() - now.getTime()) / 60000);
    
    if (diffMinutes <= 0) return 'Arriving now! 🎉';
    if (diffMinutes < 60) return `${diffMinutes} min`;
    
    const hours = Math.floor(diffMinutes / 60);
    const minutes = diffMinutes % 60;
    return `${hours}h ${minutes}m`;
  };

  const getTrafficCondition = () => {
    const speed = currentLocation?.speed || 0;
    if (speed < 20) return { text: 'Heavy traffic', color: 'text-red-600', icon: '🔴' };
    if (speed < 28) return { text: 'Moderate traffic', color: 'text-yellow-600', icon: '🟡' };
    return { text: 'Light traffic', color: 'text-green-600', icon: '🟢' };
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-5xl bg-white max-h-[95vh] overflow-hidden">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Live className="h-5 w-5 text-red-500 animate-pulse" />
              Live Delivery Tracking
              <Badge className="bg-red-100 text-red-800">LIVE</Badge>
            </CardTitle>
            <Button variant="outline" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Enhanced Status Bar */}
          <div className="flex items-center gap-4 flex-wrap">
            <Badge className={`${getStatusColor()} border`}>
              {getStatusText()}
            </Badge>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
              <span>{isConnected ? 'GPS connected' : 'Connection lost'}</span>
            </div>
            <div className="text-sm text-gray-500">
              Updated: {lastUpdate.toLocaleTimeString()}
            </div>
            <Badge variant="outline" className="gap-1">
              <Zap className="h-3 w-3" />
              Real-time GPS
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Enhanced Live Map Section */}
            <div className="lg:col-span-2">
              <Card className="h-96 overflow-hidden relative">
                <div className="absolute top-4 right-4 z-10">
                  <Button 
                    onClick={openGoogleMapsLive}
                    className="bg-blue-600 hover:bg-blue-700 gap-2"
                    size="sm"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Open in Google Maps
                  </Button>
                </div>

                <div className="relative w-full h-full bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
                  
                  {/* Enhanced Map Background with Route */}
                  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 300">
                    {/* Enhanced Street Grid Background */}
                    <defs>
                      <pattern id="streets" patternUnits="userSpaceOnUse" width="40" height="40">
                        <rect width="40" height="40" fill="#f8fafc"/>
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e2e8f0" strokeWidth="1"/>
                        <path d="M 20 0 L 20 40 M 0 20 L 40 20" fill="none" stroke="#f1f5f9" strokeWidth="0.5"/>
                      </pattern>
                      
                      {/* Gradient for route */}
                      <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity="1"/>
                        <stop offset="50%" stopColor="#1d4ed8" stopOpacity="1"/>
                        <stop offset="100%" stopColor="#1e40af" stopOpacity="0.7"/>
                      </linearGradient>
                    </defs>
                    
                    <rect width="100%" height="100%" fill="url(#streets)"/>
                    
                    {/* Main Route Path - Enhanced */}
                    <path
                      d="M 60 250 Q 120 220, 180 190 T 280 140 T 340 80"
                      stroke="#e5e7eb"
                      strokeWidth="12"
                      fill="none"
                      className="opacity-40"
                    />
                    
                    {/* Completed Route - Enhanced with gradient */}
                    <path
                      d="M 60 250 Q 120 220, 180 190 T 280 140 T 340 80"
                      stroke="url(#routeGradient)"
                      strokeWidth="6"
                      fill="none"
                      strokeDasharray="500"
                      strokeDashoffset={500 - (routeProgress * 5)}
                      className="transition-all duration-1000"
                    />
                    
                    {/* Enhanced Delivery Trail with pulsing effect */}
                    {deliveryHistory.slice(-8).map((point, index) => (
                      <circle
                        key={index}
                        cx={60 + (routeProgress * 2.8)}
                        cy={250 - (routeProgress * 1.7)}
                        r={3 - index * 0.3}
                        fill="#3b82f6"
                        className="animate-pulse"
                        style={{ 
                          opacity: 0.9 - index * 0.1,
                          animationDelay: `${index * 200}ms`
                        }}
                      />
                    ))}
                    
                    {/* Restaurant Location - Enhanced */}
                    <g transform="translate(60, 250)">
                      <circle r="15" fill="#f97316" className="animate-pulse"/>
                      <circle r="20" fill="none" stroke="#f97316" strokeWidth="3" className="animate-ping"/>
                      <circle r="25" fill="none" stroke="#f97316" strokeWidth="1" className="animate-ping" style={{animationDelay: '1s'}}/>
                      <text y="-32" textAnchor="middle" className="fill-orange-700 text-sm font-bold">
                        🏪 {donorLocation.name.split(' ')[0]}
                      </text>
                    </g>
                    
                    {/* Orphanage Location - Enhanced */}
                    <g transform="translate(340, 80)">
                      <circle r="15" fill="#16a34a"/>
                      <circle r="20" fill="none" stroke="#16a34a" strokeWidth="3" className="animate-pulse"/>
                      <circle r="25" fill="none" stroke="#16a34a" strokeWidth="1" className="animate-pulse" style={{animationDelay: '1.5s'}}/>
                      <text y="-32" textAnchor="middle" className="fill-green-700 text-sm font-bold">
                        🏠 Orphanage
                      </text>
                    </g>
                    
                    {/* Enhanced Live Delivery Person */}
                    <g transform={`translate(${60 + (routeProgress * 2.8)}, ${250 - (routeProgress * 1.7)})`}>
                      <circle r="12" fill="#1d4ed8" className="animate-pulse"/>
                      <circle r="16" fill="none" stroke="#1d4ed8" strokeWidth="3" className="animate-ping"/>
                      <circle r="22" fill="none" stroke="#1d4ed8" strokeWidth="1" className="animate-ping" style={{animationDelay: '0.5s'}}/>
                      
                      {/* Enhanced Delivery Vehicle Icon */}
                      <g transform="translate(-6, -6)">
                        <rect width="12" height="8" rx="2" fill="white" stroke="#1d4ed8" strokeWidth="1"/>
                        <circle cx="3" cy="9" r="1.5" fill="#1d4ed8"/>
                        <circle cx="9" cy="9" r="1.5" fill="#1d4ed8"/>
                      </g>
                      
                      {/* Speed and ETA Indicator */}
                      <text y="-28" textAnchor="middle" className="fill-blue-700 text-xs font-bold">
                        🚚 {currentLocation ? Math.round(currentLocation.speed) : 0} km/h
                      </text>
                      <text y="-18" textAnchor="middle" className="fill-blue-600 text-xs">
                        ETA: {formatETA(estimatedArrival)}
                      </text>
                      
                      {/* Direction Arrow - Enhanced */}
                      <g transform={`rotate(${currentLocation?.heading || 0}) translate(0, -20)`}>
                        <path d="M 0 -4 L 4 4 L 0 2 L -4 4 Z" fill="#1d4ed8"/>
                      </g>
                    </g>
                    
                    {/* Route Milestones with names */}
                    <g>
                      <circle cx="120" cy="220" r="3" fill="#6b7280"/>
                      <text x="120" y="235" textAnchor="middle" className="fill-gray-600 text-xs">Market</text>
                    </g>
                    <g>
                      <circle cx="180" cy="190" r="3" fill="#6b7280"/>
                      <text x="180" y="205" textAnchor="middle" className="fill-gray-600 text-xs">Bridge</text>
                    </g>
                    <g>
                      <circle cx="280" cy="140" r="3" fill="#6b7280"/>
                      <text x="280" y="155" textAnchor="middle" className="fill-gray-600 text-xs">Circle</text>
                    </g>
                    
                    {/* Enhanced Area Labels */}
                    <text x="50" y="285" className="fill-gray-700 text-sm font-medium">Station Road</text>
                    <text x="200" y="170" className="fill-gray-700 text-sm font-medium">KTR Circle</text>
                    <text x="300" y="50" className="fill-gray-700 text-sm font-medium">Wyra Road</text>
                  </svg>
                  
                  {/* Enhanced Live Status Overlay */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="bg-white/95 backdrop-blur-sm rounded-lg p-4 shadow-lg border">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                          <span className="font-medium">Live GPS Tracking</span>
                          <Badge variant="outline" className="text-xs">
                            {getTrafficCondition().icon} {getTrafficCondition().text}
                          </Badge>
                        </div>
                        <Badge variant="outline" className="text-blue-600 font-bold">
                          {Math.round(routeProgress)}% Complete
                        </Badge>
                      </div>
                      <Progress value={routeProgress} className="h-3 mb-2" />
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>Distance: {distanceRemaining.toFixed(1)} km remaining</span>
                        <span>Speed: {currentLocation?.speed.toFixed(0)} km/h</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            {/* Enhanced Information Panel */}
            <div className="space-y-4">
              
              {/* Delivery Person Info - Enhanced */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                      <Truck className="h-7 w-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-lg">{deliveryPerson.name}</div>
                      <div className="text-sm text-gray-600">{deliveryPerson.vehicle}</div>
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <span key={i} className={`text-sm ${i < deliveryPerson.rating ? 'text-yellow-500' : 'text-gray-300'}`}>
                            ⭐
                          </span>
                        ))}
                        <span className="text-sm text-gray-500 ml-1">({deliveryPerson.rating}/5)</span>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">
                      ACTIVE
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => makePhoneCall(deliveryPerson.phone)}
                      className="flex items-center gap-1"
                    >
                      <Phone className="h-3 w-3" />
                      Call
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="flex items-center gap-1"
                    >
                      <MessageSquare className="h-3 w-3" />
                      Message
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced ETA & Distance */}
              <Card>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <div className="text-center p-4 bg-gradient-to-br from-green-50 to-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600 mb-1">
                        {formatETA(estimatedArrival)}
                      </div>
                      <div className="text-sm text-gray-600">Estimated Arrival</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 text-center">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="font-bold text-blue-600">{distanceRemaining.toFixed(1)} km</div>
                        <div className="text-xs text-gray-600">Distance</div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="font-bold text-purple-600">
                          {currentLocation ? Math.round(currentLocation.speed) : 0} km/h
                        </div>
                        <div className="text-xs text-gray-600">Speed</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">GPS Accuracy:</span>
                      <Badge variant="outline" className="text-green-600">
                        ±{currentLocation ? currentLocation.accuracy.toFixed(0) : 0}m
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Traffic:</span>
                      <span className={`font-medium ${getTrafficCondition().color}`}>
                        {getTrafficCondition().icon} {getTrafficCondition().text}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Route Actions */}
              <Card>
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <Button 
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={openGoogleMapsLive}
                    >
                      <Navigation className="h-4 w-4 mr-2" />
                      Open Google Maps
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        // Share tracking link
                        navigator.share?.({
                          title: 'Live Delivery Tracking - FoodBridge',
                          text: `Track your food delivery live! ETA: ${formatETA(estimatedArrival)}`,
                          url: window.location.href
                        });
                      }}
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Share Live Link
                    </Button>

                    <div className="pt-2 text-center">
                      <p className="text-xs text-gray-500">
                        Your pickup partner is on the move! Tap 'Open Google Maps' for real-time navigation.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Delivery Updates */}
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3 flex items-center gap-2">
                    <RefreshCw className="h-4 w-4" />
                    Live Updates
                  </h4>
                  <div className="space-y-3 text-sm">
                    {deliveryStatus === 'delivered' && (
                      <div className="flex items-center gap-2 text-green-600 p-2 bg-green-50 rounded">
                        <CheckCircle className="h-4 w-4" />
                        <span>Food delivered successfully! 🎉</span>
                      </div>
                    )}
                    {deliveryStatus === 'in_transit' && (
                      <div className="flex items-center gap-2 text-blue-600 p-2 bg-blue-50 rounded">
                        <Route className="h-4 w-4" />
                        <span>En route to destination via {getTrafficCondition().text.toLowerCase()}</span>
                      </div>
                    )}
                    {deliveryStatus === 'pickup' && (
                      <div className="flex items-center gap-2 text-yellow-600 p-2 bg-yellow-50 rounded">
                        <Clock className="h-4 w-4" />
                        <span>Collecting food from restaurant</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-gray-600 text-xs">
                      <Live className="h-3 w-3" />
                      <span>GPS updated {Math.round(2 + Math.random() * 8)} seconds ago</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Enhanced Real-time Alerts */}
          {deliveryStatus === 'delivered' && (
            <Alert className="mt-6 border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                <div className="font-medium">🎉 Delivery Complete!</div>
                <div className="text-sm mt-1">
                  Your food donation has been successfully delivered to {recipientLocation.name}. 
                  Thank you for helping feed children in Khammam! The delivery took {Math.round(15 + Math.random() * 8)} minutes.
                </div>
              </AlertDescription>
            </Alert>
          )}

          {routeProgress > 85 && deliveryStatus !== 'delivered' && (
            <Alert className="mt-6 border-blue-200 bg-blue-50">
              <AlertTriangle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <div className="font-medium">Almost There! 🚚</div>
                <div className="text-sm mt-1">
                  Your delivery partner is approaching the destination. ETA: {formatETA(estimatedArrival)}
                  <br />
                  <strong>Tap 'Open Google Maps' to follow their exact route!</strong>
                </div>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
}