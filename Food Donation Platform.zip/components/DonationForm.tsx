import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { CalendarIcon } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface DonationFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

export function DonationForm({ onClose, onSuccess }: DonationFormProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    food_type: '',
    quantity: '',
    unit: 'kg',
    expiration_date: '',
    pickup_instructions: '',
    available_from: '',
    available_until: ''
  });

  const foodTypes = [
    'Fresh Produce',
    'Dairy Products',
    'Meat & Poultry',
    'Seafood',
    'Bakery Items',
    'Canned Goods',
    'Dry Goods',
    'Frozen Foods',
    'Prepared Meals',
    'Beverages',
    'Other'
  ];

  const units = [
    'kg', 'lbs', 'pieces', 'boxes', 'bags', 'liters', 'gallons', 'servings'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    setError('');

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-e4b54fa0/donations`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            ...formData,
            quantity: parseFloat(formData.quantity)
          }),
        }
      );

      const result = await response.json();

      if (response.ok) {
        onSuccess();
      } else {
        setError(result.error || 'Failed to create donation');
      }
    } catch (error) {
      setError('Network error occurred');
      console.error('Error creating donation:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Set default dates
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Post New Donation</DialogTitle>
          <DialogDescription>
            Share your available food donations with organizations in need. Fill out the details below to help connect your surplus food with those who can use it.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="title">Donation Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleChange('title', e.target.value)}
                placeholder="e.g., Fresh vegetables from daily harvest"
                required
              />
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Detailed description of the food items..."
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="food_type">Food Type *</Label>
              <Select value={formData.food_type} onValueChange={(value) => handleChange('food_type', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select food type" />
                </SelectTrigger>
                <SelectContent>
                  {foodTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <div className="flex-1">
                <Label htmlFor="quantity">Quantity *</Label>
                <Input
                  id="quantity"
                  type="number"
                  step="0.1"
                  min="0"
                  value={formData.quantity}
                  onChange={(e) => handleChange('quantity', e.target.value)}
                  required
                />
              </div>
              <div className="w-24">
                <Label htmlFor="unit">Unit</Label>
                <Select value={formData.unit} onValueChange={(value) => handleChange('unit', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {units.map(unit => (
                      <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="expiration_date">Expiration Date *</Label>
              <Input
                id="expiration_date"
                type="date"
                value={formData.expiration_date}
                onChange={(e) => handleChange('expiration_date', e.target.value)}
                min={today}
                required
              />
            </div>

            <div>
              <Label htmlFor="available_from">Available From</Label>
              <Input
                id="available_from"
                type="datetime-local"
                value={formData.available_from}
                onChange={(e) => handleChange('available_from', e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="available_until">Available Until</Label>
              <Input
                id="available_until"
                type="datetime-local"
                value={formData.available_until}
                onChange={(e) => handleChange('available_until', e.target.value)}
              />
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="pickup_instructions">Pickup Instructions</Label>
              <Textarea
                id="pickup_instructions"
                value={formData.pickup_instructions}
                onChange={(e) => handleChange('pickup_instructions', e.target.value)}
                placeholder="Special instructions for pickup (e.g., back entrance, specific hours, contact person...)"
                rows={2}
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button 
              type="submit" 
              disabled={loading}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {loading ? 'Posting...' : 'Post Donation'}
            </Button>
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
              className="px-8"
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}