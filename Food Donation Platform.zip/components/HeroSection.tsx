import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ArrowRight, Heart, Users, Utensils } from "lucide-react";
import { useState } from "react";
import { AuthModal } from "./AuthModal";

export function HeroSection() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'signin' | 'signup'>('signup');

  const handleOrphanageClick = () => {
    setAuthModalTab('signup');
    setAuthModalOpen(true);
  };

  const handleRestaurantClick = () => {
    setAuthModalTab('signup');
    setAuthModalOpen(true);
  };

  return (
    <>
      <section id="home" className="relative bg-gradient-to-br from-green-50 to-green-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <Heart className="h-8 w-8 text-green-600 mr-3" />
                <span className="text-green-600 font-semibold">Fighting Hunger Together</span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                Connect Food Donors with 
                <span className="text-green-600"> Orphanages</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                FoodBridge connects restaurants and grocery stores with orphanages to reduce food waste and fight hunger. 
                Join our mission to ensure no good food goes to waste while feeding those in need.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button 
                  size="lg" 
                  className="bg-green-600 hover:bg-green-700 transition-all duration-200 transform hover:scale-105"
                  onClick={handleOrphanageClick}
                >
                  <Users className="mr-2 h-5 w-5" />
                  I'm an Orphanage
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-green-600 text-green-600 hover:bg-green-50 transition-all duration-200 transform hover:scale-105"
                  onClick={handleRestaurantClick}
                >
                  <Utensils className="mr-2 h-5 w-5" />
                  I'm a Restaurant/Grocery
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              
              <div className="grid grid-cols-3 gap-8 pt-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">13,940+</div>
                  <div className="text-sm text-gray-600">Meals Donated</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">85+</div>
                  <div className="text-sm text-gray-600">Organizations</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">32+</div>
                  <div className="text-sm text-gray-600">Cities</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80"
                alt="Community food sharing"
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg animate-pulse">
                <div className="flex items-center">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Heart className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-semibold text-gray-900">Impact Today</div>
                    <div className="text-xs text-gray-600">42 meals donated</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <AuthModal 
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialTab={authModalTab}
      />
    </>
  );
}