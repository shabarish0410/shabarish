import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  ArrowLeft,
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Users, 
  Award, 
  Heart,
  ChefHat,
  Baby,
  Star,
  Calendar,
  Package,
  TrendingUp,
  Shield,
  CheckCircle,
  MessageSquare
} from 'lucide-react';

interface OrganizationProfileProps {
  organizationId: string;
  onClose: () => void;
  onMessage?: (orgId: string) => void;
}

export function OrganizationProfile({ organizationId, onClose, onMessage }: OrganizationProfileProps) {
  const [organization, setOrganization] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching organization data
    setTimeout(() => {
      // Sample organization data based on ID
      const orgData = {
        'donor-1': {
          id: 'donor-1',
          name: 'Haveli Restaurant',
          type: 'donor',
          category: 'Fine Dining Restaurant',
          address: 'Station Road, Khammam, Telangana 507001',
          phone: '+91 8341266934',
          email: 'contact@havelikhammam.com',
          established: '2015',
          description: 'Premium traditional restaurant serving authentic Hyderabadi and Telangana cuisine. Known for our signature biryanis and commitment to reducing food waste.',
          image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
          stats: {
            totalDonations: 127,
            mealsProvided: 3200,
            wasteReduced: '450 kg',
            monthlyDonations: 18,
            activeYears: 2
          },
          certifications: ['Food Safety Certified', 'Hygiene Excellence', 'Community Partner'],
          operatingHours: 'Daily 11:00 AM - 11:00 PM',
          specialties: ['Hyderabadi Biryani', 'Traditional Curries', 'Fresh Rotis'],
          rating: 4.8,
          reviews: 156,
          recentDonations: [
            { date: '2024-01-15', item: 'Chicken Biryani', quantity: '15 portions', status: 'completed' },
            { date: '2024-01-14', item: 'Vegetable Curry', quantity: '20 meals', status: 'completed' },
            { date: '2024-01-13', item: 'Fresh Rotis', quantity: '30 pieces', status: 'completed' }
          ]
        },
        'recipient-1': {
          id: 'recipient-1',
          name: 'Balala Vikasa Kendra Orphanage',
          type: 'recipient',
          category: 'Children\'s Home',
          address: 'Wyra Road, Khammam, Telangana 507002',
          phone: '+91 9441234567',
          email: 'info@balalavikasa.org',
          established: '2008',
          description: 'Dedicated to caring for orphaned and underprivileged children in Khammam. We provide shelter, education, and nutritious meals to 45 children aged 5-17.',
          image: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800',
          stats: {
            childrenCount: 45,
            mealsReceived: 2800,
            donorsHelped: 23,
            monthlyNeeds: '850 meals',
            activeYears: 16
          },
          certifications: ['NGO Registration', 'Child Welfare License', 'Educational Institute'],
          operatingHours: '24/7 Residential Care',
          specialties: ['Child Education', 'Nutritional Care', 'Skill Development'],
          rating: 4.9,
          reviews: 89,
          recentClaims: [
            { date: '2024-01-15', item: 'Fresh Fruit Bowls', quantity: '30 bowls', donor: 'Khammam Fruit Market' },
            { date: '2024-01-14', item: 'Breakfast Combo', quantity: '40 sets', donor: 'Udupi Bhavan' },
            { date: '2024-01-13', item: 'Mixed Vegetables', quantity: '20 meals', donor: 'Reliance Fresh' }
          ]
        }
      };

      const mockOrg = orgData[organizationId as keyof typeof orgData] || orgData['donor-1'];
      setOrganization(mockOrg);
      setLoading(false);
    }, 800);
  }, [organizationId]);

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-2xl bg-white">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Loading organization profile...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!organization) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-2xl bg-white">
          <CardContent className="p-8 text-center">
            <p>Organization not found</p>
            <Button onClick={onClose} className="mt-4">Close</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isDonor = organization.type === 'donor';

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <Card className="w-full max-w-4xl bg-white max-h-[95vh] overflow-hidden">
        
        {/* Header */}
        <div className="relative">
          <div className="h-48 bg-gradient-to-r from-blue-600 to-purple-600 relative overflow-hidden">
            <ImageWithFallback
              src={organization.image}
              alt={organization.name}
              className="w-full h-full object-cover opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            
            {/* Back Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              className="absolute top-4 left-4 bg-white/90 hover:bg-white"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>

            {/* Organization Info Overlay */}
            <div className="absolute bottom-4 left-4 right-4 text-white">
              <div className="flex items-start gap-4">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                  isDonor ? 'bg-orange-600' : 'bg-blue-600'
                }`}>
                  {isDonor ? (
                    <ChefHat className="h-8 w-8 text-white" />
                  ) : (
                    <Baby className="h-8 w-8 text-white" />
                  )}
                </div>
                
                <div className="flex-1">
                  <h1 className="text-2xl font-bold mb-1">{organization.name}</h1>
                  <p className="text-white/90 mb-2">{organization.category}</p>
                  
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>Khammam, Telangana</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-400" />
                      <span>{organization.rating}/5 ({organization.reviews} reviews)</span>
                    </div>
                    {isDonor && (
                      <Badge className="bg-green-600 text-white">
                        {organization.stats.totalDonations} donations
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    size="sm"
                    onClick={() => onMessage?.(organization.id)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Message
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <CardContent className="p-6">
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="impact">Impact</TabsTrigger>
              <TabsTrigger value="contact">Contact</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* About */}
                <Card>
                  <CardHeader>
                    <CardTitle>About {organization.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{organization.description}</p>
                    
                    <div className="space-y-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span>Established in {organization.established}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span>{organization.operatingHours}</span>
                      </div>
                      {isDonor ? (
                        <div className="flex items-center gap-2">
                          <ChefHat className="h-4 w-4 text-gray-500" />
                          <span>Specializes in {organization.specialties.join(', ')}</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-gray-500" />
                          <span>Caring for {organization.stats.childrenCount} children</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Statistics */}
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {isDonor ? 'Donation Statistics' : 'Care Statistics'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      {isDonor ? (
                        <>
                          <div className="text-center p-3 bg-green-50 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">
                              {organization.stats.totalDonations}
                            </div>
                            <div className="text-sm text-gray-600">Total Donations</div>
                          </div>
                          <div className="text-center p-3 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">
                              {organization.stats.mealsProvided}
                            </div>
                            <div className="text-sm text-gray-600">Meals Provided</div>
                          </div>
                          <div className="text-center p-3 bg-purple-50 rounded-lg">
                            <div className="text-2xl font-bold text-purple-600">
                              {organization.stats.wasteReduced}
                            </div>
                            <div className="text-sm text-gray-600">Waste Reduced</div>
                          </div>
                          <div className="text-center p-3 bg-orange-50 rounded-lg">
                            <div className="text-2xl font-bold text-orange-600">
                              {organization.stats.monthlyDonations}
                            </div>
                            <div className="text-sm text-gray-600">This Month</div>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="text-center p-3 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">
                              {organization.stats.childrenCount}
                            </div>
                            <div className="text-sm text-gray-600">Children</div>
                          </div>
                          <div className="text-center p-3 bg-green-50 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">
                              {organization.stats.mealsReceived}
                            </div>
                            <div className="text-sm text-gray-600">Meals Received</div>
                          </div>
                          <div className="text-center p-3 bg-purple-50 rounded-lg">
                            <div className="text-2xl font-bold text-purple-600">
                              {organization.stats.donorsHelped}
                            </div>
                            <div className="text-sm text-gray-600">Partner Donors</div>
                          </div>
                          <div className="text-center p-3 bg-orange-50 rounded-lg">
                            <div className="text-2xl font-bold text-orange-600">
                              {organization.stats.activeYears}
                            </div>
                            <div className="text-sm text-gray-600">Years Active</div>
                          </div>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Certifications */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-green-600" />
                    Certifications & Verification
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {organization.certifications.map((cert: string, index: number) => (
                      <Badge key={index} variant="outline" className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                        {cert}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600 mt-3">
                    All certifications verified by FoodBridge team • Last updated: January 2024
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>
                    Recent {isDonor ? 'Donations' : 'Food Claims'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {(isDonor ? organization.recentDonations : organization.recentClaims).map((item: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            isDonor ? 'bg-orange-100' : 'bg-blue-100'
                          }`}>
                            <Package className={`h-5 w-5 ${
                              isDonor ? 'text-orange-600' : 'text-blue-600'
                            }`} />
                          </div>
                          <div>
                            <div className="font-medium">{item.item}</div>
                            <div className="text-sm text-gray-600">
                              {item.quantity} • {new Date(item.date).toLocaleDateString()}
                              {!isDonor && item.donor && (
                                <span> • from {item.donor}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <Badge className={
                          (item.status === 'completed' || !item.status) 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-blue-100 text-blue-800'
                        }>
                          {item.status || 'completed'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Impact Tab */}
            <TabsContent value="impact" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Heart className="h-5 w-5 text-red-500" />
                      Community Impact
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isDonor ? (
                      <div className="space-y-4">
                        <div className="text-center p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
                          <div className="text-3xl font-bold text-green-600 mb-2">
                            {organization.stats.mealsProvided}
                          </div>
                          <div className="text-gray-600">Total meals provided to children</div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <div className="text-xl font-bold text-blue-600">{organization.stats.wasteReduced}</div>
                            <div className="text-xs text-gray-600">Food waste prevented</div>
                          </div>
                          <div>
                            <div className="text-xl font-bold text-purple-600">12</div>
                            <div className="text-xs text-gray-600">Orphanages helped</div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="text-center p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                          <div className="text-3xl font-bold text-blue-600 mb-2">
                            {organization.stats.childrenCount}
                          </div>
                          <div className="text-gray-600">Children receiving regular meals</div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <div className="text-xl font-bold text-green-600">{organization.stats.mealsReceived}</div>
                            <div className="text-xs text-gray-600">Meals received</div>
                          </div>
                          <div>
                            <div className="text-xl font-bold text-orange-600">{organization.stats.donorsHelped}</div>
                            <div className="text-xs text-gray-600">Partner restaurants</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-blue-500" />
                      Monthly Progress
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Monthly Goal</span>
                          <span>
                            {isDonor ? `${organization.stats.monthlyDonations}/25` : `${Math.floor(parseInt(organization.stats.monthlyNeeds) * 0.8)}/${organization.stats.monthlyNeeds.split(' ')[0]}`}
                          </span>
                        </div>
                        <Progress 
                          value={isDonor ? (organization.stats.monthlyDonations / 25) * 100 : 80} 
                          className="h-2" 
                        />
                      </div>
                      <div className="text-sm text-gray-600">
                        {isDonor 
                          ? 'Exceeding monthly donation goals helps more children in Khammam'
                          : 'Regular meal support ensures nutritional security for our children'
                        }
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Contact Tab */}
            <TabsContent value="contact" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-3">
                      <MapPin className="h-5 w-5 text-gray-500" />
                      <div>
                        <div className="font-medium">Address</div>
                        <div className="text-sm text-gray-600">{organization.address}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-gray-500" />
                      <div>
                        <div className="font-medium">Phone</div>
                        <div className="text-sm text-gray-600">{organization.phone}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-gray-500" />
                      <div>
                        <div className="font-medium">Email</div>
                        <div className="text-sm text-gray-600">{organization.email}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Clock className="h-5 w-5 text-gray-500" />
                      <div>
                        <div className="font-medium">Hours</div>
                        <div className="text-sm text-gray-600">{organization.operatingHours}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button 
                      className="w-full justify-start"
                      onClick={() => onMessage?.(organization.id)}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Send Message
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => window.open(`tel:${organization.phone}`)}
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => window.open(`mailto:${organization.email}`)}
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Send Email
                    </Button>

                    <Alert className="mt-4">
                      <Shield className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Verified Organization</strong><br />
                        This organization has been verified by the FoodBridge team and follows all safety protocols.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}