import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Code, Coffee, MapPinIcon as Live } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center mb-4">
              <Heart className="h-8 w-8 text-green-500" />
              <span className="ml-2 text-xl font-semibold">FoodBridge</span>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Connecting restaurants and grocery stores with orphanages to reduce food waste 
              and fight hunger in our communities. Every meal shared makes a difference.
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-6 w-6 text-gray-400 hover:text-white cursor-pointer" />
              <Twitter className="h-6 w-6 text-gray-400 hover:text-white cursor-pointer" />
              <Instagram className="h-6 w-6 text-gray-400 hover:text-white cursor-pointer" />
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#home" className="hover:text-white">Home</a></li>
              <li><a href="#how-it-works" className="hover:text-white">How It Works</a></li>
              <li><a href="#donations" className="hover:text-white">Donations</a></li>
              <li><a href="#organizations" className="hover:text-white">Organizations</a></li>
              <li><a href="#" className="hover:text-white">About Us</a></li>
              <li><a href="#" className="hover:text-white">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-3 text-gray-300">
              <div className="flex items-center">
                <Mail className="h-5 w-5 mr-3" />
                <span className="not-italic font-normal font-bold">shabarishreddy12@gmail.com</span>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-3" />
                <span>+91 8341266934</span>
              </div>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-3" />
                <span>Khammam, Telangana, India</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Project Banner Section */}
        <div className="border-t border-gray-800 mt-8 pt-6 pb-4">
          <div className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 rounded-lg p-4 border border-blue-800/30">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3 flex-wrap">
                <Code className="h-4 w-4 text-blue-400" />
                <div className="text-blue-300 text-sm">
                  <strong>🚀 FoodBridge Platform</strong> • Built with React, TypeScript & Tailwind CSS • 
                  Connecting restaurants with orphanages in Khammam to reduce food waste and fight hunger
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Coffee className="h-4 w-4 text-orange-400" />
                <span className="text-xs text-gray-400">Live Demo</span>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-gray-700/50">
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <Live className="h-4 w-4 text-red-500 animate-pulse" />
                <span className="text-green-400 font-medium text-sm">🔴 NEW: Live GPS tracking with Google Maps integration!</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-6 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-center md:text-left">
              <p className="text-gray-400 text-sm">
                © 2025 FoodBridge. All rights reserved.
              </p>
              <p className="text-gray-500 text-xs mt-1">
                Built with React + TypeScript • Part of App.tsx project structure
              </p>
            </div>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}