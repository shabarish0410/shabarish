import { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MessageSquare, Phone, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface SMSNotificationProps {
  message: string;
  phoneNumber: string;
  recipientName: string;
  onClose: () => void;
}

interface SMSStatus {
  status: 'sending' | 'sent' | 'delivered' | 'failed';
  timestamp: Date;
  messageId: string;
}

export function SMSNotification({ message, phoneNumber, recipientName, onClose }: SMSNotificationProps) {
  const [smsStatus, setSmsStatus] = useState<SMSStatus>({
    status: 'sending',
    timestamp: new Date(),
    messageId: `SMS${Date.now()}`
  });

  useEffect(() => {
    // Simulate SMS sending process
    const sendSMS = async () => {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setSmsStatus(prev => ({
        ...prev,
        status: 'sent',
        timestamp: new Date()
      }));

      // Simulate delivery confirmation
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setSmsStatus(prev => ({
        ...prev,
        status: 'delivered',
        timestamp: new Date()
      }));

      // Auto close after successful delivery
      setTimeout(() => {
        onClose();
      }, 2000);
    };

    sendSMS().catch(() => {
      setSmsStatus(prev => ({
        ...prev,
        status: 'failed',
        timestamp: new Date()
      }));
    });
  }, [onClose]);

  const getStatusIcon = () => {
    switch (smsStatus.status) {
      case 'sending':
        return <Clock className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'sent':
        return <MessageSquare className="h-4 w-4 text-yellow-500" />;
      case 'delivered':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = () => {
    switch (smsStatus.status) {
      case 'sending':
        return 'Sending SMS...';
      case 'sent':
        return 'SMS Sent';
      case 'delivered':
        return 'SMS Delivered';
      case 'failed':
        return 'SMS Failed';
    }
  };

  const getStatusColor = () => {
    switch (smsStatus.status) {
      case 'sending':
        return 'bg-blue-100 text-blue-800';
      case 'sent':
        return 'bg-yellow-100 text-yellow-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              <h3 className="font-semibold">SMS Notification</h3>
            </div>
            <Badge className={getStatusColor()}>
              {getStatusIcon()}
              <span className="ml-2">{getStatusText()}</span>
            </Badge>
          </div>

          <div className="space-y-4">
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Phone className="h-4 w-4 text-gray-500" />
                <span className="text-sm font-medium">To: {recipientName}</span>
              </div>
              <div className="text-sm text-gray-600">{phoneNumber}</div>
            </div>

            <div className="bg-blue-50 p-3 rounded-lg">
              <h4 className="text-sm font-medium text-blue-900 mb-2">Message Content:</h4>
              <p className="text-sm text-blue-800">{message}</p>
            </div>

            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>Message ID: {smsStatus.messageId}</span>
              <span>{smsStatus.timestamp.toLocaleTimeString()}</span>
            </div>

            {smsStatus.status === 'delivered' && (
              <div className="bg-green-50 p-3 rounded-lg">
                <div className="flex items-center gap-2 text-green-800">
                  <CheckCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">SMS delivered successfully!</span>
                </div>
                <p className="text-xs text-green-700 mt-1">
                  The recipient has been notified about the donation claim.
                </p>
              </div>
            )}

            {smsStatus.status === 'failed' && (
              <div className="bg-red-50 p-3 rounded-lg">
                <div className="flex items-center gap-2 text-red-800">
                  <AlertCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">Failed to send SMS</span>
                </div>
                <p className="text-xs text-red-700 mt-1">
                  Please try calling the donor directly or contact support.
                </p>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              {smsStatus.status === 'failed' && (
                <Button 
                  size="sm" 
                  className="flex-1"
                  onClick={() => window.open(`tel:${phoneNumber}`)}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call Instead
                </Button>
              )}
              <Button 
                variant="outline" 
                size="sm"
                onClick={onClose}
                className={smsStatus.status === 'failed' ? '' : 'flex-1'}
              >
                {smsStatus.status === 'delivered' ? 'Done' : 'Close'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// SMS notification utility functions
export const createClaimNotificationSMS = (donationTitle: string, recipientName: string, recipientPhone: string) => {
  return `🍽️ FoodBridge Khammam Alert

Your donation "${donationTitle}" has been claimed by ${recipientName}.

Contact: ${recipientPhone}

They will coordinate pickup directly with you. Thank you for supporting our community!

- FoodBridge Team`;
};

export const createPickupReminderSMS = (donorName: string, donationTitle: string, pickupTime: string) => {
  return `🚚 Pickup Reminder - FoodBridge

Reminder: Pickup scheduled today at ${pickupTime}

Donation: ${donationTitle}
From: ${donorName}

Please arrive on time and bring your organization ID. Thank you!

- FoodBridge Khammam`;
};

export const createDonationAvailableSMS = (recipientName: string, donationType: string, donorName: string) => {
  return `🍽️ New Donation Alert - FoodBridge

New ${donationType} available from ${donorName} in Khammam!

Login to FoodBridge to claim: foodbridge-khammam.com

Fresh donations go fast - claim now!

- FoodBridge Team`;
};