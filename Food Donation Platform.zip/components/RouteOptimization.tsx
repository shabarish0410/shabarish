import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { MapPin, Navigation, Clock, Truck, Route, Phone, ChevronRight, Car, User, Maximize2, Minimize2, X } from 'lucide-react';
import { openDirections, makePhoneCall } from '../utils/navigation';

interface Location {
  id: string;
  name: string;
  address: string;
  phone: string;
  coordinates: [number, number]; // [latitude, longitude]
  estimatedTime: number; // minutes
  distance: number; // km
}

interface RouteOptimizationProps {
  pickupLocations: {
    donationId: string;
    donorName: string;
    donorAddress: string;
    donorPhone: string;
  }[];
  recipientLocation?: {
    name: string;
    address: string;
  };
  onClose?: () => void;
  mode?: 'inline' | 'fullscreen'; // New prop for display mode
  onModeChange?: (mode: 'inline' | 'fullscreen') => void;
}

// Khammam coordinates and locations
const KHAMMAM_LOCATIONS: { [key: string]: [number, number] } = {
  'Haveli Restaurant': [17.2473, 80.1514],
  'Annapurna Family Restaurant': [17.2456, 80.1498],
  'Reliance Fresh Grocery': [17.2489, 80.1532],
  'Sri Venkateswara Dairy & Sweets': [17.2445, 80.1485],
  'Udupi Krishna Hotel': [17.2463, 80.1507],
  'Big Bazaar Khammam': [17.2501, 80.1545],
  'Kakatiya Family Restaurant': [17.2478, 80.1521],
  'Raghavendra Tea Stall & Snacks': [17.2441, 80.1479],
  'Balala Vikasa Kendra': [17.2435, 80.1542],
  'Khammam Children\'s Home': [17.2467, 80.1489]
};

export function RouteOptimization({ 
  pickupLocations, 
  recipientLocation, 
  onClose, 
  mode = 'inline',
  onModeChange 
}: RouteOptimizationProps) {
  const [optimizedRoute, setOptimizedRoute] = useState<Location[]>([]);
  const [totalDistance, setTotalDistance] = useState(0);
  const [totalTime, setTotalTime] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [isNavigating, setIsNavigating] = useState(false);
  const [animationProgress, setAnimationProgress] = useState(0);
  const [isMoving, setIsMoving] = useState(false);

  // Animation state for movement visualization
  const [currentPosition, setCurrentPosition] = useState({ x: 0, y: 0 });
  const [targetPosition, setTargetPosition] = useState({ x: 0, y: 0 });
  const [movementProgress, setMovementProgress] = useState(0);

  useEffect(() => {
    optimizeRoute();
  }, [pickupLocations]);

  // Animation effect for movement between locations
  useEffect(() => {
    if (isNavigating && isMoving) {
      const interval = setInterval(() => {
        setMovementProgress(prev => {
          if (prev >= 100) {
            setIsMoving(false);
            return 0;
          }
          return prev + 2; // Adjust speed here
        });
      }, 50);

      return () => clearInterval(interval);
    }
  }, [isNavigating, isMoving]);

  // Update position based on movement progress
  useEffect(() => {
    if (isMoving && movementProgress > 0) {
      const progress = movementProgress / 100;
      const newX = currentPosition.x + (targetPosition.x - currentPosition.x) * progress;
      const newY = currentPosition.y + (targetPosition.y - currentPosition.y) * progress;
      
      // Update visual position would go here in a real implementation
      // For now, we'll just track the progress
    }
  }, [movementProgress, currentPosition, targetPosition, isMoving]);

  const optimizeRoute = () => {
    // Convert pickup locations to Location objects with Khammam coordinates
    const locations: Location[] = pickupLocations.map((pickup, index) => {
      const coords = KHAMMAM_LOCATIONS[pickup.donorName] || [17.2473, 80.1514]; // Default to center of Khammam
      return {
        id: pickup.donationId,
        name: pickup.donorName,
        address: pickup.donorAddress,
        phone: pickup.donorPhone,
        coordinates: coords,
        estimatedTime: 10 + (index * 5), // Estimated pickup time
        distance: 0 // Will be calculated
      };
    });

    // Simple route optimization algorithm (nearest neighbor)
    const optimized = nearestNeighborOptimization(locations);
    
    // Calculate distances and times
    let totalDist = 0;
    let totalTimeCalc = 0;
    
    for (let i = 0; i < optimized.length; i++) {
      if (i > 0) {
        const dist = calculateDistance(
          optimized[i-1].coordinates,
          optimized[i].coordinates
        );
        optimized[i].distance = dist;
        totalDist += dist;
        totalTimeCalc += (dist * 3) + optimized[i].estimatedTime; // 3 minutes per km + pickup time
      } else {
        optimized[i].distance = 2; // Distance from recipient to first pickup
        totalDist += 2;
        totalTimeCalc += 6 + optimized[i].estimatedTime;
      }
    }

    setOptimizedRoute(optimized);
    setTotalDistance(Math.round(totalDist * 10) / 10);
    setTotalTime(Math.round(totalTimeCalc));
  };

  const nearestNeighborOptimization = (locations: Location[]): Location[] => {
    if (locations.length <= 1) return locations;

    const optimized: Location[] = [];
    const remaining = [...locations];
    
    // Start from the first location
    optimized.push(remaining.shift()!);

    while (remaining.length > 0) {
      const current = optimized[optimized.length - 1];
      let nearestIndex = 0;
      let minDistance = calculateDistance(current.coordinates, remaining[0].coordinates);

      for (let i = 1; i < remaining.length; i++) {
        const distance = calculateDistance(current.coordinates, remaining[i].coordinates);
        if (distance < minDistance) {
          minDistance = distance;
          nearestIndex = i;
        }
      }

      optimized.push(remaining.splice(nearestIndex, 1)[0]);
    }

    return optimized;
  };

  const calculateDistance = (coord1: [number, number], coord2: [number, number]): number => {
    const [lat1, lon1] = coord1;
    const [lat2, lon2] = coord2;
    
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const startNavigation = () => {
    setIsNavigating(true);
    setCurrentStep(0);
    setAnimationProgress(0);
    startMovementToNextLocation();
  };

  const startMovementToNextLocation = () => {
    if (currentStep < optimizedRoute.length) {
      setIsMoving(true);
      setMovementProgress(0);
      
      // Calculate target position for visual movement
      // In a real map, these would be actual coordinates
      const targetX = (currentStep + 1) * 100; // Simplified positioning
      const targetY = 50 + Math.sin(currentStep) * 20; // Add some curve to the path
      
      setTargetPosition({ x: targetX, y: targetY });
    }
  };

  const nextStep = () => {
    if (currentStep < optimizedRoute.length - 1) {
      setCurrentStep(currentStep + 1);
      startMovementToNextLocation();
    } else {
      // Navigation complete
      alert('All pickups completed! Thank you for helping our community.');
      setIsNavigating(false);
      setIsMoving(false);
    }
  };

  const openInMaps = (location: Location) => {
    // Enhanced route opening with full address details and confirmation
    const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(location.address || 'Khammam, Telangana')}&travelmode=driving`;
    
    // Open in new tab and show confirmation
    window.open(googleMapsUrl, '_blank');
    
    // Add visual feedback
    alert(`🗺️ Opening route to ${location.name} in Google Maps!\n\nAddress: ${location.address}\nPhone: ${location.phone}\n\nETA: ~${location.estimatedTime} minutes`);
  };

  const callLocation = (phone: string) => {
    // Enhanced phone call with confirmation and fallback
    if (phone && phone !== '8341266934') {
      const confirmation = confirm(`📞 Call ${phone}?\n\nThis will open your phone app to call the location directly.`);
      if (confirmation) {
        window.open(`tel:${phone}`);
      }
    } else {
      alert('📞 Contact Information:\n\nPlease contact the organization directly for pickup coordination.\n\nAlternatively, you can find their contact details in the donation listing.');
    }
  };

  const calculateOverallProgress = () => {
    if (!isNavigating || optimizedRoute.length === 0) return 0;
    const baseProgress = (currentStep / optimizedRoute.length) * 100;
    const stepProgress = isMoving ? (movementProgress / optimizedRoute.length) : 0;
    return Math.min(baseProgress + stepProgress, 100);
  };

  const toggleMode = () => {
    const newMode = mode === 'inline' ? 'fullscreen' : 'inline';
    onModeChange?.(newMode);
  };

  // Content component that can be used in both modes
  const RouteContent = () => (
    <>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Route className="h-5 w-5 text-blue-600" />
            Optimized Pickup Route - Khammam
            {isNavigating && (
              <Badge className="bg-green-100 text-green-800 ml-2">
                Navigation Active
              </Badge>
            )}
          </CardTitle>
          <div className="flex gap-2">
            {onModeChange && (
              <Button variant="outline" size="sm" onClick={toggleMode}>
                {mode === 'inline' ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </Button>
            )}
            {onClose && (
              <Button variant="outline" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <MapPin className="h-4 w-4" />
            <span>{optimizedRoute.length} pickup locations</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Navigation className="h-4 w-4" />
            <span>{totalDistance} km total distance</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Clock className="h-4 w-4" />
            <span>{totalTime} minutes estimated</span>
          </div>
        </div>

        {/* Overall Progress Bar */}
        {isNavigating && (
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-blue-600 font-medium">Route Progress</span>
              <span className="text-blue-600">{Math.round(calculateOverallProgress())}%</span>
            </div>
            <Progress value={calculateOverallProgress()} className="h-3" />
            <div className="text-xs text-gray-600 text-center">
              {isMoving ? `Moving to ${optimizedRoute[currentStep]?.name || 'destination'}...` : 
               currentStep < optimizedRoute.length ? `At ${optimizedRoute[currentStep]?.name || 'location'}` : 'Route completed!'}
            </div>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Enhanced 3D Route Visualization */}
        {isNavigating && (
          <div className="bg-gradient-to-br from-blue-50 to-green-50 p-6 rounded-lg border-2 border-blue-200 overflow-hidden">
            <h3 className="font-semibold text-blue-900 mb-4 flex items-center gap-2">
              <Car className="h-5 w-5" />
              Live 3D Route Visualization
            </h3>
            
            {/* 3D Route Map with Perspective */}
            <div className="relative h-48 bg-gradient-to-b from-sky-100 to-green-100 rounded-lg border overflow-hidden"
                 style={{ perspective: '800px' }}>
              
              {/* 3D Ground Plane */}
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-green-50 to-green-100 opacity-60"
                   style={{ 
                     transform: 'rotateX(60deg) translateZ(-20px)',
                     transformOrigin: 'center bottom'
                   }} />
              
              {/* 3D Route Path with Elevation */}
              <div className="absolute inset-0 flex items-center">
                <div className="relative w-full h-2 mx-6">
                  {/* Road base with 3D effect */}
                  <div className="absolute inset-0 bg-gray-400 rounded-full shadow-lg"
                       style={{ 
                         transform: 'translateZ(2px)',
                         boxShadow: '0 4px 8px rgba(0,0,0,0.2), inset 0 -2px 4px rgba(0,0,0,0.1)'
                       }} />
                  {/* Progress road */}
                  <div 
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 rounded-full transition-all duration-1000 ease-in-out"
                    style={{ 
                      width: `${calculateOverallProgress()}%`,
                      transform: 'translateZ(3px)',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.3), 0 0 10px rgba(59, 130, 246, 0.5)'
                    }}
                  />
                  {/* Road markings */}
                  <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white opacity-60 rounded-full"
                       style={{ transform: 'translateY(-50%) translateZ(4px)' }}>
                    <div className="flex w-full h-full">
                      {Array.from({ length: 20 }, (_, i) => (
                        <div key={i} className="flex-1 border-r border-white border-dashed" />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* 3D Location Markers with Depth */}
              <div className="absolute inset-0 flex items-center justify-between px-6">
                {/* Start point with 3D effect */}
                <div className="flex flex-col items-center relative">
                  <div className="relative">
                    <div className="w-6 h-6 bg-blue-500 rounded-full border-3 border-white shadow-xl"
                         style={{ 
                           transform: 'translateZ(8px)',
                           boxShadow: '0 6px 12px rgba(59, 130, 246, 0.4), 0 0 0 3px rgba(255,255,255,0.8)'
                         }} />
                    <div className="absolute -bottom-1 left-1/2 w-4 h-2 bg-blue-400 rounded-full opacity-40 blur-sm"
                         style={{ transform: 'translateX(-50%) rotateX(70deg)' }} />
                  </div>
                  <span className="text-xs mt-2 font-medium text-blue-700 drop-shadow-sm">START</span>
                </div>
                
                {/* Pickup locations with 3D animation */}
                {optimizedRoute.map((location, index) => (
                  <div key={location.id} className="flex flex-col items-center relative">
                    <div className="relative">
                      <div className={`w-6 h-6 rounded-full border-3 border-white transition-all duration-500 ${
                        currentStep > index 
                          ? 'bg-green-500 shadow-xl' 
                          : currentStep === index 
                          ? 'bg-yellow-500 animate-pulse shadow-xl' 
                          : 'bg-gray-300 shadow-md'
                      }`}
                           style={{ 
                             transform: currentStep === index 
                               ? 'translateZ(12px) scale(1.1)' 
                               : currentStep > index 
                               ? 'translateZ(8px)' 
                               : 'translateZ(6px)',
                             boxShadow: currentStep === index 
                               ? '0 8px 16px rgba(234, 179, 8, 0.5), 0 0 20px rgba(234, 179, 8, 0.3)' 
                               : currentStep > index
                               ? '0 6px 12px rgba(34, 197, 94, 0.4)'
                               : '0 4px 8px rgba(0,0,0,0.2)'
                           }} />
                      {/* 3D Shadow */}
                      <div className={`absolute -bottom-1 left-1/2 w-4 h-2 rounded-full opacity-40 blur-sm ${
                        currentStep > index ? 'bg-green-400' :
                        currentStep === index ? 'bg-yellow-400' :
                        'bg-gray-400'
                      }`}
                           style={{ transform: 'translateX(-50%) rotateX(70deg)' }} />
                    </div>
                    <span className="text-xs mt-2 font-medium drop-shadow-sm">{index + 1}</span>
                  </div>
                ))}
              </div>
              
              {/* 3D Moving Vehicle/Person with Enhanced Effects */}
              <div 
                className="absolute top-1/2 transition-all duration-1000 ease-in-out z-10"
                style={{ 
                  left: `${Math.min(calculateOverallProgress(), 92)}%`,
                  transform: 'translateY(-50%) translateX(-50%)'
                }}
              >
                <div className="relative">
                  {/* Main 3D Vehicle */}
                  <div className={`relative w-12 h-12 rounded-lg flex items-center justify-center transition-all duration-300 ${
                    isMoving ? 'bg-gradient-to-br from-blue-400 to-blue-600' : 'bg-gradient-to-br from-green-400 to-green-600'
                  }`}
                       style={{ 
                         transform: isMoving 
                           ? 'translateZ(15px) rotateY(-10deg) rotateX(-5deg) scale(1.1)' 
                           : 'translateZ(12px) rotateY(0deg) rotateX(0deg) scale(1)',
                         boxShadow: isMoving 
                           ? '0 10px 20px rgba(59, 130, 246, 0.4), 0 0 30px rgba(59, 130, 246, 0.2)' 
                           : '0 8px 16px rgba(34, 197, 94, 0.4)',
                         animation: isMoving ? 'vehicleBounce 0.6s ease-in-out infinite' : 'none'
                       }}>
                    
                    {/* Vehicle Icon with 3D Effect */}
                    <div className="relative">
                      {isMoving ? (
                        <Truck className="h-6 w-6 text-white drop-shadow-lg" 
                               style={{ filter: 'drop-shadow(2px 2px 4px rgba(0,0,0,0.3))' }} />
                      ) : (
                        <User className="h-6 w-6 text-white drop-shadow-lg"
                              style={{ filter: 'drop-shadow(2px 2px 4px rgba(0,0,0,0.3))' }} />
                      )}
                    </div>
                    
                    {/* 3D Vehicle Details */}
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full opacity-80"
                         style={{ transform: 'translateZ(2px)' }} />
                    <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-black rounded-full opacity-20" />
                  </div>
                  
                  {/* Enhanced Movement Effects */}
                  {isMoving && (
                    <>
                      {/* Animated trail particles */}
                      <div className="absolute inset-0 w-12 h-12 rounded-lg animate-ping opacity-40"
                           style={{ 
                             background: 'radial-gradient(circle, rgba(59, 130, 246, 0.6) 0%, transparent 70%)',
                             transform: 'translateZ(8px)'
                           }} />
                      
                      {/* Speed lines */}
                      <div className="absolute top-1/2 -left-8 w-6 h-0.5 bg-blue-400 opacity-60 rounded-full"
                           style={{ 
                             transform: 'translateY(-50%) rotateZ(-5deg)',
                             animation: 'speedLine 0.3s ease-in-out infinite'
                           }} />
                      <div className="absolute top-1/2 -left-6 w-4 h-0.5 bg-blue-300 opacity-40 rounded-full"
                           style={{ 
                             transform: 'translateY(-50%) rotateZ(-3deg)',
                             animation: 'speedLine 0.3s ease-in-out infinite 0.1s'
                           }} />
                    </>
                  )}
                  
                  {/* 3D Ground Shadow */}
                  <div className="absolute -bottom-6 left-1/2 w-8 h-4 bg-black rounded-full opacity-20 blur-md"
                       style={{ 
                         transform: 'translateX(-50%) rotateX(70deg) scale(1.2)',
                         filter: 'blur(4px)'
                       }} />
                </div>
              </div>
              
              {/* 3D Environmental Elements */}
              <div className="absolute top-4 left-8 w-3 h-8 bg-green-600 rounded-t-full opacity-60"
                   style={{ transform: 'translateZ(5px) rotateX(15deg)' }} />
              <div className="absolute top-6 right-12 w-2 h-6 bg-green-500 rounded-t-full opacity-40"
                   style={{ transform: 'translateZ(3px) rotateX(10deg)' }} />
              <div className="absolute bottom-8 left-1/3 w-4 h-3 bg-yellow-400 rounded-full opacity-50"
                   style={{ transform: 'translateZ(2px)' }} />
            </div>
            
            {/* Enhanced Movement Status with 3D Text */}
            <div className="mt-6 text-center">
              {isMoving ? (
                <div className="flex items-center justify-center gap-3 text-blue-700">
                  <div className="relative">
                    <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" 
                         style={{ boxShadow: '0 0 10px rgba(59, 130, 246, 0.6)' }} />
                    <div className="absolute inset-0 w-3 h-3 bg-blue-400 rounded-full animate-ping opacity-40" />
                  </div>
                  <span className="text-sm font-medium drop-shadow-sm">
                    🚛 Moving to pickup location...
                  </span>
                  <div className="relative">
                    <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" 
                         style={{ boxShadow: '0 0 10px rgba(59, 130, 246, 0.6)' }} />
                    <div className="absolute inset-0 w-3 h-3 bg-blue-400 rounded-full animate-ping opacity-40" />
                  </div>
                </div>
              ) : currentStep < optimizedRoute.length ? (
                <div className="flex items-center justify-center gap-3 text-green-700">
                  <div className="w-3 h-3 bg-green-500 rounded-full" 
                       style={{ boxShadow: '0 0 8px rgba(34, 197, 94, 0.4)' }} />
                  <span className="text-sm font-medium drop-shadow-sm">
                    📍 Ready for pickup at {optimizedRoute[currentStep]?.name}
                  </span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-3 text-purple-700">
                  <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse" 
                       style={{ boxShadow: '0 0 10px rgba(147, 51, 234, 0.6)' }} />
                  <span className="text-sm font-medium drop-shadow-sm">
                    🎉 All pickups completed!
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Route Summary */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-semibold text-blue-900 mb-2">Route Summary</h3>
          <p className="text-blue-800 text-sm">
            Optimized route starting from {recipientLocation?.name || 'your location'} in Khammam. 
            The route is designed to minimize travel time and distance while ensuring efficient pickup coordination.
          </p>
        </div>

        {/* Navigation Controls */}
        <div className="flex gap-3">
          {!isNavigating ? (
            <Button 
              onClick={startNavigation} 
              className="bg-green-600 hover:bg-green-700"
              disabled={optimizedRoute.length === 0}
            >
              <Navigation className="h-4 w-4 mr-2" />
              Start Navigation
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button 
                onClick={nextStep}
                className="bg-blue-600 hover:bg-blue-700"
                disabled={isMoving}
              >
                {isMoving ? 'Moving...' : 
                 currentStep < optimizedRoute.length - 1 ? 'Next Pickup' : 'Complete Route'}
                {!isMoving && <ChevronRight className="h-4 w-4 ml-2" />}
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  setIsNavigating(false);
                  setIsMoving(false);
                  setCurrentStep(0);
                }}
              >
                Stop Navigation
              </Button>
            </div>
          )}
        </div>

        {/* Route Steps */}
        <div className="space-y-4">
          <h3 className="font-semibold text-gray-900">Pickup Route</h3>
          
          {/* Starting Point */}
          <div className="flex items-center gap-4 p-4 rounded-lg border-2 border-dashed border-gray-300">
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
              <span className="text-blue-600 font-medium text-sm">START</span>
            </div>
            <div className="flex-1">
              <h4 className="font-medium">{recipientLocation?.name || 'Your Location'}</h4>
              <p className="text-sm text-gray-600">{recipientLocation?.address || 'Khammam, Telangana'}</p>
            </div>
          </div>

          {/* Pickup Locations */}
          {optimizedRoute.map((location, index) => (
            <div 
              key={location.id} 
              className={`flex items-center gap-4 p-4 rounded-lg border-2 transition-all duration-500 ${
                isNavigating && currentStep === index 
                  ? 'border-green-500 bg-green-50 shadow-md' 
                  : isNavigating && currentStep > index
                  ? 'border-gray-300 bg-gray-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className={`h-8 w-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                isNavigating && currentStep === index 
                  ? 'bg-green-500 text-white shadow-lg' 
                  : isNavigating && currentStep > index
                  ? 'bg-gray-400 text-white'
                  : 'bg-gray-100 text-gray-600'
              }`}>
                <span className="font-medium text-sm">{index + 1}</span>
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-medium">{location.name}</h4>
                  {isNavigating && currentStep === index && (
                    <Badge className="bg-green-500 animate-pulse">
                      {isMoving ? 'Approaching...' : 'Current Stop'}
                    </Badge>
                  )}
                  {isNavigating && currentStep > index && (
                    <Badge className="bg-gray-400">Completed ✓</Badge>
                  )}
                </div>
                <p className="text-sm text-gray-600 mb-2">{location.address}</p>
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Navigation className="h-3 w-3" />
                    {location.distance.toFixed(1)} km
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    ~{location.estimatedTime} min pickup
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => callLocation(location.phone)}
                >
                  <Phone className="h-3 w-3" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => openInMaps(location)}
                >
                  <MapPin className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Route Instructions */}
        {isNavigating && (
          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
            <h4 className="font-medium text-yellow-900 mb-2 flex items-center gap-2">
              <Navigation className="h-4 w-4" />
              Current Instructions
            </h4>
            {currentStep < optimizedRoute.length ? (
              <div className="space-y-2">
                {isMoving ? (
                  <div className="flex items-center gap-2 text-yellow-800">
                    <div className="w-2 h-2 bg-yellow-600 rounded-full animate-pulse" />
                    <p className="text-sm font-medium">
                      En route to <strong>{optimizedRoute[currentStep].name}</strong>
                    </p>
                  </div>
                ) : (
                  <p className="text-yellow-800 text-sm">
                    You have arrived at <strong>{optimizedRoute[currentStep].name}</strong>
                  </p>
                )}
                <p className="text-yellow-700 text-sm">
                  📍 {optimizedRoute[currentStep].address}
                </p>
                <p className="text-yellow-700 text-sm">
                  📞 Call {optimizedRoute[currentStep].phone} upon arrival
                </p>
                <p className="text-yellow-700 text-sm">
                  ⏱️ Estimated pickup time: {optimizedRoute[currentStep].estimatedTime} minutes
                </p>
              </div>
            ) : (
              <p className="text-yellow-800 text-sm">
                🎉 All pickups completed! Return to your organization.
              </p>
            )}
          </div>
        )}

        {/* Tips - Only show in inline mode to save space */}
        {mode === 'inline' && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-2">Pickup Tips</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Call ahead before arriving at each location</li>
              <li>• Bring insulated bags for perishable items</li>
              <li>• Check pickup instructions for each donation</li>
              <li>• Have your organization ID ready</li>
              <li>• Follow food safety guidelines during transport</li>
            </ul>
          </div>
        )}
      </CardContent>
    </>
  );

  // Render based on mode
  if (mode === 'fullscreen') {
    return (
      <div className="fixed inset-0 bg-white z-50 overflow-y-auto">
        <Card className="min-h-screen rounded-none border-0">
          <RouteContent />
        </Card>
      </div>
    );
  }

  // Inline mode
  return (
    <Card className="w-full">
      <RouteContent />
    </Card>
  );
}