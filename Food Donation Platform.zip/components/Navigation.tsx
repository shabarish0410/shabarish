import { useState } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { useAuth } from "../contexts/AuthContext";
import { AuthModal } from "./AuthModal";
import { NotificationCenter } from "./NotificationCenter";
import { ConnectivityDemo } from "./ConnectivityDemo";
import { Heart, Truck, ChefHat, User, LogOut, Settings } from "lucide-react";

interface NavigationProps {
  onNavigate: (page: string) => void;
  currentPage?: string;
}

export function Navigation({ onNavigate, currentPage }: NavigationProps) {
  const { user, profile, signOut } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [showConnectivityDemo, setShowConnectivityDemo] = useState(false);

  // Debug function to clear stuck sessions
  const clearAllData = () => {
    localStorage.clear();
    window.location.reload();
  };

  const handleAuthSuccess = () => {
    setShowAuthModal(false);
  };

  const handleSignOut = () => {
    signOut();
    onNavigate('home');
  };

  return (
    <>
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <button
                onClick={() => onNavigate('home')}
                className="flex items-center gap-2"
              >
                <Heart className="h-8 w-8 text-green-600" />
                <span className="text-xl font-bold text-gray-900">FoodBridge</span>
                <Badge variant="outline" className="text-xs">Khammam</Badge>
              </button>
            </div>

            {user && profile ? (
              <div className="flex items-center gap-4">
                {/* Notification Center */}
                <NotificationCenter />
                
                {/* Connectivity Test - only show for testing */}
                {process.env.NODE_ENV === 'development' && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowConnectivityDemo(true)}
                      className="gap-2"
                    >
                      <Settings className="h-4 w-4" />
                      Test
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={clearAllData}
                      className="gap-2 text-red-600"
                    >
                      Clear Data
                    </Button>
                  </>
                )}
                
                <div className="flex items-center gap-3">
                  {profile.organization_type === 'donor' && (
                    <div className="flex items-center gap-1 text-sm text-orange-600">
                      <ChefHat className="h-4 w-4" />
                      <span>Donor</span>
                    </div>
                  )}
                  {profile.organization_type === 'volunteer' && (
                    <div className="flex items-center gap-1 text-sm text-green-600">
                      <Truck className="h-4 w-4" />
                      <span>Volunteer</span>
                    </div>
                  )}
                  {profile.organization_type === 'recipient' && (
                    <div className="flex items-center gap-1 text-sm text-blue-600">
                      <Heart className="h-4 w-4" />
                      <span>Recipient</span>
                    </div>
                  )}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onNavigate('profile')}
                  className="gap-2"
                >
                  <User className="h-4 w-4" />
                  {profile.contact_person}
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSignOut}
                  className="gap-2"
                >
                  <LogOut className="h-4 w-4" />
                  Sign Out
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setAuthMode('signin');
                    setShowAuthModal(true);
                  }}
                >
                  Sign In
                </Button>
                <Button
                  onClick={() => {
                    setAuthMode('signup');
                    setShowAuthModal(true);
                  }}
                >
                  Join FoodBridge
                </Button>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal
          mode={authMode}
          onClose={() => setShowAuthModal(false)}
          onSuccess={handleAuthSuccess}
          onToggleMode={(mode) => setAuthMode(mode)}
          isOpen={showAuthModal}
        />
      )}

      {/* Connectivity Demo Modal */}
      {showConnectivityDemo && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="relative">
            <Button
              onClick={() => setShowConnectivityDemo(false)}
              className="absolute -top-2 -right-2 z-10"
              size="sm"
            >
              ×
            </Button>
            <ConnectivityDemo />
          </div>
        </div>
      )}
    </>
  );
}