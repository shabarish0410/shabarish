import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useDonations } from '../contexts/DonationContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Package, 
  Heart, 
  Users,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  MapPin,
  Phone,
  RefreshCw,
  Baby,
  Star,
  Navigation,
  MessageSquare,
  Eye
} from 'lucide-react';
import { openGoogleMaps, makePhoneCall, openDirections } from '../utils/navigation';
import { ClaimForm } from './ClaimForm';
import { RouteOptimization } from './RouteOptimization';
import { SMSNotification, createPickupReminderSMS } from './SMSNotification';
import { LiveLocationTracker } from './LiveLocationTracker';
import { LiveTrackingNotification, useLiveTrackingNotifications } from './LiveTrackingNotification';
import { OrganizationProfile } from './OrganizationProfile';


interface OrphanageDashboardProps {
  onNavigate?: (page: string) => void;
}

export function OrphanageDashboard({ onNavigate }: OrphanageDashboardProps) {
  const { user, profile } = useAuth();
  const { 
    availableDonations, 
    loading,
    refreshDonations,
    claimDonation
  } = useDonations();
  
  const [selectedDonation, setSelectedDonation] = useState<any>(null);
  const [showRouteOptimizer, setShowRouteOptimizer] = useState(false);
  const [routeOptimizerMode, setRouteOptimizerMode] = useState<'inline' | 'fullscreen'>('inline');
  const [showSMSNotification, setSMSNotification] = useState<any>(null);
  const [claimedDonations, setClaimedDonations] = useState<any[]>([]);
  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());
  const [recentActivity, setRecentActivity] = useState<string[]>([]);
  const [weeklyMealsGoal, setWeeklyMealsGoal] = useState(200);
  const [showLiveTracker, setShowLiveTracker] = useState(false);
  const [selectedTracking, setSelectedTracking] = useState<any>(null);
  const [showOrgProfile, setShowOrgProfile] = useState(false);
  const [selectedOrgId, setSelectedOrgId] = useState<string>('');
  const { notifications, addNotification, removeNotification } = useLiveTrackingNotifications();


  // Real-time activity tracking
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdateTime(new Date());
      
      // Simulate real-time notifications for orphanages
      if (Math.random() < 0.12) {
        const activities = [
          'New biryani donation available from Haveli Restaurant',
          'Fresh vegetables donated by Reliance Fresh Grocery',
          'Successfully fed all 45 children today',
          'Pickup completed from Annapurna Family Restaurant'
        ];
        const newActivity = activities[Math.floor(Math.random() * activities.length)];
        setRecentActivity(prev => [newActivity, ...prev.slice(0, 4)]);
      }
      
      // Simulate live tracking notifications for claimed donations
      if (Math.random() < 0.08 && claimedDonations.length > 0) {
        const randomDonation = claimedDonations[Math.floor(Math.random() * claimedDonations.length)];
        const isUrgent = Math.random() < 0.3;
        const etaMinutes = isUrgent ? Math.floor(Math.random() * 5) + 1 : Math.floor(Math.random() * 15) + 5;
        
        addNotification({
          id: `tracking-${randomDonation.id}-${Date.now()}`,
          donationTitle: randomDonation.title,
          deliveryPersonName: 'Ravi Kumar',
          estimatedArrival: `${etaMinutes} min`,
          isUrgent,
          onTrack: () => {
            setSelectedTracking({
              donationId: randomDonation.id,
              donorLocation: {
                name: randomDonation.donor_name,
                address: randomDonation.donor_address || 'Station Road, Khammam',
                lat: 17.2473 + Math.random() * 0.01,
                lng: 80.1514 + Math.random() * 0.01
              },
              recipientLocation: {
                name: profile?.organization_name || 'Your Orphanage',
                address: profile?.address || 'Wyra Road, Khammam',
                lat: 17.2373 + Math.random() * 0.01,
                lng: 80.1614 + Math.random() * 0.01
              },
              deliveryPerson: {
                id: 'driver-1',
                name: 'Ravi Kumar',
                phone: '9876543210',
                vehicle: 'Bike - TS 07 CB 1234',
                rating: 4.8
              }
            });
            setShowLiveTracker(true);
          }
        });
      }
    }, 25000);

    return () => clearInterval(interval);
  }, [claimedDonations, profile, addNotification]);

  const handleClaimSubmit = async (claimData: any) => {
    const success = await claimDonation(claimData.donation_id);
    if (success) {
      const donation = availableDonations.find(d => d.id === claimData.donation_id);
      if (donation) {
        setClaimedDonations(prev => [...prev, { ...donation, claimData }]);
        setRecentActivity(prev => [`Claimed donation: ${donation.title}`, ...prev.slice(0, 4)]);
        
        // Send pickup reminder SMS
        setSMSNotification({
          message: createPickupReminderSMS(
            donation.donor_name, 
            donation.title, 
            claimData.pickup_time || '2:00 PM'
          ),
          phoneNumber: profile?.phone || '8341266934',
          recipientName: profile?.organization_name || 'Orphanage'
        });
      }
      setSelectedDonation(null);
    }
    return success;
  };

  const handleViewProfile = (orgId: string) => {
    setSelectedOrgId(orgId);
    setShowOrgProfile(true);
  };

  const handleMessage = (orgId: string) => {
    // Navigate to messaging system with selected organization
    onNavigate?.('messages');
  };

  const handleStartPickupRoute = () => {
    if (showRouteOptimizer) {
      setShowRouteOptimizer(false);
      return;
    }

    const pickupLocations = claimedDonations.map(donation => ({
      donationId: donation.id,
      donorName: donation.donor_name,
      donorAddress: donation.donor_address || 'Khammam, Telangana',
      donorPhone: donation.donor_phone || '8341266934'
    }));

    if (pickupLocations.length > 0) {
      setShowRouteOptimizer(true);
      setRouteOptimizerMode('inline');
    } else {
      alert('No claimed donations for pickup route optimization.');
    }
  };

  const getTimeAgo = (dateString: string) => {
    const now = new Date();
    const created = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - created.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes} minutes ago`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(diffInMinutes / 1440);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
  };

  const getExpiryUrgency = (expiryDate: string) => {
    const now = new Date();
    const expiry = new Date(expiryDate);
    const hoursUntilExpiry = (expiry.getTime() - now.getTime()) / (1000 * 60 * 60);
    
    if (hoursUntilExpiry < 6) return 'urgent';
    if (hoursUntilExpiry < 24) return 'soon';
    return 'normal';
  };

  const stats = {
    available: availableDonations.length,
    claimed: claimedDonations.length,
    completedToday: claimedDonations.filter(d => {
      const today = new Date();
      const claimDate = new Date(d.claimed_at || d.created_at);
      return claimDate.toDateString() === today.toDateString();
    }).length,
    mealsThisWeek: claimedDonations.reduce((total, d) => total + (d.quantity * 2), 0) // Estimate 2 meals per unit
  };

  const weeklyProgress = (stats.mealsThisWeek / weeklyMealsGoal) * 100;

  if (!user || !profile) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Baby className="h-8 w-8 text-blue-600" />
                Orphanage Dashboard
              </h1>
              <p className="text-gray-600 mt-2">
                Welcome back, {profile.organization_name}! Find fresh food donations for your children in Khammam.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-sm text-gray-500">
                Last updated: {lastUpdateTime.toLocaleTimeString()}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={refreshDonations}
                disabled={loading}
                className="gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>

          {/* Weekly Meals Progress */}
          <Card className="mt-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-blue-900">Weekly Meals Goal</h3>
                <Badge className="bg-blue-100 text-blue-800">
                  {stats.mealsThisWeek}/{weeklyMealsGoal} meals
                </Badge>
              </div>
              <Progress value={weeklyProgress} className="h-3 mb-2" />
              <p className="text-sm text-blue-700">
                {weeklyProgress >= 100 
                  ? "🎉 Amazing! You've secured enough meals for this week!" 
                  : `${weeklyMealsGoal - stats.mealsThisWeek} more meals needed to reach this week's goal`}
              </p>
            </CardContent>
          </Card>

          {/* Real-time Activity Feed */}
          {recentActivity.length > 0 && (
            <Alert className="mt-4 border-green-200 bg-green-50">
              <AlertCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                <div className="font-medium mb-1">Recent Activity:</div>
                <div className="text-sm space-y-1">
                  {recentActivity.slice(0, 2).map((activity, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3" />
                      {activity}
                    </div>
                  ))}
                </div>
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-600">Available Now</p>
                  <p className="text-3xl font-bold text-green-700">{stats.available}</p>
                  <p className="text-xs text-green-600 mt-1">
                    Fresh donations ready
                  </p>
                </div>
                <Package className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600">Claimed Today</p>
                  <p className="text-3xl font-bold text-blue-700">{stats.completedToday}</p>
                  <p className="text-xs text-blue-600 mt-1">Pending pickup</p>
                </div>
                <Heart className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-600">This Week</p>
                  <p className="text-3xl font-bold text-purple-700">{stats.mealsThisWeek}</p>
                  <p className="text-xs text-purple-600 mt-1">Meals secured</p>
                </div>
                <Users className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-50 to-orange-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-600">Children Fed</p>
                  <p className="text-3xl font-bold text-orange-700">{profile?.children_count || 45}</p>
                  <p className="text-xs text-orange-600 mt-1">Daily target</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Button 
            onClick={handleStartPickupRoute}
            className="h-16 bg-blue-600 hover:bg-blue-700 text-lg"
            disabled={claimedDonations.length === 0}
          >
            <Navigation className="h-5 w-5 mr-3" />
            {showRouteOptimizer ? 'Hide Route Optimizer' : `Optimize Pickup Route (${claimedDonations.length} stops)`}
          </Button>
          <Button 
            variant="outline"
            onClick={() => onNavigate?.('messages')}
            className="h-16 text-lg"
          >
            <MessageSquare className="h-5 w-5 mr-3" />
            Contact Donors
          </Button>
        </div>

        {/* Route Optimization Section */}
        {showRouteOptimizer && (
          <RouteOptimization
            pickupLocations={claimedDonations.map(d => ({
              donationId: d.id,
              donorName: d.donor_name,
              donorAddress: d.donor_address || 'Khammam, Telangana',
              donorPhone: d.donor_phone || '8341266934'
            }))}
            recipientLocation={{
              name: profile?.organization_name || 'Your Organization',
              address: profile?.address || 'Khammam, Telangana'
            }}
            mode={routeOptimizerMode}
            onClose={() => setShowRouteOptimizer(false)}
            onModeChange={(mode) => setRouteOptimizerMode(mode)}
          />
        )}

        {/* Main Content */}
        {!showRouteOptimizer || routeOptimizerMode === 'inline' ? (
          <Tabs defaultValue="available" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="available">Available Donations</TabsTrigger>
            <TabsTrigger value="claimed">My Claims</TabsTrigger>
            <TabsTrigger value="nutrition">Nutrition Planning</TabsTrigger>
          </TabsList>

          {/* Available Donations Tab */}
          <TabsContent value="available" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Available Food Donations in Khammam</h2>
              <Badge variant="outline" className="text-green-600 border-green-600">
                {stats.available} donations available
              </Badge>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {availableDonations.map((donation) => {
                const urgency = getExpiryUrgency(donation.expiration_date);
                return (
                  <Card key={donation.id} className={`hover:shadow-lg transition-shadow overflow-hidden ${
                    urgency === 'urgent' ? 'ring-2 ring-red-200' : 
                    urgency === 'soon' ? 'ring-1 ring-yellow-200' : ''
                  }`}>
                    {/* Realistic Food Image */}
                    <div className="relative">
                      <ImageWithFallback
                        src={donation.image_url || "https://images.unsplash.com/photo-1665758483281-b4b59c5fd4c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVwYXJlZCUyMG1lYWxzJTIwcmVhZHklMjBmb29kJTIwY29udGFpbmVyc3xlbnwxfHx8fDE3NTQzMDEyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"}
                        alt={donation.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-3 left-3">
                        <Badge className={
                          urgency === 'urgent' ? 'bg-red-500 text-white' :
                          urgency === 'soon' ? 'bg-yellow-500 text-white' :
                          'bg-green-500 text-white'
                        }>
                          {urgency === 'urgent' ? 'Urgent' : 
                           urgency === 'soon' ? 'Expiring Soon' : 
                           'Available'}
                        </Badge>
                      </div>
                      <div className="absolute top-3 right-3">
                        <Badge variant="outline" className="bg-white/90 text-gray-800">
                          {donation.food_type}
                        </Badge>
                      </div>
                      <div className="absolute bottom-3 left-3">
                        <Badge className="bg-black/70 text-white hover:bg-black/70">
                          {donation.quantity} {donation.unit}
                        </Badge>
                      </div>
                    </div>

                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{donation.title}</CardTitle>
                      </div>
                      <button
                        onClick={() => handleViewProfile('donor-1')}
                        className="text-sm text-blue-600 hover:text-blue-800 text-left flex items-center gap-1"
                      >
                        {donation.donor_name}
                        <Eye className="h-3 w-3" />
                      </button>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4 line-clamp-2">{donation.description}</p>
                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Expires:</span>
                          <span className={urgency === 'urgent' ? 'text-red-600 font-medium' : 
                                         urgency === 'soon' ? 'text-yellow-600 font-medium' : 'text-gray-600'}>
                            {new Date(donation.expiration_date).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Posted:</span>
                          <span>{getTimeAgo(donation.created_at)}</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-3 w-3 mr-1" />
                          <span>{donation.donor_address}</span>
                        </div>
                        {donation.pickup_instructions && (
                          <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
                            <strong>Pickup:</strong> {donation.pickup_instructions}
                          </div>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Button 
                          className="w-full"
                          onClick={() => setSelectedDonation(donation)}
                        >
                          {urgency === 'urgent' ? 'Claim Now - Urgent!' : 'Claim Donation'}
                        </Button>
                        <Button 
                          variant="outline"
                          size="sm"
                          onClick={() => openDirections(donation.donor_address || 'Khammam, Telangana')}
                          className="w-full"
                        >
                          <Navigation className="h-3 w-3 mr-1" />
                          📍 Navigate with Google Maps
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {availableDonations.length === 0 && (
              <div className="text-center py-12">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No donations available</h3>
                <p className="text-gray-600 mb-4">
                  Check back soon! New donations from Khammam restaurants are posted regularly.
                </p>
                <Button onClick={refreshDonations} variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh Listings
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Claimed Donations Tab */}
          <TabsContent value="claimed" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Your Claimed Donations</h2>
              <Badge variant="outline" className="text-blue-600 border-blue-600">
                {claimedDonations.length} pending pickup
              </Badge>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {claimedDonations.map((donation) => (
                <Card key={donation.id} className="border-blue-200 overflow-hidden">
                  {/* Small preview image */}
                  <div className="flex">
                    <div className="w-24 h-24 flex-shrink-0">
                      <ImageWithFallback
                        src={donation.image_url || "https://images.unsplash.com/photo-1665758483281-b4b59c5fd4c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVwYXJlZCUyMG1lYWxzJTIwcmVhZHklMjBmb29kJTIwY29udGFpbmVyc3xlbnwxfHx8fDE3NTQzMDEyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"}
                        alt={donation.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 p-4">
                      <div className="flex justify-between items-start mb-2">
                        <CardTitle className="text-lg">{donation.title}</CardTitle>
                        <Badge className="bg-blue-100 text-blue-800">Claimed</Badge>
                      </div>
                      <p className="text-sm text-blue-600 mb-3">{donation.donor_name}</p>
                      
                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Quantity:</span>
                          <span>{donation.quantity} {donation.unit}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Pickup By:</span>
                          <span className="text-red-600 font-medium">
                            {new Date(donation.expiration_date).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Phone className="h-3 w-3 mr-1" />
                          <span>{donation.donor_phone}</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-3 w-3 mr-1" />
                          <span>{donation.donor_address}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => makePhoneCall(donation.donor_phone || '8341266934')}
                          className="flex-1"
                        >
                          <Phone className="h-3 w-3 mr-1" />
                          Call
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedTracking({
                              donationId: donation.id,
                              donorLocation: {
                                name: donation.donor_name,
                                address: donation.donor_address || 'Station Road, Khammam',
                                lat: 17.2473 + Math.random() * 0.01,
                                lng: 80.1514 + Math.random() * 0.01
                              },
                              recipientLocation: {
                                name: profile?.organization_name || 'Your Orphanage',
                                address: profile?.address || 'Wyra Road, Khammam',
                                lat: 17.2373 + Math.random() * 0.01,
                                lng: 80.1614 + Math.random() * 0.01
                              },
                              deliveryPerson: {
                                id: 'driver-1',
                                name: 'Ravi Kumar',
                                phone: '9876543210',
                                vehicle: 'Bike - TS 07 CB 1234',
                                rating: 4.8
                              }
                            });
                            setShowLiveTracker(true);
                          }}
                          className="flex-1"
                        >
                          <MapPin className="h-3 w-3 mr-1" />
                          🔴 Track Live
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {claimedDonations.length === 0 && (
              <div className="text-center py-12">
                <Heart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No claimed donations</h3>
                <p className="text-gray-600 mb-4">
                  Browse available donations and claim food for your children.
                </p>
                <Button onClick={() => setSelectedTab?.('available')} variant="outline">
                  Browse Donations
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Nutrition Planning Tab */}
          <TabsContent value="nutrition" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Nutrition Planning</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Dietary Requirements</h4>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li>• {profile?.children_count || 45} children daily meals</li>
                      <li>• Balanced nutrition with proteins</li>
                      <li>• Fresh vegetables and fruits</li>
                      <li>• Dairy products for growing children</li>
                      <li>• Avoid excessive spicy food</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium mb-3">Food Safety Guidelines</h4>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li>• Check expiration dates carefully</li>
                      <li>• Maintain cold chain for perishables</li>
                      <li>• Reheat food properly before serving</li>
                      <li>• Store donations in clean containers</li>
                      <li>• Serve food within safe time limits</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        ) : null}
      </div>

      {/* Forms and Modals */}
      {selectedDonation && (
        <ClaimForm
          donation={selectedDonation}
          onClose={() => setSelectedDonation(null)}
          onSubmit={handleClaimSubmit}
        />
      )}



      {showSMSNotification && (
        <SMSNotification
          message={showSMSNotification.message}
          phoneNumber={showSMSNotification.phoneNumber}
          recipientName={showSMSNotification.recipientName}
          onClose={() => setSMSNotification(null)}
        />
      )}

      {/* Live Location Tracker */}
      {showLiveTracker && selectedTracking && (
        <LiveLocationTracker
          donationId={selectedTracking.donationId}
          donorLocation={selectedTracking.donorLocation}
          recipientLocation={selectedTracking.recipientLocation}
          deliveryPerson={selectedTracking.deliveryPerson}
          onClose={() => {
            setShowLiveTracker(false);
            setSelectedTracking(null);
          }}
          isRecipientView={true}
        />
      )}

      {/* Live Tracking Notifications */}
      {notifications.map((notification) => (
        <LiveTrackingNotification
          key={notification.id}
          donationTitle={notification.donationTitle}
          deliveryPersonName={notification.deliveryPersonName}
          estimatedArrival={notification.estimatedArrival}
          isUrgent={notification.isUrgent}
          onTrack={notification.onTrack}
          onDismiss={() => removeNotification(notification.id)}
        />
      ))}

      {/* Organization Profile Modal */}
      {showOrgProfile && (
        <OrganizationProfile
          organizationId={selectedOrgId}
          onClose={() => setShowOrgProfile(false)}
          onMessage={handleMessage}
        />
      )}
    </div>
  );
}