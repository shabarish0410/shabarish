import { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  MapPin, 
  X, 
  Bell, 
  Clock, 
  Truck,
  CheckCircle,
  AlertTriangle,
  ExternalLink,
  Navigation,
  Zap,
  RadioIcon as Live
} from 'lucide-react';

interface LiveTrackingNotificationProps {
  donationTitle: string;
  deliveryPersonName: string;
  estimatedArrival: string;
  onTrack: () => void;
  onDismiss: () => void;
  isUrgent?: boolean;
}

export function LiveTrackingNotification({
  donationTitle,
  deliveryPersonName,
  estimatedArrival,
  onTrack,
  onDismiss,
  isUrgent = false
}: LiveTrackingNotificationProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [pulseCount, setPulseCount] = useState(0);
  const [animationPhase, setAnimationPhase] = useState(0);

  useEffect(() => {
    if (isUrgent) {
      const interval = setInterval(() => {
        setPulseCount(prev => prev + 1);
        setAnimationPhase(prev => (prev + 1) % 3);
      }, 1500);
      return () => clearInterval(interval);
    }
  }, [isUrgent]);

  if (!isVisible) return null;

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss();
  };

  const getAnimationClass = () => {
    if (isUrgent) {
      switch (animationPhase) {
        case 0: return 'animate-pulse';
        case 1: return 'animate-bounce';
        case 2: return 'animate-pulse';
        default: return 'animate-pulse';
      }
    }
    return '';
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      <Card className={`shadow-2xl border-2 transition-all duration-300 ${
        isUrgent 
          ? 'border-red-300 bg-gradient-to-br from-red-50 to-orange-50' 
          : 'border-blue-300 bg-gradient-to-br from-blue-50 to-purple-50'
      } ${getAnimationClass()}`}>
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className={`flex items-center gap-1 ${
                isUrgent ? 'text-red-600' : 'text-blue-600'
              }`}>
                <Live className="h-4 w-4 animate-pulse" />
                <span className="font-medium text-sm">Live Tracking Available</span>
                <Badge className={`text-xs ${
                  isUrgent 
                    ? 'bg-red-100 text-red-800' 
                    : 'bg-blue-100 text-blue-800'
                }`}>
                  LIVE
                </Badge>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleDismiss}
              className="h-6 w-6 p-0 text-gray-400 hover:text-gray-600"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>

          <div className="space-y-3">
            {/* Enhanced Delivery Info */}
            <div className="bg-white/80 backdrop-blur-sm rounded-lg p-3 space-y-2 border">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full animate-pulse ${
                  isUrgent ? 'bg-red-500' : 'bg-blue-500'
                }`}></div>
                <Truck className={`h-4 w-4 ${
                  isUrgent ? 'text-red-600' : 'text-blue-600'
                }`} />
                <span className="font-medium text-sm">{deliveryPersonName}</span>
                <Badge variant="outline" className="text-xs">
                  GPS Active
                </Badge>
              </div>
              
              <div className="text-xs text-gray-600 pl-4">
                Delivering: {donationTitle.length > 35 ? 
                  `${donationTitle.substring(0, 35)}...` : 
                  donationTitle
                }
              </div>
              
              <div className="flex items-center justify-between pl-4">
                <div className="flex items-center gap-2">
                  <Clock className={`h-3 w-3 ${
                    isUrgent ? 'text-red-600' : 'text-green-600'
                  }`} />
                  <span className={`text-sm font-medium ${
                    isUrgent ? 'text-red-600' : 'text-green-600'
                  }`}>
                    ETA: {estimatedArrival}
                  </span>
                </div>
                <Badge variant="outline" className="text-xs gap-1">
                  <Navigation className="h-2 w-2" />
                  Google Maps Ready
                </Badge>
              </div>
            </div>

            {/* Enhanced Call-to-Action */}
            <div className="space-y-2">
              <Button 
                onClick={onTrack}
                size="sm"
                className={`w-full ${
                  isUrgent 
                    ? 'bg-red-600 hover:bg-red-700' 
                    : 'bg-blue-600 hover:bg-blue-700'
                } gap-2`}
              >
                <ExternalLink className="h-3 w-3" />
                Open Google Maps Live
                {isUrgent && <span className="animate-pulse">🔥</span>}
              </Button>
              
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={onTrack}
                  className="flex-1 gap-1 text-xs"
                >
                  <MapPin className="h-3 w-3" />
                  Track
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleDismiss}
                  className="px-3 text-xs"
                >
                  Later
                </Button>
              </div>
            </div>

            {/* Enhanced Status Indicator with Google Maps integration */}
            <div className="bg-white/60 rounded-lg p-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1">
                  {isUrgent ? (
                    <>
                      <AlertTriangle className="h-3 w-3 text-red-600 animate-pulse" />
                      <span className="text-red-600 font-medium">Almost here!</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span className="text-green-600">On the way</span>
                    </>
                  )}
                </div>
                
                <div className="flex items-center gap-1">
                  <Zap className="h-2 w-2 text-blue-600" />
                  <span className="text-gray-600">Real-time GPS</span>
                </div>
              </div>
              
              <div className="mt-1 text-center">
                <p className="text-xs text-gray-600">
                  <strong>Your pickup partner is on the move!</strong>
                  <br />
                  Tap above to follow their real-time route in Google Maps
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Enhanced hook with Google Maps integration
export function useLiveTrackingNotifications() {
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    donationTitle: string;
    deliveryPersonName: string;
    estimatedArrival: string;
    isUrgent: boolean;
    onTrack: () => void;
  }>>([]);

  const addNotification = (notification: {
    id: string;
    donationTitle: string;
    deliveryPersonName: string;
    estimatedArrival: string;
    isUrgent?: boolean;
    onTrack: () => void;
  }) => {
    // Automatically show Google Maps integration message
    const enhancedNotification = {
      ...notification,
      isUrgent: notification.isUrgent || false,
      onTrack: () => {
        // Enhanced tracking with Google Maps focus
        notification.onTrack();
        
        // Optional: Could also open Google Maps directly
        // const destination = "Khammam, Telangana";
        // const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}&travelmode=driving`;
        // window.open(mapsUrl, '_blank');
      }
    };
    
    setNotifications(prev => [...prev, enhancedNotification]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  return {
    notifications,
    addNotification,
    removeNotification,
    clearAllNotifications
  };
}