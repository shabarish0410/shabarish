import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { projectId } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface RequestFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

export function RequestForm({ onClose, onSuccess }: RequestFormProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    food_type: '',
    quantity_needed: '',
    unit: 'kg',
    needed_by: '',
    urgency: 'medium' as 'low' | 'medium' | 'high'
  });

  const foodTypes = [
    'Fresh Produce',
    'Dairy Products',
    'Meat & Poultry',
    'Seafood',
    'Bakery Items',
    'Canned Goods',
    'Dry Goods',
    'Frozen Foods',
    'Prepared Meals',
    'Beverages',
    'Any Food Items',
    'Other'
  ];

  const units = [
    'kg', 'lbs', 'pieces', 'boxes', 'bags', 'liters', 'gallons', 'servings'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    setError('');

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-e4b54fa0/requests`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            ...formData,
            quantity_needed: parseFloat(formData.quantity_needed)
          }),
        }
      );

      const result = await response.json();

      if (response.ok) {
        onSuccess();
      } else {
        setError(result.error || 'Failed to create request');
      }
    } catch (error) {
      setError('Network error occurred');
      console.error('Error creating request:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Set default date (tomorrow)
  const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Request</DialogTitle>
          <DialogDescription>
            Create a food request to let donor organizations know what your organization needs. Specify your requirements and urgency level to help donors understand your needs.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="title">Request Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleChange('title', e.target.value)}
                placeholder="e.g., Urgent need for fresh vegetables"
                required
              />
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Describe your specific needs and any dietary requirements..."
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="food_type">Food Type *</Label>
              <Select value={formData.food_type} onValueChange={(value) => handleChange('food_type', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select food type" />
                </SelectTrigger>
                <SelectContent>
                  {foodTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="urgency">Urgency Level *</Label>
              <Select value={formData.urgency} onValueChange={(value: 'low' | 'medium' | 'high') => handleChange('urgency', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low - Can wait a few days</SelectItem>
                  <SelectItem value="medium">Medium - Needed within 2-3 days</SelectItem>
                  <SelectItem value="high">High - Urgent, needed ASAP</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <div className="flex-1">
                <Label htmlFor="quantity_needed">Quantity Needed *</Label>
                <Input
                  id="quantity_needed"
                  type="number"
                  step="0.1"
                  min="0"
                  value={formData.quantity_needed}
                  onChange={(e) => handleChange('quantity_needed', e.target.value)}
                  required
                />
              </div>
              <div className="w-24">
                <Label htmlFor="unit">Unit</Label>
                <Select value={formData.unit} onValueChange={(value) => handleChange('unit', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {units.map(unit => (
                      <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="needed_by">Needed By *</Label>
              <Input
                id="needed_by"
                type="date"
                value={formData.needed_by}
                onChange={(e) => handleChange('needed_by', e.target.value)}
                min={tomorrow}
                required
              />
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">How this works:</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Your request will be visible to donor organizations</li>
              <li>• Donors can contact you directly through our messaging system</li>
              <li>• You'll receive notifications when someone responds</li>
              <li>• You can coordinate pickup details directly with donors</li>
            </ul>
          </div>

          <div className="flex gap-3 pt-4">
            <Button 
              type="submit" 
              disabled={loading}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {loading ? 'Creating Request...' : 'Create Request'}
            </Button>
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
              className="px-8"
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}