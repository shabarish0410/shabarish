import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { 
  Bell, 
  BellRing, 
  Package, 
  Truck, 
  Heart, 
  Navigation, 
  X, 
  CheckCheck,
  AlertTriangle,
  Info,
  ChefHat,
  Baby,
  MapPin,
  Phone,
  Clock
} from 'lucide-react';
import { useNotifications } from '../contexts/NotificationContext';
import { useAuth } from '../contexts/AuthContext';

export function NotificationCenter() {
  const { notifications, unreadCount, markAsRead, markAllAsRead, removeNotification } = useNotifications();
  const { profile } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const getNotificationIcon = (type: string, priority: string) => {
    const iconClass = `h-4 w-4 ${
      priority === 'urgent' ? 'text-red-500' :
      priority === 'high' ? 'text-orange-500' :
      priority === 'medium' ? 'text-blue-500' :
      'text-gray-500'
    }`;

    switch (type) {
      case 'donation_posted':
        return <Package className={iconClass} />;
      case 'donation_claimed':
        return <Heart className={iconClass} />;
      case 'pickup_requested':
        return <Truck className={iconClass} />;
      case 'delivery_update':
        return <Navigation className={iconClass} />;
      case 'route_request':
        return <MapPin className={iconClass} />;
      default:
        return <Info className={iconClass} />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Urgent</Badge>;
      case 'high':
        return <Badge className="bg-orange-100 text-orange-800 border-orange-200">High</Badge>;
      case 'medium':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Medium</Badge>;
      default:
        return <Badge variant="outline">Low</Badge>;
    }
  };

  const handleNotificationClick = (notification: any) => {
    markAsRead(notification.id);
    
    // Handle specific actions based on notification type
    if (notification.type === 'pickup_requested' && notification.data?.donorPhone) {
      // Show quick action options for volunteers
      const shouldCall = confirm(`Accept pickup from ${notification.data.donor}?\n\nClick OK to call them at ${notification.data.donorPhone || 'their number'}`);
      if (shouldCall && notification.data.donorPhone) {
        window.open(`tel:${notification.data.donorPhone}`);
      }
    } else if (notification.type === 'donation_posted' && profile?.organization_type === 'recipient') {
      // For recipients, we could navigate to the donation or show quick claim option
      alert(`Would you like to view "${notification.data?.title}" donation details?`);
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const notifTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - notifTime.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  // Filter notifications relevant to current user type
  const relevantNotifications = notifications.filter(notification => 
    !notification.targetUserType || 
    notification.targetUserType === profile?.organization_type ||
    notification.targetUserType === 'all'
  );

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="relative">
          {unreadCount > 0 ? (
            <BellRing className="h-4 w-4" />
          ) : (
            <Bell className="h-4 w-4" />
          )}
          {unreadCount > 0 && (
            <Badge className="absolute -top-2 -right-2 bg-red-500 text-white px-1.5 py-0.5 text-xs min-w-[1.25rem] h-5 flex items-center justify-center">
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <Card className="border-none shadow-lg">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Notifications
                {unreadCount > 0 && (
                  <Badge className="bg-red-100 text-red-800 border-red-200">
                    {unreadCount} new
                  </Badge>
                )}
              </CardTitle>
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                  <CheckCheck className="h-4 w-4 mr-1" />
                  Mark all read
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-96">
              {relevantNotifications.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  <Bell className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                  <p>No notifications yet</p>
                  <p className="text-sm">You'll see updates about donations and deliveries here</p>
                </div>
              ) : (
                <div className="divide-y">
                  {relevantNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-gray-50 cursor-pointer transition-colors ${
                        !notification.read ? 'bg-blue-50/30 border-l-4 border-l-blue-500' : ''
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3 flex-1">
                          <div className="mt-0.5">
                            {getNotificationIcon(notification.type, notification.priority)}
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium text-sm text-gray-900">
                                {notification.title}
                              </h4>
                              {!notification.read && (
                                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                              )}
                            </div>
                            <p className="text-sm text-gray-600 line-clamp-2">
                              {notification.message}
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              {getPriorityBadge(notification.priority)}
                              <div className="flex items-center gap-1 text-xs text-gray-500">
                                <Clock className="h-3 w-3" />
                                {formatTimeAgo(notification.timestamp)}
                              </div>
                            </div>
                            
                            {/* Show quick action buttons for specific notification types */}
                            {notification.type === 'pickup_requested' && profile?.organization_type === 'volunteer' && (
                              <div className="flex gap-2 mt-2">
                                <Button size="sm" variant="outline" className="h-7 text-xs">
                                  <Phone className="h-3 w-3 mr-1" />
                                  Call
                                </Button>
                                <Button size="sm" variant="outline" className="h-7 text-xs">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  Route
                                </Button>
                              </div>
                            )}
                            
                            {notification.type === 'donation_posted' && profile?.organization_type === 'recipient' && (
                              <div className="flex gap-2 mt-2">
                                <Button size="sm" variant="outline" className="h-7 text-xs">
                                  View Details
                                </Button>
                                <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700">
                                  Quick Claim
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeNotification(notification.id);
                          }}
                          className="opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  );
}