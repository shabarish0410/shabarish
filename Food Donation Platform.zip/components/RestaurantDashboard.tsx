import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useDonations } from '../contexts/DonationContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Plus, 
  Package, 
  Heart, 
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Users,
  MapPin,
  Phone,
  RefreshCw,
  ChefHat,
  Star,
  Eye
} from 'lucide-react';
import { openDirections } from '../utils/navigation';
import { DonationForm } from './DonationForm';
import { RouteOptimization } from './RouteOptimization';
import { SMSNotification, createClaimNotificationSMS } from './SMSNotification';
import { LiveLocationTracker } from './LiveLocationTracker';
import { OrganizationProfile } from './OrganizationProfile';

interface RestaurantDashboardProps {
  onNavigate?: (page: string) => void;
}

export function RestaurantDashboard({ onNavigate }: RestaurantDashboardProps) {
  const { user, profile } = useAuth();
  const { 
    userDonations, 
    loading,
    refreshDonations,
    createDonation,
    updateDonationStatus
  } = useDonations();

  // Sample food donations from Khammam restaurants for demonstration
  const sampleDonations = [
    {
      id: 'sample-1',
      title: 'Fresh Hyderabadi Biryani (Large Portions)',
      description: 'Premium quality chicken biryani with raita and shorba. Perfect for dinner service. Prepared with aromatic basmati rice and traditional spices.',
      food_type: 'Main Course',
      quantity: 15,
      unit: 'portions',
      status: 'available',
      expiration_date: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(), // 4 hours from now
      donor_name: profile?.organization_name || 'Haveli Restaurant',
      donor_address: 'Station Road, Khammam',
      donor_phone: '8341266934',
      created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
      image_url: 'https://images.unsplash.com/photo-1563379091339-03246963d96c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXJ5YW5pfGVufDB8fHx8MTczNDM0MTIwM3ww&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'sample-2',
      title: 'Mixed Vegetable Curry with Chapati',
      description: 'Healthy vegetable curry made with fresh local vegetables, served with soft chapatis. Rich in nutrients and perfect for children.',
      food_type: 'Vegetarian',
      quantity: 20,
      unit: 'meals',
      status: 'claimed',
      recipient_name: 'Balala Vikasa Kendra Orphanage',
      recipient_phone: '9441234567',
      expiration_date: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString(),
      donor_name: profile?.organization_name || 'Reliance Fresh Khammam',
      donor_address: 'KTR Circle, Khammam',
      donor_phone: '8341266934',
      created_at: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(), // 1 hour ago
      image_url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdldGFibGUlMjBjdXJyeXxlbnwwfHx8fDE3MzQzNDEyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'sample-3',
      title: 'Fresh Roti & Dal Combo',
      description: 'Freshly made rotis with nutritious dal (lentil curry). High protein meal ideal for growing children. Prepared with organic ingredients.',
      food_type: 'Vegetarian',
      quantity: 25,
      unit: 'combos',
      status: 'completed',
      recipient_name: 'Little Angels Children Home',
      recipient_phone: '9876543210',
      expiration_date: new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString(),
      donor_name: profile?.organization_name || 'Shanti Restaurant',
      donor_address: 'Wyra Road, Khammam',
      donor_phone: '8341266934',
      created_at: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
      image_url: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb3RpJTIwZGFsfGVufDB8fHx8MTczNDM0MTIwM3ww&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'sample-4',
      title: 'Chicken Curry with Rice',
      description: 'Spicy chicken curry with steamed basmati rice. Traditional Khammam style preparation with local spices and tender chicken pieces.',
      food_type: 'Non-Vegetarian',
      quantity: 12,
      unit: 'plates',
      status: 'available',
      expiration_date: new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString(),
      donor_name: profile?.organization_name || 'Minerva Grand Hotel',
      donor_address: 'Collectorate Road, Khammam',
      donor_phone: '8341266934',
      created_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
      image_url: 'https://images.unsplash.com/photo-1565299507177-b0ac66763828?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwY3Vycnl8ZW58MHx8fHwxNzM0MzQxMjAzfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'sample-5',
      title: 'Fresh Fruit Bowls',
      description: 'Assorted seasonal fresh fruits including bananas, apples, and oranges. Perfect for healthy dessert or snacks for children.',
      food_type: 'Fruits',
      quantity: 30,
      unit: 'bowls',
      status: 'claimed',
      recipient_name: 'Hope Children Foundation',
      recipient_phone: '8123456789',
      expiration_date: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString(),
      donor_name: profile?.organization_name || 'Khammam Fruit Market',
      donor_address: 'Vegetable Market, Khammam',
      donor_phone: '8341266934',
      created_at: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), // 3 hours ago
      image_url: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcnVpdCUyMGJvd2x8ZW58MHx8fHwxNzM0MzQxMjAzfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'sample-6',
      title: 'Breakfast Combo - Idli & Sambar',
      description: 'Traditional South Indian breakfast with soft idlis and flavorful sambar. Includes coconut chutney. Nutritious start for the day.',
      food_type: 'Breakfast',
      quantity: 40,
      unit: 'sets',
      status: 'completed',
      recipient_name: 'Sri Sai Orphanage',
      recipient_phone: '9988776655',
      expiration_date: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
      donor_name: profile?.organization_name || 'Udupi Bhavan',
      donor_address: 'Bus Stand Road, Khammam',
      donor_phone: '8341266934',
      created_at: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(), // 8 hours ago (this morning)
      image_url: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpZGxpJTIwc2FtYmFyfGVufDB8fHx8MTczNDM0MTIwM3ww&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  // Combine user donations with sample data for demonstration
  const allDonations = userDonations.length > 0 ? userDonations : sampleDonations;
  
  const [showDonationForm, setShowDonationForm] = useState(false);
  const [showRouteOptimizer, setShowRouteOptimizer] = useState(false);
  const [routeOptimizerMode, setRouteOptimizerMode] = useState<'inline' | 'fullscreen'>('inline');
  const [showSMSNotification, setSMSNotification] = useState<any>(null);
  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());
  const [recentActivity, setRecentActivity] = useState<string[]>([]);
  const [todaysGoal, setTodaysGoal] = useState(5);
  const [showLiveTracker, setShowLiveTracker] = useState(false);
  const [selectedTracking, setSelectedTracking] = useState<any>(null);
  const [showOrgProfile, setShowOrgProfile] = useState(false);
  const [selectedOrgId, setSelectedOrgId] = useState<string>('');

  // Real-time activity tracking
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdateTime(new Date());
      
      // Simulate real-time notifications for restaurants
      if (Math.random() < 0.15) {
        const activities = [
          'Your biryani donation was claimed by Balala Vikasa Kendra',
          'New orphanage request for fresh meals in Khammam',
          'Successfully helped feed 45 children today',
          'Food waste reduced by 5kg this week'
        ];
        const newActivity = activities[Math.floor(Math.random() * activities.length)];
        setRecentActivity(prev => [newActivity, ...prev.slice(0, 4)]);
      }
    }, 20000);

    return () => clearInterval(interval);
  }, []);

  const handleCreateDonation = async (donationData: any) => {
    const success = await createDonation(donationData);
    if (success) {
      setShowDonationForm(false);
      setRecentActivity(prev => [`Posted new donation: ${donationData.title}`, ...prev.slice(0, 4)]);
      
      // Show SMS notification to nearby orphanages
      setSMSNotification({
        message: `🍽️ New Donation Alert - FoodBridge\n\nNew ${donationData.food_type} available from ${profile?.organization_name} in Khammam!\n\nLogin to claim: foodbridge-khammam.com\n\n- FoodBridge Team`,
        phoneNumber: '8341266934',
        recipientName: 'Local Orphanages'
      });
    }
    return success;
  };

  const handleUpdateStatus = async (donationId: string, status: string) => {
    const success = await updateDonationStatus(donationId, status);
    if (success) {
      setRecentActivity(prev => [`Donation status updated to ${status}`, ...prev.slice(0, 4)]);
    }
  };

  const handleDonationClaimed = (donation: any) => {
    // Send SMS notification to restaurant
    setSMSNotification({
      message: createClaimNotificationSMS(donation.title, donation.recipient_name, donation.recipient_phone),
      phoneNumber: profile?.phone || '8341266934',
      recipientName: profile?.organization_name || 'Restaurant'
    });
  };

  const handleViewRecipientProfile = (recipientName: string) => {
    setSelectedOrgId('recipient-1');
    setShowOrgProfile(true);
  };

  const handleMessage = (orgId: string) => {
    // Navigate to messaging system with selected organization
    onNavigate?.('messages');
  };

  const stats = {
    totalToday: allDonations.filter(d => {
      const today = new Date();
      const donationDate = new Date(d.created_at);
      return donationDate.toDateString() === today.toDateString();
    }).length,
    totalWeek: allDonations.filter(d => {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return new Date(d.created_at) >= weekAgo;
    }).length,
    available: allDonations.filter(d => d.status === 'available').length,
    completed: allDonations.filter(d => d.status === 'completed').length,
    claimed: allDonations.filter(d => d.status === 'claimed').length
  };

  const dailyProgress = (stats.totalToday / todaysGoal) * 100;

  if (!user || !profile) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <ChefHat className="h-8 w-8 text-orange-600" />
                Restaurant Dashboard
              </h1>
              <p className="text-gray-600 mt-2">
                Welcome back, {profile.organization_name}! Help reduce food waste and feed Khammam's children.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-sm text-gray-500">
                Last updated: {lastUpdateTime.toLocaleTimeString()}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={refreshDonations}
                disabled={loading}
                className="gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>

          {/* Daily Goal Progress */}
          <Card className="mt-6 bg-gradient-to-r from-orange-50 to-yellow-50 border-orange-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-orange-900">Daily Donation Goal</h3>
                <Badge className="bg-orange-100 text-orange-800">
                  {stats.totalToday}/{todaysGoal} donations
                </Badge>
              </div>
              <Progress value={dailyProgress} className="h-3 mb-2" />
              <p className="text-sm text-orange-700">
                {dailyProgress >= 100 
                  ? "🎉 Congratulations! You've exceeded today's goal!" 
                  : `${todaysGoal - stats.totalToday} more donations to reach today's goal`}
              </p>
            </CardContent>
          </Card>

          {/* Real-time Activity Feed */}
          {recentActivity.length > 0 && (
            <Alert className="mt-4 border-green-200 bg-green-50">
              <AlertCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                <div className="font-medium mb-1">Recent Activity:</div>
                <div className="text-sm space-y-1">
                  {recentActivity.slice(0, 2).map((activity, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3" />
                      {activity}
                    </div>
                  ))}
                </div>
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600">Today's Donations</p>
                  <p className="text-3xl font-bold text-blue-700">{stats.totalToday}</p>
                  <p className="text-xs text-blue-600 mt-1">
                    {stats.totalWeek} this week
                  </p>
                </div>
                <Package className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-600">Available Now</p>
                  <p className="text-3xl font-bold text-green-700">{stats.available}</p>
                  <p className="text-xs text-green-600 mt-1">Ready for pickup</p>
                </div>
                <Heart className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-600">Claimed Today</p>
                  <p className="text-3xl font-bold text-purple-700">{stats.claimed}</p>
                  <p className="text-xs text-purple-600 mt-1">Awaiting pickup</p>
                </div>
                <Clock className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-50 to-orange-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-600">Completed</p>
                  <p className="text-3xl font-bold text-orange-700">{stats.completed}</p>
                  <p className="text-xs text-orange-600 mt-1">Successfully delivered</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Route Optimization Section */}
        {showRouteOptimizer && (
          <RouteOptimization
            pickupLocations={allDonations
              .filter(d => d.status === 'claimed')
              .map(d => ({
                donationId: d.id,
                donorName: d.donor_name,
                donorAddress: d.donor_address || 'Khammam, Telangana',
                donorPhone: d.donor_phone || '8341266934'
              }))}
            recipientLocation={{
              name: profile?.organization_name || 'Your Organization',
              address: profile?.address || 'Khammam, Telangana'
            }}
            mode={routeOptimizerMode}
            onClose={() => setShowRouteOptimizer(false)}
            onModeChange={(mode) => setRouteOptimizerMode(mode)}
          />
        )}

        {/* Main Content */}
        {!showRouteOptimizer || routeOptimizerMode === 'inline' ? (
          <Tabs defaultValue="donations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="donations">My Donations</TabsTrigger>
            <TabsTrigger value="impact">Community Impact</TabsTrigger>
            <TabsTrigger value="tips">Restaurant Tips</TabsTrigger>
          </TabsList>

          {/* Donations Tab */}
          <TabsContent value="donations" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Your Food Donations</h2>
              <Button 
                onClick={() => setShowDonationForm(true)}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
              >
                <Plus className="h-4 w-4" />
                Post New Donation
              </Button>
            </div>

            {/* Sample Donations Info Banner */}
            {userDonations.length === 0 && (
              <Alert className="border-blue-200 bg-blue-50">
                <ChefHat className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  <div className="font-medium mb-1">👋 Welcome to FoodBridge!</div>
                  <div className="text-sm">
                    Below are sample donations from Khammam restaurants to show you what your donations could look like. 
                    Click <strong>"Post New Donation"</strong> to start helping feed local children and reduce food waste.
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {allDonations.map((donation) => (
                <Card key={donation.id} className="hover:shadow-lg transition-shadow overflow-hidden">
                  {/* Realistic Food Image */}
                  <div className="relative">
                    <ImageWithFallback
                      src={donation.image_url || "https://images.unsplash.com/photo-1665758483281-b4b59c5fd4c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVwYXJlZCUyMG1lYWxzJTIwcmVhZHklMjBmb29kJTIwY29udGFpbmVyc3xlbnwxfHx8fDE3NTQzMDEyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"}
                      alt={donation.title}
                      className="w-full h-40 object-cover"
                    />
                    <div className="absolute top-3 right-3">
                      <Badge className={
                        donation.status === 'available' ? 'bg-green-100 text-green-800' :
                        donation.status === 'claimed' ? 'bg-blue-100 text-blue-800' :
                        donation.status === 'completed' ? 'bg-gray-100 text-gray-800' :
                        'bg-red-100 text-red-800'
                      }>
                        {donation.status}
                      </Badge>
                    </div>
                    <div className="absolute bottom-3 left-3">
                      <Badge className="bg-black/70 text-white hover:bg-black/70">
                        {donation.quantity} {donation.unit}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{donation.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4 line-clamp-2">{donation.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Food Type:</span>
                        <span>{donation.food_type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Expires:</span>
                        <span>{new Date(donation.expiration_date).toLocaleDateString()}</span>
                      </div>
                      {donation.status === 'claimed' && donation.recipient_name && (
                        <div className="pt-2 border-t">
                          <button
                            onClick={() => handleViewRecipientProfile(donation.recipient_name)}
                            className="text-sm font-medium text-green-600 hover:text-green-800 flex items-center gap-1"
                          >
                            Claimed by: {donation.recipient_name}
                            <Eye className="h-3 w-3" />
                          </button>
                          {donation.recipient_phone && (
                            <p className="text-sm text-gray-500">
                              <Phone className="inline h-3 w-3 mr-1" />
                              {donation.recipient_phone}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="mt-4 flex gap-2">
                      {donation.status === 'claimed' && (
                        <>
                          <Button 
                            size="sm" 
                            onClick={() => handleUpdateStatus(donation.id, 'completed')}
                            className="bg-green-600 hover:bg-green-700 flex-1"
                          >
                            Mark Complete
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              setSelectedTracking({
                                donationId: donation.id,
                                donorLocation: {
                                  name: profile?.organization_name || 'Your Restaurant',
                                  address: profile?.address || 'Station Road, Khammam',
                                  lat: 17.2473 + Math.random() * 0.01,
                                  lng: 80.1514 + Math.random() * 0.01
                                },
                                recipientLocation: {
                                  name: donation.recipient_name || 'Orphanage',
                                  address: 'Wyra Road, Khammam',
                                  lat: 17.2373 + Math.random() * 0.01,
                                  lng: 80.1614 + Math.random() * 0.01
                                },
                                deliveryPerson: {
                                  id: 'driver-1',
                                  name: 'Ravi Kumar',
                                  phone: '9876543210',
                                  vehicle: 'Bike - TS 07 CB 1234',
                                  rating: 4.8
                                }
                              });
                              setShowLiveTracker(true);
                            }}
                            className="flex-1"
                          >
                            <MapPin className="h-3 w-3 mr-1" />
                            🔴 Track Live
                          </Button>
                        </>
                      )}
                      {donation.status === 'available' && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleUpdateStatus(donation.id, 'expired')}
                        >
                          Mark Expired
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {allDonations.length === 0 && (
              <div className="text-center py-12">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No donations yet</h3>
                <p className="text-gray-600 mb-4">
                  Start helping the Khammam community by posting your first food donation.
                </p>
                <Button 
                  onClick={() => setShowDonationForm(true)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Post Your First Donation
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Impact Tab */}
          <TabsContent value="impact" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Your Impact This Month</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
                      <div className="text-3xl font-bold text-green-600 mb-2">
                        {(allDonations.length * 25)} meals
                      </div>
                      <div className="text-gray-600">Provided to children</div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-xl font-bold text-blue-600">{allDonations.length * 15} kg</div>
                        <div className="text-xs text-gray-600">Food waste prevented</div>
                      </div>
                      <div>
                        <div className="text-xl font-bold text-purple-600">{allDonations.length * 8} kg</div>
                        <div className="text-xs text-gray-600">CO2 emissions saved</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Community Recognition</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-yellow-100 rounded-full flex items-center justify-center">
                        <Star className="h-5 w-5 text-yellow-600" />
                      </div>
                      <div>
                        <div className="font-medium">Community Hero</div>
                        <div className="text-sm text-gray-600">Top contributor this month</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center">
                        <Heart className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium">Waste Warrior</div>
                        <div className="text-sm text-gray-600">Reducing food waste daily</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tips Tab */}
          <TabsContent value="tips" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Best Practices for Restaurant Donations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Food Safety</h4>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li>• Maintain proper temperature control</li>
                      <li>• Label all containers with contents and time</li>
                      <li>• Follow FIFO (First In, First Out) principles</li>
                      <li>• Use clean, food-grade containers</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium mb-3">Donation Tips</h4>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li>• Post donations before 6 PM for same-day pickup</li>
                      <li>• Include clear pickup instructions</li>
                      <li>• Estimate realistic quantities</li>
                      <li>• Communicate any dietary restrictions</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium mb-3">Legal Protection</h4>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li>• Food donations are protected under Good Samaritan laws</li>
                      <li>• Maintain donation records for tax benefits</li>
                      <li>• Get receipts from recipient organizations</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium mb-3">Community Impact</h4>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li>• Each meal can feed a child for a day</li>
                      <li>• Regular donations build strong relationships</li>
                      <li>• Your contribution reduces local hunger</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        ) : null}
      </div>

      {/* Forms and Modals */}
      {showDonationForm && (
        <DonationForm 
          onClose={() => setShowDonationForm(false)} 
          onSuccess={handleCreateDonation}
        />
      )}



      {showSMSNotification && (
        <SMSNotification
          message={showSMSNotification.message}
          phoneNumber={showSMSNotification.phoneNumber}
          recipientName={showSMSNotification.recipientName}
          onClose={() => setSMSNotification(null)}
        />
      )}

      {/* Live Location Tracker */}
      {showLiveTracker && selectedTracking && (
        <LiveLocationTracker
          donationId={selectedTracking.donationId}
          donorLocation={selectedTracking.donorLocation}
          recipientLocation={selectedTracking.recipientLocation}
          deliveryPerson={selectedTracking.deliveryPerson}
          onClose={() => {
            setShowLiveTracker(false);
            setSelectedTracking(null);
          }}
          isRecipientView={false}
        />
      )}

      {/* Organization Profile Modal */}
      {showOrgProfile && (
        <OrganizationProfile
          organizationId={selectedOrgId}
          onClose={() => setShowOrgProfile(false)}
          onMessage={handleMessage}
        />
      )}
    </div>
  );
}